import subprocess
import json
import os
from pathlib import Path
from typing import Dict, Set, List

class CSharpDependencyAnalyzer:
    def __init__(self, analyzer_exe_path):
        self.analyzer_path = analyzer_exe_path
        self.is_dll = analyzer_exe_path.endswith('.dll')
    
    def analyze_file(self, project_path, target_file):
        """Analyze dependencies for a specific C# file."""
        try:
            if self.is_dll:
                cmd = ['dotnet', self.analyzer_path, project_path, target_file]
            else:
                cmd = [self.analyzer_path, project_path, target_file]
            
            result = subprocess.run(cmd, capture_output=True, text=True, check=False)
            
            if result.returncode == 0:
                return json.loads(result.stdout)
            else:
                try:
                    return json.loads(result.stdout)
                except:
                    return {
                        'error': True,
                        'message': result.stderr or result.stdout,
                        'returnCode': result.returncode
                    }
        except Exception as e:
            return {'error': True, 'message': str(e)}
    
    def get_full_dependency_tree(self, project_path, target_file, max_depth=10):
        """
        Build complete nested dependency tree.
        
        Returns structure:
        {
            "file": "target.cs",
            "dependencies": {...},
            "children": [
                {
                    "file": "dependency1.cs",
                    "dependencies": {...},
                    "children": [...]
                }
            ]
        }
        """
        analyzed_files = set()
        
        def analyze_recursive(file_path, current_depth, parent_chain):
            # Prevent infinite loops
            if current_depth > max_depth:
                return {
                    'file': file_path,
                    'error': 'Max depth reached',
                    'depth': current_depth
                }
            
            # Prevent circular dependencies
            if file_path in analyzed_files:
                return {
                    'file': file_path,
                    'circular': True,
                    'note': 'Already analyzed (circular reference)',
                    'depth': current_depth
                }
            
            analyzed_files.add(file_path)
            
            # Analyze current file
            result = self.analyze_file(project_path, file_path)
            
            if result.get('error'):
                return {
                    'file': file_path,
                    'error': result.get('message'),
                    'depth': current_depth
                }
            
            # Build tree node
            tree_node = {
                'file': file_path,
                'fullPath': result.get('fullPath'),
                'depth': current_depth,
                'dependencies': result.get('dependencies'),
                'children': []
            }
            
            # Recursively analyze all referenced files
            referenced_files = result.get('dependencies', {}).get('referencedFiles', [])
            
            for ref_file in referenced_files:
                ref_path = ref_file.get('fullPath') or ref_file.get('relativePath')
                
                # Analyze child dependency
                child_node = analyze_recursive(
                    ref_path, 
                    current_depth + 1,
                    parent_chain + [file_path]
                )
                tree_node['children'].append(child_node)
            
            return tree_node
        
        return analyze_recursive(target_file, 0, [])
    
    def get_flat_dependency_list(self, project_path, target_file, max_depth=10):
        """
        Get a flat list of ALL dependencies (direct and transitive).
        
        Returns:
        {
            "targetFile": "...",
            "allDependencies": [
                {
                    "file": "...",
                    "depth": 1,
                    "dependencyChain": ["root.cs", "level1.cs", "level2.cs"]
                }
            ]
        }
        """
        all_deps = []
        analyzed = set()
        
        def collect_deps(file_path, current_depth, chain):
            if current_depth > max_depth or file_path in analyzed:
                return
            
            analyzed.add(file_path)
            result = self.analyze_file(project_path, file_path)
            
            if result.get('error'):
                return
            
            referenced_files = result.get('dependencies', {}).get('referencedFiles', [])
            
            for ref_file in referenced_files:
                ref_path = ref_file.get('fullPath') or ref_file.get('relativePath')
                
                dep_info = {
                    'file': ref_path,
                    'relativePath': ref_file.get('relativePath'),
                    'depth': current_depth + 1,
                    'dependencyChain': chain + [file_path, ref_path]
                }
                all_deps.append(dep_info)
                
                # Continue recursively
                collect_deps(ref_path, current_depth + 1, chain + [file_path])
        
        collect_deps(target_file, 0, [])
        
        return {
            'targetFile': target_file,
            'totalDependencies': len(all_deps),
            'allDependencies': all_deps
        }
    
    def get_dependency_graph(self, project_path, target_file, max_depth=10):
        """
        Build a complete dependency graph showing all relationships.
        
        Returns:
        {
            "nodes": [{"id": "file.cs", "label": "file.cs", ...}],
            "edges": [{"from": "a.cs", "to": "b.cs", "depth": 1}]
        }
        """
        nodes = {}
        edges = []
        analyzed = set()
        
        def build_graph(file_path, current_depth):
            if current_depth > max_depth or file_path in analyzed:
                return
            
            analyzed.add(file_path)
            result = self.analyze_file(project_path, file_path)
            
            if result.get('error'):
                return
            
            # Add node
            if file_path not in nodes:
                nodes[file_path] = {
                    'id': file_path,
                    'fullPath': result.get('fullPath'),
                    'depth': current_depth,
                    'usingDirectives': result.get('dependencies', {}).get('usingDirectives', []),
                    'declaredClasses': result.get('dependencies', {}).get('declaredClasses', [])
                }
            
            # Add edges
            referenced_files = result.get('dependencies', {}).get('referencedFiles', [])
            for ref_file in referenced_files:
                ref_path = ref_file.get('fullPath') or ref_file.get('relativePath')
                
                edges.append({
                    'from': file_path,
                    'to': ref_path,
                    'depth': current_depth
                })
                
                # Recurse
                build_graph(ref_path, current_depth + 1)
        
        build_graph(target_file, 0)
        
        return {
            'targetFile': target_file,
            'nodes': list(nodes.values()),
            'edges': edges,
            'totalNodes': len(nodes),
            'totalEdges': len(edges)
        }


# Complete Example Usage
def main():
    # Configure paths
    analyzer_path = r"C:\Users\ABHISHEK SANODIYA\Desktop\vulnerability\CSharpDependencyAnalyzer\bin\Release\net10.0\CSharpDependencyAnalyzer.dll"
    
    # Initialize analyzer    
    # Analyze a specific file
    target_file = r"C:\Users\ABHISHEK SANODIYA\Desktop\vulnerability\eShopOnWeb\src\BlazorAdmin\Program.cs"
    project_path = r"C:\Users\ABHISHEK SANODIYA\Desktop\vulnerability\eShopOnWeb\src\BlazorAdmin\BlazorAdmin.csproj"
 
    
    analyzer = CSharpDependencyAnalyzer(analyzer_path)
    
    print("=" * 60)
    print("1. NESTED DEPENDENCY TREE (Full Hierarchy)")
    print("=" * 60)
    tree = analyzer.get_full_dependency_tree(project_path, target_file, max_depth=5)
    with open('dependency_tree.json', 'w') as f:
        json.dump(tree, f, indent=2)
    print("Saved to: dependency_tree.json")
    print(f"Root file: {tree['file']}")
    print(f"Direct children: {len(tree.get('children', []))}")
    
    print("\n" + "=" * 60)
    print("2. FLAT DEPENDENCY LIST (All Levels)")
    print("=" * 60)
    flat = analyzer.get_flat_dependency_list(project_path, target_file, max_depth=5)
    with open('dependency_flat.json', 'w') as f:
        json.dump(flat, f, indent=2)
    print("Saved to: dependency_flat.json")
    print(f"Total dependencies: {flat['totalDependencies']}")
    
    # Print sample dependency chains
    print("\nSample dependency chains:")
    for dep in flat['allDependencies'][:5]:
        chain = " -> ".join([Path(p).name for p in dep['dependencyChain']])
        print(f"  Depth {dep['depth']}: {chain}")
    
    print("\n" + "=" * 60)
    print("3. DEPENDENCY GRAPH (Nodes & Edges)")
    print("=" * 60)
    graph = analyzer.get_dependency_graph(project_path, target_file, max_depth=5)
    with open('dependency_graph.json', 'w') as f:
        json.dump(graph, f, indent=2)
    print("Saved to: dependency_graph.json")
    print(f"Total nodes: {graph['totalNodes']}")
    print(f"Total edges: {graph['totalEdges']}")
    
    print("\n" + "=" * 60)
    print("4. SINGLE FILE ANALYSIS")
    print("=" * 60)
    single = analyzer.analyze_file(project_path, target_file)
    with open('dependency_single.json', 'w') as f:
        json.dump(single, f, indent=2)
    print("Saved to: dependency_single.json")
    
    if not single.get('error'):
        deps = single.get('dependencies', {})
        print(f"Using directives: {len(deps.get('usingDirectives', []))}")
        print(f"Referenced files: {len(deps.get('referencedFiles', []))}")
        print(f"Referenced types: {len(deps.get('referencedTypes', []))}")


if __name__ == '__main__':
    main()
