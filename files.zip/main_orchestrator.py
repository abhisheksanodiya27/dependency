"""
Main Orchestrator for Vulnerability Resolution System
Coordinates all agents and manages the complete workflow
"""

import os
import sys
from pathlib import Path
from typing import List, Dict
import pandas as pd
from datetime import datetime

from vuln_resolver_agent import (
    OpenAIClient,
    GitHubRepoManager,
    DependencyAnalyzer,
    VulnerabilityFixer,
    FlowDiagramGenerator,
    VulnerabilityInput,
    AgentState,
    create_agent_workflow
)


class VulnerabilityResolutionOrchestrator:
    """Main orchestrator for the vulnerability resolution system"""
    
    def __init__(self, openai_api_key: str, github_token: str = None):
        """Initialize the orchestrator with API keys"""
        self.openai_client = OpenAIClient(openai_api_key)
        self.github_token = github_token
        
        self.dependency_analyzer = DependencyAnalyzer(self.openai_client)
        self.vuln_fixer = VulnerabilityFixer(self.openai_client)
        self.diagram_generator = FlowDiagramGenerator(self.openai_client)
        
        self.output_dir = Path("output")
        self.output_dir.mkdir(exist_ok=True)
    
    def load_vulnerabilities(self, csv_path: str) -> List[VulnerabilityInput]:
        """Load vulnerabilities from CSV file"""
        
        df = pd.read_csv(csv_path)
        vulnerabilities = []
        
        for _, row in df.iterrows():
            vuln = VulnerabilityInput(
                file_name=row['file_name'],
                file_path=row['file_path'],
                line_number=int(row['line_number']),
                vulnerability_type=row['vulnerability_type'],
                description=row['description']
            )
            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def run_complete_workflow(self, repo_url: str, vulnerabilities_csv: str,
                             local_repo_path: str = "./repo",
                             branch_name: str = None):
        """Run the complete vulnerability resolution workflow"""
        
        if branch_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            branch_name = f"vuln-fix-{timestamp}"
        
        print("=" * 80)
        print("VULNERABILITY RESOLUTION WORKFLOW")
        print("=" * 80)
        
        # Step 1: Clone Repository
        print("\n[STEP 1] Cloning repository...")
        repo_manager = GitHubRepoManager(repo_url, local_repo_path, self.github_token)
        
        if not repo_manager.clone_repo():
            print("Failed to clone repository")
            return False
        
        repo_path = Path(local_repo_path)
        
        # Step 2: Load Vulnerabilities
        print("\n[STEP 2] Loading vulnerabilities...")
        vulnerabilities = self.load_vulnerabilities(vulnerabilities_csv)
        print(f"Loaded {len(vulnerabilities)} vulnerabilities")
        
        for vuln in vulnerabilities:
            print(f"  - {vuln.file_path}:{vuln.line_number} - {vuln.vulnerability_type}")
        
        # Step 3: Analyze Dependencies
        print("\n[STEP 3] Analyzing repository dependencies...")
        print("This may take a while for large repositories...")
        
        dependencies = self.dependency_analyzer.analyze_repository(repo_path)
        print(f"Analyzed {len(dependencies)} files")
        
        # Save dependencies to CSV
        dep_output_path = self.output_dir / "dependencies.csv"
        self.dependency_analyzer.save_dependencies_to_csv(dependencies, str(dep_output_path))
        
        # Step 4: Create New Branch
        print("\n[STEP 4] Creating new branch...")
        if not repo_manager.create_branch(branch_name):
            print("Failed to create branch")
            return False
        print(f"Created branch: {branch_name}")
        
        # Step 5: Fix Vulnerabilities
        print("\n[STEP 5] Fixing vulnerabilities...")
        fixes = []
        
        for idx, vuln in enumerate(vulnerabilities, 1):
            print(f"\nFixing {idx}/{len(vulnerabilities)}: {vuln.file_path}:{vuln.line_number}")
            print(f"  Type: {vuln.vulnerability_type}")
            
            fix = self.vuln_fixer.fix_vulnerability(vuln, repo_path, dependencies)
            fixes.append(fix)
            
            if fix.fixed_code:
                print(f"  ✓ Fix generated")
                print(f"  Dependent files analyzed: {len(fix.dependent_files_analyzed)}")
            else:
                print(f"  ✗ Fix failed: {fix.explanation}")
        
        # Step 6: Validate Fixes
        print("\n[STEP 6] Validating fixes...")
        validated_fixes = []
        
        for fix in fixes:
            if fix.fixed_code:
                # Validate using LLM
                validation_result = self._validate_fix(fix, repo_path, dependencies)
                fix.validation_status = validation_result
                validated_fixes.append(fix)
                print(f"  {fix.file_path}: {validation_result}")
        
        # Step 7: Apply Fixes
        print("\n[STEP 7] Applying fixes to files...")
        applied_count = 0
        
        for fix in validated_fixes:
            if fix.validation_status == "valid":
                if self.vuln_fixer.apply_fix(fix, repo_path):
                    applied_count += 1
        
        print(f"Applied {applied_count}/{len(validated_fixes)} fixes")
        
        # Step 8: Generate Flow Diagrams
        print("\n[STEP 8] Generating flow diagrams...")
        diagrams_dir = self.output_dir / "diagrams"
        diagrams_dir.mkdir(exist_ok=True)
        
        for idx, (vuln, fix) in enumerate(zip(vulnerabilities, fixes), 1):
            if fix.fixed_code:
                print(f"  Generating diagram {idx}/{len(vulnerabilities)}")
                diagram = self.diagram_generator.generate_diagram(vuln, fix, dependencies)
                
                diagram_path = diagrams_dir / f"vuln_{idx}_{vuln.vulnerability_type}.md"
                with open(diagram_path, 'w') as f:
                    f.write(f"# Vulnerability Flow Diagram\n\n")
                    f.write(f"**File:** {vuln.file_path}\n")
                    f.write(f"**Line:** {vuln.line_number}\n")
                    f.write(f"**Type:** {vuln.vulnerability_type}\n\n")
                    f.write(diagram)
        
        # Step 9: Generate Summary Report
        print("\n[STEP 9] Generating summary report...")
        self._generate_report(vulnerabilities, fixes, validated_fixes)
        
        # Step 10: Commit and Push
        print("\n[STEP 10] Committing and pushing changes...")
        commit_message = f"Fix {len(validated_fixes)} security vulnerabilities\n\n"
        commit_message += "Vulnerabilities fixed:\n"
        
        for fix in validated_fixes:
            commit_message += f"- {fix.file_path}:{fix.line_number} - {fix.vulnerability_type}\n"
        
        if repo_manager.commit_changes(commit_message):
            print("  ✓ Changes committed")
            
            if repo_manager.push_changes(branch_name):
                print(f"  ✓ Changes pushed to branch: {branch_name}")
            else:
                print("  ✗ Failed to push changes")
        else:
            print("  ✗ Failed to commit changes")
        
        print("\n" + "=" * 80)
        print("WORKFLOW COMPLETED")
        print("=" * 80)
        print(f"Branch: {branch_name}")
        print(f"Fixes applied: {applied_count}/{len(vulnerabilities)}")
        print(f"Output directory: {self.output_dir.absolute()}")
        
        return True
    
    def _validate_fix(self, fix, repo_path, dependencies) -> str:
        """Validate a fix using LLM"""
        
        prompt = f"""Validate the following security fix:

File: {fix.file_path}
Vulnerability Type: {fix.vulnerability_type}
Line: {fix.line_number}

Original Code:
{fix.original_code}

Fixed Code:
{fix.fixed_code}

Explanation:
{fix.explanation}

Dependent Files Analyzed: {fix.dependent_files_analyzed}

Validate that:
1. The fix properly addresses the vulnerability
2. No new vulnerabilities are introduced
3. Dependencies are not broken
4. The code maintains functionality

Respond with ONE word: "valid", "invalid", or "needs_review"
"""
        
        messages = [
            {"role": "system", "content": "You are a security code reviewer. Validate fixes strictly."},
            {"role": "user", "content": prompt}
        ]
        
        try:
            response = self.openai_client.chat_completion(messages).strip().lower()
            if "valid" in response and "invalid" not in response:
                return "valid"
            elif "invalid" in response:
                return "invalid"
            else:
                return "needs_review"
        except:
            return "needs_review"
    
    def _generate_report(self, vulnerabilities, fixes, validated_fixes):
        """Generate summary report"""
        
        report_path = self.output_dir / "vulnerability_resolution_report.md"
        
        with open(report_path, 'w') as f:
            f.write("# Vulnerability Resolution Report\n\n")
            f.write(f"**Date:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"**Total Vulnerabilities:** {len(vulnerabilities)}\n")
            f.write(f"**Fixes Generated:** {len(fixes)}\n")
            f.write(f"**Fixes Validated:** {len(validated_fixes)}\n\n")
            
            f.write("## Summary by Status\n\n")
            valid_count = sum(1 for fix in validated_fixes if fix.validation_status == "valid")
            invalid_count = sum(1 for fix in validated_fixes if fix.validation_status == "invalid")
            review_count = sum(1 for fix in validated_fixes if fix.validation_status == "needs_review")
            
            f.write(f"- Valid: {valid_count}\n")
            f.write(f"- Invalid: {invalid_count}\n")
            f.write(f"- Needs Review: {review_count}\n\n")
            
            f.write("## Detailed Results\n\n")
            
            for idx, (vuln, fix) in enumerate(zip(vulnerabilities, fixes), 1):
                f.write(f"### {idx}. {vuln.vulnerability_type}\n\n")
                f.write(f"**File:** `{vuln.file_path}`\n")
                f.write(f"**Line:** {vuln.line_number}\n")
                f.write(f"**Status:** {fix.validation_status}\n\n")
                f.write(f"**Description:** {vuln.description}\n\n")
                f.write(f"**Fix Explanation:**\n{fix.explanation}\n\n")
                
                if fix.dependent_files_analyzed:
                    f.write(f"**Dependent Files Analyzed:**\n")
                    for dep_file in fix.dependent_files_analyzed:
                        f.write(f"- {dep_file}\n")
                    f.write("\n")
                
                f.write("---\n\n")
        
        print(f"Report generated: {report_path}")


def create_sample_vulnerability_csv(output_path: str = "sample_vulnerabilities.csv"):
    """Create a sample vulnerability CSV file"""
    
    data = {
        'file_name': [
            'auth.py',
            'database.py',
            'api_handler.py',
            'user_controller.cs',
            'data_service.java'
        ],
        'file_path': [
            'src/auth/auth.py',
            'src/database/database.py',
            'src/api/api_handler.py',
            'Controllers/UserController.cs',
            'com/example/service/DataService.java'
        ],
        'line_number': [
            45,
            78,
            120,
            56,
            89
        ],
        'vulnerability_type': [
            'SQL Injection',
            'Hardcoded Credentials',
            'XSS (Cross-Site Scripting)',
            'Insecure Deserialization',
            'Path Traversal'
        ],
        'description': [
            'User input is directly concatenated into SQL query without parameterization, allowing SQL injection attacks',
            'Database password is hardcoded in the source code, should be moved to environment variables or secure vault',
            'User-provided data is rendered in HTML without proper sanitization, allowing XSS attacks',
            'User input is deserialized without validation, potentially allowing remote code execution',
            'File path is constructed using user input without validation, allowing access to unauthorized files'
        ]
    }
    
    df = pd.DataFrame(data)
    df.to_csv(output_path, index=False)
    print(f"Sample vulnerability CSV created: {output_path}")
    return output_path


def main():
    """Main entry point"""
    
    # Configuration
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "your-openai-api-key-here")
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")  # Optional
    
    # Example usage
    REPO_URL = "https://github.com/your-org/your-repo.git"
    LOCAL_REPO_PATH = "./target_repo"
    
    # Create sample CSV if it doesn't exist
    vulnerabilities_csv = "sample_vulnerabilities.csv"
    if not Path(vulnerabilities_csv).exists():
        create_sample_vulnerability_csv(vulnerabilities_csv)
    
    # Initialize orchestrator
    orchestrator = VulnerabilityResolutionOrchestrator(
        openai_api_key=OPENAI_API_KEY,
        github_token=GITHUB_TOKEN
    )
    
    # Run workflow
    print("\nStarting Vulnerability Resolution Workflow...")
    print("=" * 80)
    
    success = orchestrator.run_complete_workflow(
        repo_url=REPO_URL,
        vulnerabilities_csv=vulnerabilities_csv,
        local_repo_path=LOCAL_REPO_PATH
    )
    
    if success:
        print("\n✓ Workflow completed successfully!")
    else:
        print("\n✗ Workflow failed!")
    
    return 0 if success else 1


if __name__ == "__main__":
    # For testing, just create the sample CSV
    create_sample_vulnerability_csv()
    print("\nTo run the full workflow, update the configuration in main() and execute:")
    print("python main_orchestrator.py")
