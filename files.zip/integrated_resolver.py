"""
Complete Integration Script
Demonstrates the full workflow with all components working together
"""

import os
import sys
from pathlib import Path
import json
from datetime import datetime

# Import all components
from vuln_resolver_agent import (
    OpenAIClient,
    GitHubRepoManager,
    VulnerabilityInput,
    create_agent_workflow
)
from advanced_dependency_analyzer import AdvancedDependencyAnalyzer
from enhanced_vulnerability_fixer import EnhancedVulnerabilityFixer
from main_orchestrator import (
    VulnerabilityResolutionOrchestrator,
    create_sample_vulnerability_csv
)


class IntegratedVulnerabilityResolver:
    """Integrated system using all advanced components"""
    
    def __init__(self, openai_api_key: str, github_token: str = None):
        # Initialize OpenAI client
        self.openai_client = OpenAIClient(api_key=openai_api_key, model="gpt-4o")
        self.github_token = github_token
        
        # Initialize all components
        self.dependency_analyzer = AdvancedDependencyAnalyzer(self.openai_client)
        self.vulnerability_fixer = EnhancedVulnerabilityFixer(self.openai_client)
        
        # Output directories
        self.output_dir = Path("output")
        self.output_dir.mkdir(exist_ok=True)
        
        (self.output_dir / "diagrams").mkdir(exist_ok=True)
        (self.output_dir / "reports").mkdir(exist_ok=True)
        (self.output_dir / "backups").mkdir(exist_ok=True)
    
    def execute_workflow(self, repo_url: str, vulnerabilities_csv: str,
                        local_repo_path: str = "./target_repo",
                        branch_name: str = None):
        """Execute the complete integrated workflow"""
        
        if branch_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            branch_name = f"security-fix-{timestamp}"
        
        print("\n" + "="*80)
        print("INTEGRATED VULNERABILITY RESOLUTION SYSTEM")
        print("="*80)
        print(f"Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"Repository: {repo_url}")
        print(f"Branch: {branch_name}")
        print("="*80 + "\n")
        
        # ===================================================================
        # PHASE 1: REPOSITORY SETUP
        # ===================================================================
        print("[PHASE 1] REPOSITORY SETUP")
        print("-" * 80)
        
        repo_manager = GitHubRepoManager(repo_url, local_repo_path, self.github_token)
        
        if not repo_manager.clone_repo():
            print("❌ Failed to clone repository")
            return False
        
        print("✅ Repository cloned successfully")
        repo_path = Path(local_repo_path)
        
        # ===================================================================
        # PHASE 2: LOAD VULNERABILITIES
        # ===================================================================
        print("\n[PHASE 2] VULNERABILITY LOADING")
        print("-" * 80)
        
        vulnerabilities = self._load_vulnerabilities(vulnerabilities_csv)
        print(f"✅ Loaded {len(vulnerabilities)} vulnerabilities")
        
        for i, vuln in enumerate(vulnerabilities, 1):
            print(f"  {i}. {vuln.file_path}:{vuln.line_number}")
            print(f"     Type: {vuln.vulnerability_type}")
            print(f"     Desc: {vuln.description[:60]}...")
        
        # ===================================================================
        # PHASE 3: COMPREHENSIVE DEPENDENCY ANALYSIS
        # ===================================================================
        print("\n[PHASE 3] DEPENDENCY ANALYSIS (LLM-based)")
        print("-" * 80)
        print("This will analyze all files using GPT-4o...")
        
        # Build dependency graph
        dependency_graph = self.dependency_analyzer.build_dependency_graph(repo_path)
        print(f"✅ Analyzed {len(dependency_graph)} files")
        
        # Save dependency graph
        graph_path = self.output_dir / "dependency_graph.json"
        self.dependency_analyzer.save_dependency_graph(dependency_graph, str(graph_path))
        print(f"✅ Dependency graph saved: {graph_path}")
        
        # Generate dependency report
        report_path = self.output_dir / "reports" / "dependency_analysis_report.md"
        self.dependency_analyzer.generate_dependency_report(
            dependency_graph, str(report_path)
        )
        print(f"✅ Dependency report saved: {report_path}")
        
        # Extract relationships
        relationships = self.dependency_analyzer.extract_dependency_relationships(
            dependency_graph
        )
        print(f"✅ Extracted relationships:")
        print(f"   - File-to-file dependencies: {len(relationships['file_to_file'])}")
        print(f"   - Import chains: {len(relationships['import_chains'])}")
        
        # ===================================================================
        # PHASE 4: CREATE GIT BRANCH
        # ===================================================================
        print("\n[PHASE 4] GIT BRANCH CREATION")
        print("-" * 80)
        
        if not repo_manager.create_branch(branch_name):
            print("❌ Failed to create branch")
            return False
        
        print(f"✅ Created branch: {branch_name}")
        
        # ===================================================================
        # PHASE 5: VULNERABILITY ANALYSIS & FIXING
        # ===================================================================
        print("\n[PHASE 5] VULNERABILITY ANALYSIS & FIXING")
        print("-" * 80)
        
        all_fixes = []
        
        for i, vuln in enumerate(vulnerabilities, 1):
            print(f"\n--- Processing Vulnerability {i}/{len(vulnerabilities)} ---")
            print(f"File: {vuln.file_path}")
            print(f"Line: {vuln.line_number}")
            print(f"Type: {vuln.vulnerability_type}")
            
            # Step 5.1: Get relevant context
            print("  [5.1] Extracting context...")
            file_path = repo_path / vuln.file_path
            
            if not file_path.exists():
                print(f"  ❌ File not found: {vuln.file_path}")
                continue
            
            context = self.vulnerability_fixer.get_smart_context(
                file_path, vuln.line_number, dependency_graph
            )
            print(f"  ✅ Context extracted (lines {context['start_line']}-{context['end_line']})")
            
            # Step 5.2: Get dependent code
            print("  [5.2] Analyzing dependencies...")
            dependent_code = self.vulnerability_fixer.get_dependency_context(
                vuln.file_path, dependency_graph, repo_path
            )
            print(f"  ✅ Found {len(dependent_code)} dependent files")
            
            # Step 5.3: Analyze impact
            print("  [5.3] Analyzing security impact...")
            impact_analysis = self.vulnerability_fixer.analyze_vulnerability_impact(
                vuln, context, dependency_graph
            )
            
            try:
                impact_data = json.loads(impact_analysis)
                severity = impact_data.get('severity', 'unknown')
                print(f"  ✅ Impact analyzed - Severity: {severity}")
            except:
                print("  ⚠️  Impact analysis completed (parsing issue)")
            
            # Step 5.4: Generate fix
            print("  [5.4] Generating secure fix...")
            fix = self.vulnerability_fixer.generate_fix(
                vuln, context, dependent_code, impact_analysis, dependency_graph
            )
            
            if fix.fixed_code:
                print("  ✅ Fix generated successfully")
            else:
                print("  ❌ Fix generation failed")
                continue
            
            # Step 5.5: Validate fix
            print("  [5.5] Validating fix...")
            validation_result = self.vulnerability_fixer.validate_fix_comprehensive(
                fix, dependency_graph, repo_path
            )
            
            status = validation_result.get('overall_status', 'unknown')
            security_score = validation_result.get('security_score', 0)
            functionality_score = validation_result.get('functionality_score', 0)
            
            print(f"  ✅ Validation: {status}")
            print(f"     Security Score: {security_score}/100")
            print(f"     Functionality Score: {functionality_score}/100")
            
            fix.validation_status = status
            
            # Store validation details
            validation_path = self.output_dir / "reports" / f"validation_{i}_{vuln.vulnerability_type}.json"
            with open(validation_path, 'w') as f:
                json.dump(validation_result, f, indent=2)
            
            all_fixes.append((vuln, fix, validation_result))
        
        # ===================================================================
        # PHASE 6: APPLY FIXES
        # ===================================================================
        print("\n[PHASE 6] APPLYING FIXES")
        print("-" * 80)
        
        applied_count = 0
        skipped_count = 0
        
        for vuln, fix, validation in all_fixes:
            if fix.validation_status in ["approved", "valid"]:
                print(f"Applying fix to {vuln.file_path}...")
                
                if self.vulnerability_fixer.apply_fix_to_file(fix, repo_path):
                    applied_count += 1
                    print(f"  ✅ Applied")
                else:
                    print(f"  ❌ Failed to apply")
            else:
                print(f"Skipping {vuln.file_path} (validation: {fix.validation_status})")
                skipped_count += 1
        
        print(f"\n✅ Applied: {applied_count}")
        print(f"⏭️  Skipped: {skipped_count}")
        
        # ===================================================================
        # PHASE 7: GENERATE DOCUMENTATION
        # ===================================================================
        print("\n[PHASE 7] GENERATING DOCUMENTATION")
        print("-" * 80)
        
        # Generate comprehensive report
        self._generate_comprehensive_report(
            vulnerabilities, all_fixes, dependency_graph, relationships
        )
        
        # Generate flow diagrams
        self._generate_flow_diagrams(vulnerabilities, all_fixes, dependency_graph)
        
        # ===================================================================
        # PHASE 8: GIT COMMIT & PUSH
        # ===================================================================
        print("\n[PHASE 8] GIT COMMIT & PUSH")
        print("-" * 80)
        
        # Create commit message
        commit_msg = self._create_commit_message(vulnerabilities, all_fixes)
        
        if repo_manager.commit_changes(commit_msg):
            print("✅ Changes committed")
            
            if repo_manager.push_changes(branch_name):
                print(f"✅ Changes pushed to branch: {branch_name}")
            else:
                print("⚠️  Failed to push changes (check permissions)")
        else:
            print("⚠️  No changes to commit")
        
        # ===================================================================
        # FINAL SUMMARY
        # ===================================================================
        print("\n" + "="*80)
        print("WORKFLOW COMPLETED")
        print("="*80)
        print(f"📊 Statistics:")
        print(f"   - Total vulnerabilities: {len(vulnerabilities)}")
        print(f"   - Fixes generated: {len(all_fixes)}")
        print(f"   - Fixes applied: {applied_count}")
        print(f"   - Fixes skipped: {skipped_count}")
        print(f"\n📁 Output directory: {self.output_dir.absolute()}")
        print(f"🌿 Git branch: {branch_name}")
        print("="*80 + "\n")
        
        return True
    
    def _load_vulnerabilities(self, csv_path: str):
        """Load vulnerabilities from CSV"""
        import pandas as pd
        
        df = pd.read_csv(csv_path)
        vulnerabilities = []
        
        for _, row in df.iterrows():
            vuln = VulnerabilityInput(
                file_name=row['file_name'],
                file_path=row['file_path'],
                line_number=int(row['line_number']),
                vulnerability_type=row['vulnerability_type'],
                description=row['description']
            )
            vulnerabilities.append(vuln)
        
        return vulnerabilities
    
    def _generate_comprehensive_report(self, vulnerabilities, all_fixes,
                                      dependency_graph, relationships):
        """Generate comprehensive resolution report"""
        
        report_path = self.output_dir / "reports" / "comprehensive_report.md"
        
        with open(report_path, 'w') as f:
            f.write("# Comprehensive Vulnerability Resolution Report\n\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Executive Summary
            f.write("## Executive Summary\n\n")
            f.write(f"- **Total Vulnerabilities:** {len(vulnerabilities)}\n")
            f.write(f"- **Fixes Generated:** {len(all_fixes)}\n")
            
            approved = sum(1 for _, fix, _ in all_fixes if fix.validation_status in ["approved", "valid"])
            f.write(f"- **Fixes Approved:** {approved}\n")
            f.write(f"- **Files Analyzed:** {len(dependency_graph)}\n\n")
            
            # Vulnerability Breakdown
            f.write("## Vulnerability Breakdown\n\n")
            vuln_types = {}
            for vuln in vulnerabilities:
                vuln_types[vuln.vulnerability_type] = vuln_types.get(vuln.vulnerability_type, 0) + 1
            
            for vtype, count in sorted(vuln_types.items(), key=lambda x: -x[1]):
                f.write(f"- **{vtype}:** {count}\n")
            f.write("\n")
            
            # Detailed Results
            f.write("## Detailed Results\n\n")
            
            for i, (vuln, fix, validation) in enumerate(all_fixes, 1):
                f.write(f"### {i}. {vuln.vulnerability_type}\n\n")
                f.write(f"**File:** `{vuln.file_path}` (Line {vuln.line_number})\n\n")
                f.write(f"**Status:** {fix.validation_status}\n\n")
                
                if 'security_score' in validation:
                    f.write(f"**Validation Scores:**\n")
                    f.write(f"- Security: {validation.get('security_score', 'N/A')}/100\n")
                    f.write(f"- Functionality: {validation.get('functionality_score', 'N/A')}/100\n\n")
                
                f.write(f"**Description:** {vuln.description}\n\n")
                
                if fix.dependent_files_analyzed:
                    f.write(f"**Dependent Files Analyzed:**\n")
                    for dep in fix.dependent_files_analyzed:
                        f.write(f"- `{dep}`\n")
                    f.write("\n")
                
                if 'issues_found' in validation and validation['issues_found']:
                    f.write(f"**Issues Found:**\n")
                    for issue in validation['issues_found']:
                        f.write(f"- [{issue['severity']}] {issue['issue']}\n")
                    f.write("\n")
                
                f.write("---\n\n")
        
        print(f"✅ Comprehensive report generated: {report_path}")
    
    def _generate_flow_diagrams(self, vulnerabilities, all_fixes, dependency_graph):
        """Generate flow diagrams for all vulnerabilities"""
        
        from vuln_resolver_agent import FlowDiagramGenerator
        
        diagram_gen = FlowDiagramGenerator(self.openai_client)
        diagrams_dir = self.output_dir / "diagrams"
        
        for i, (vuln, fix, _) in enumerate(all_fixes, 1):
            print(f"  Generating diagram {i}/{len(all_fixes)}...")
            
            try:
                diagram = diagram_gen.generate_diagram(vuln, fix, dependency_graph)
                
                diagram_path = diagrams_dir / f"vuln_{i}_{vuln.vulnerability_type.replace(' ', '_')}.md"
                
                with open(diagram_path, 'w') as f:
                    f.write(f"# {vuln.vulnerability_type} - Flow Diagram\n\n")
                    f.write(f"**File:** {vuln.file_path}\n")
                    f.write(f"**Line:** {vuln.line_number}\n\n")
                    f.write(diagram)
                
                print(f"  ✅ Saved: {diagram_path.name}")
            except Exception as e:
                print(f"  ⚠️  Failed to generate diagram: {str(e)}")
        
        print(f"✅ Flow diagrams saved to {diagrams_dir}")
    
    def _create_commit_message(self, vulnerabilities, all_fixes):
        """Create comprehensive commit message"""
        
        msg = f"Security: Fix {len(vulnerabilities)} vulnerabilities\n\n"
        msg += "This commit addresses the following security issues:\n\n"
        
        for vuln, fix, _ in all_fixes:
            if fix.validation_status in ["approved", "valid"]:
                msg += f"- {vuln.vulnerability_type} in {vuln.file_path}:{vuln.line_number}\n"
        
        msg += "\nAll fixes have been validated for:\n"
        msg += "- Security completeness\n"
        msg += "- Functionality preservation\n"
        msg += "- Dependency compatibility\n"
        
        return msg


def main():
    """Main execution function"""
    
    print("\n" + "="*80)
    print("INTEGRATED VULNERABILITY RESOLUTION SYSTEM")
    print("="*80 + "\n")
    
    # Check for API key
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or api_key == "your-openai-api-key-here":
        print("❌ Error: OPENAI_API_KEY not set")
        print("\nPlease set your OpenAI API key:")
        print("  export OPENAI_API_KEY='your-key-here'")
        return 1
    
    # Create sample vulnerability CSV if it doesn't exist
    vuln_csv = "sample_vulnerabilities.csv"
    if not Path(vuln_csv).exists():
        print(f"Creating sample vulnerability CSV: {vuln_csv}")
        create_sample_vulnerability_csv(vuln_csv)
        print("✅ Sample CSV created\n")
    
    # Configuration
    REPO_URL = os.getenv("REPO_URL", "https://github.com/your-org/your-repo.git")
    GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
    
    if REPO_URL == "https://github.com/your-org/your-repo.git":
        print("⚠️  Note: Using example repository URL")
        print("   Set REPO_URL environment variable to analyze your repository")
        print("\nFor demonstration, sample CSV has been created.")
        print("Update configuration in the script to run against a real repository.\n")
        return 0
    
    # Initialize integrated resolver
    resolver = IntegratedVulnerabilityResolver(
        openai_api_key=api_key,
        github_token=GITHUB_TOKEN
    )
    
    # Execute workflow
    success = resolver.execute_workflow(
        repo_url=REPO_URL,
        vulnerabilities_csv=vuln_csv,
        local_repo_path="./target_repo"
    )
    
    return 0 if success else 1


if __name__ == "__main__":
    sys.exit(main())
