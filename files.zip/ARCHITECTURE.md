# System Architecture Documentation

## 🏛️ High-Level Architecture

```mermaid
graph TB
    subgraph "User Interface Layer"
        UI[User/CLI]
        CSV[Vulnerability CSV]
    end
    
    subgraph "Orchestration Layer"
        ORCH[Integrated Resolver<br/>Main Orchestrator]
    end
    
    subgraph "Core Components"
        GIT[GitHub Repo Manager]
        DEP[Advanced Dependency Analyzer<br/>LLM-based]
        FIX[Enhanced Vulnerability Fixer]
        VAL[Validation Engine]
        DIAG[Flow Diagram Generator]
    end
    
    subgraph "AI Layer"
        GPT[GPT-4o API<br/>OpenAI]
    end
    
    subgraph "Data Layer"
        REPO[Local Repository]
        GRAPH[Dependency Graph]
        REPORTS[Reports & Diagrams]
    end
    
    UI --> CSV
    CSV --> ORCH
    ORCH --> GIT
    ORCH --> DEP
    ORCH --> FIX
    ORCH --> VAL
    ORCH --> DIAG
    
    GIT --> REPO
    DEP --> GPT
    FIX --> GPT
    VAL --> GPT
    DIAG --> GPT
    
    DEP --> GRAPH
    FIX --> REPORTS
    VAL --> REPORTS
    DIAG --> REPORTS
    
    REPO --> GIT
    GRAPH --> FIX
```

## 🔄 Workflow Sequence

```mermaid
sequenceDiagram
    participant User
    participant Orchestrator
    participant GitManager
    participant DepAnalyzer
    participant VulnFixer
    participant Validator
    participant GPT4o
    
    User->>Orchestrator: Start Workflow
    Orchestrator->>GitManager: Clone Repository
    GitManager->>Orchestrator: Repository Ready
    
    Orchestrator->>DepAnalyzer: Analyze All Files
    loop For Each File
        DepAnalyzer->>GPT4o: Analyze Code
        GPT4o->>DepAnalyzer: Dependency Info
    end
    DepAnalyzer->>Orchestrator: Dependency Graph
    
    Orchestrator->>GitManager: Create Branch
    
    loop For Each Vulnerability
        Orchestrator->>VulnFixer: Fix Vulnerability
        VulnFixer->>GPT4o: Analyze Impact
        GPT4o->>VulnFixer: Impact Analysis
        VulnFixer->>GPT4o: Generate Fix
        GPT4o->>VulnFixer: Fixed Code
        VulnFixer->>Validator: Validate Fix
        Validator->>GPT4o: Validate Security
        GPT4o->>Validator: Validation Result
        Validator->>Orchestrator: Fix Ready
    end
    
    Orchestrator->>GitManager: Commit & Push
    GitManager->>User: Changes Pushed
```

## 📦 Component Details

### 1. Integrated Resolver (Main Orchestrator)
**File**: `integrated_resolver.py`

**Responsibilities**:
- Coordinates entire workflow
- Manages component lifecycle
- Error handling and recovery
- Progress tracking and reporting

**Key Methods**:
- `execute_workflow()`: Main entry point
- `_load_vulnerabilities()`: Parse input CSV
- `_generate_comprehensive_report()`: Create final report
- `_generate_flow_diagrams()`: Create visualizations

### 2. GitHub Repository Manager
**File**: `vuln_resolver_agent.py` (GitHubRepoManager class)

**Responsibilities**:
- Clone repositories
- Create and manage branches
- Commit changes
- Push to remote

**Key Methods**:
- `clone_repo()`: Clone from URL
- `create_branch()`: Create new branch
- `commit_changes()`: Stage and commit
- `push_changes()`: Push to remote

### 3. Advanced Dependency Analyzer
**File**: `advanced_dependency_analyzer.py`

**Responsibilities**:
- Multi-language code analysis using LLM
- Build dependency graphs
- Track relationships between files
- Identify transitive dependencies

**Key Methods**:
- `analyze_file_detailed()`: Deep file analysis
- `build_dependency_graph()`: Create full graph
- `find_transitive_dependencies()`: Find indirect deps
- `get_relevant_context_for_vulnerability()`: Extract context

**Analysis Output**:
```json
{
  "file_path": "src/auth.py",
  "language": "Python",
  "imports": [...],
  "classes_defined": [...],
  "functions_defined": [...],
  "internal_file_dependencies": [...],
  "external_dependencies": [...],
  "function_calls": [...],
  "class_instantiations": [...],
  "data_flows": [...]
}
```

### 4. Enhanced Vulnerability Fixer
**File**: `enhanced_vulnerability_fixer.py`

**Responsibilities**:
- Smart context extraction
- Security impact analysis
- Fix generation
- File modification with backup

**Key Methods**:
- `get_smart_context()`: Extract relevant code
- `analyze_vulnerability_impact()`: Analyze severity
- `generate_fix()`: Create secure fix
- `apply_fix_to_file()`: Apply with backup

**Fix Process**:
```mermaid
graph LR
    A[Vulnerability] --> B[Extract Context]
    B --> C[Get Dependencies]
    C --> D[Analyze Impact]
    D --> E[Generate Fix]
    E --> F[Validate]
    F --> G{Valid?}
    G -->|Yes| H[Apply]
    G -->|No| I[Skip/Revise]
```

### 5. Validation Engine
**File**: `enhanced_vulnerability_fixer.py` (validate_fix_comprehensive)

**Validation Checklist**:
1. **Security Validation**
   - Vulnerability addressed?
   - New issues introduced?
   - Attack vectors blocked?

2. **Functionality Validation**
   - Code still works?
   - Edge cases handled?
   - Error handling appropriate?

3. **Dependency Validation**
   - Breaking changes?
   - Function signatures match?
   - Dependent code works?

4. **Code Quality**
   - Maintainable?
   - Best practices followed?
   - Minimal and focused?

5. **Performance**
   - Performance implications?
   - Resource leaks?

**Output**:
```json
{
  "overall_status": "approved|rejected|needs_revision",
  "security_score": 0-100,
  "functionality_score": 0-100,
  "issues_found": [...],
  "recommendations": [...],
  "summary": "..."
}
```

## 🧠 LLM Integration Details

### Context Window Management

**GPT-4o Specifications**:
- Context Window: 128,000 tokens
- Response Buffer: 4,096 tokens
- Available for Input: ~123,000 tokens

**Token Budget Allocation**:
```
┌─────────────────────────────────────────┐
│ Total: 128,000 tokens                   │
├─────────────────────────────────────────┤
│ System Prompts:        2,000 tokens     │
│ Vulnerability Context: 5,000 tokens     │
│ Dependent Files:      10,000 tokens     │
│ Instructions:          1,000 tokens     │
│ Response Buffer:       4,096 tokens     │
│ Safety Margin:         5,904 tokens     │
│ Available:           100,000 tokens     │
└─────────────────────────────────────────┘
```

**Truncation Strategy**:
1. Count tokens using tiktoken
2. If exceeds limit, extract relevant section
3. Include complete functions/classes
4. Preserve line numbers
5. Add context markers

### Multi-Stage Analysis

```mermaid
graph TD
    A[Input Code] --> B[Stage 1: Structure Analysis]
    B --> C[Stage 2: Dependency Extraction]
    C --> D[Stage 3: Relationship Mapping]
    D --> E[Stage 4: Vulnerability Impact]
    E --> F[Stage 5: Fix Generation]
    F --> G[Stage 6: Validation]
    
    B --> GPT1[GPT-4o Call]
    C --> GPT2[GPT-4o Call]
    D --> GPT3[GPT-4o Call]
    E --> GPT4[GPT-4o Call]
    F --> GPT5[GPT-4o Call]
    G --> GPT6[GPT-4o Call]
```

## 📊 Data Flow

```mermaid
graph LR
    subgraph "Input"
        CSV[Vulnerabilities CSV]
        REPO[GitHub Repo]
    end
    
    subgraph "Processing"
        CLONE[Clone Repo]
        ANALYZE[Analyze Dependencies]
        FIX[Generate Fixes]
        VALIDATE[Validate Fixes]
    end
    
    subgraph "Output"
        GRAPH[Dependency Graph JSON]
        DEPS[Dependencies CSV]
        REPORT[Comprehensive Report]
        DIAGRAMS[Flow Diagrams]
        BRANCH[Git Branch]
    end
    
    CSV --> FIX
    REPO --> CLONE
    CLONE --> ANALYZE
    ANALYZE --> GRAPH
    ANALYZE --> DEPS
    ANALYZE --> FIX
    FIX --> VALIDATE
    VALIDATE --> REPORT
    VALIDATE --> DIAGRAMS
    VALIDATE --> BRANCH
```

## 🔒 Security Considerations

### API Key Management
```python
# ✅ Good - Environment Variables
api_key = os.getenv("OPENAI_API_KEY")

# ❌ Bad - Hardcoded
api_key = "sk-abc123..."
```

### File Handling Safety
```python
# Automatic backup before modification
backup_path = file_path.with_suffix(file_path.suffix + '.backup')
with open(backup_path, 'w') as f:
    f.write(original_content)
```

### Branch Strategy
```
main (protected)
  │
  └── security-fix-20240113_120000 (new branch)
      │
      └── Pull Request → Code Review → Merge
```

## 📈 Performance Characteristics

### Time Complexity
- **Repository Clone**: O(repo_size)
- **File Analysis**: O(n * m) where n=files, m=avg_file_size
- **Dependency Graph**: O(n * d) where d=max_dependencies
- **Fix Generation**: O(v * c) where v=vulnerabilities, c=context_size
- **Validation**: O(v)

### Space Complexity
- **Dependency Graph**: O(n * d)
- **Context Storage**: O(v * c)
- **Backup Files**: O(total_file_size)

### API Call Optimization
```python
# Batch similar operations
# Cache dependency analysis results
# Reuse context for related vulnerabilities
```

## 🔧 Extension Points

### Adding New Languages
```python
# In advanced_dependency_analyzer.py
self.language_extensions['.new_ext'] = 'NewLanguage'

# Customize prompts for language-specific patterns
```

### Custom Validators
```python
def custom_security_validator(fix, dep_graph, repo_path):
    # Your validation logic
    return {
        "status": "valid|invalid",
        "score": 0-100,
        "issues": [...]
    }

# Register validator
fixer.validators.append(custom_security_validator)
```

### Plugin Architecture
```python
class VulnerabilityFixerPlugin:
    def before_fix(self, vuln, context): pass
    def after_fix(self, fix): pass
    def validate(self, fix): pass
```

## 📉 Error Handling

### Retry Strategy
```mermaid
graph TD
    A[API Call] --> B{Success?}
    B -->|Yes| C[Continue]
    B -->|No| D{Retryable?}
    D -->|Yes| E[Wait]
    E --> F{Retry Count < Max?}
    F -->|Yes| A
    F -->|No| G[Fail Gracefully]
    D -->|No| G
```

### Failure Recovery
- Automatic backups
- Transaction-like commits
- Partial success handling
- Detailed error logging

## 🎯 Design Principles

1. **Modularity**: Each component has single responsibility
2. **Extensibility**: Easy to add new languages/validators
3. **Safety**: Backups and validation before changes
4. **Transparency**: Detailed reporting and logging
5. **Efficiency**: Context management and caching
6. **Reliability**: Error handling and recovery

## 📚 References

- [OpenAI GPT-4o Documentation](https://platform.openai.com/docs/models/gpt-4o)
- [LangGraph Documentation](https://python.langchain.com/docs/langgraph)
- [tiktoken](https://github.com/openai/tiktoken)
