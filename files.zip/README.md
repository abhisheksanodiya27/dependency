# Agentic Application for Automated Code Vulnerability Resolution

A comprehensive, AI-powered system for automatically detecting, analyzing, and fixing security vulnerabilities in multi-language codebases using GPT-4o and LangGraph.

## 🎯 Overview

This application provides an end-to-end automated workflow for:
- Pulling source code from GitHub repositories
- Analyzing code dependencies using LLM-based approach (no Tree-sitter)
- Identifying vulnerability impacts and dependencies
- Generating secure fixes with GPT-4o
- Validating fixes against security and functionality requirements
- Committing changes to a new Git branch
- Generating flow diagrams for vulnerable code paths

## 🏗️ Architecture

The system uses an agent-based architecture with the following components:

```
┌─────────────────────────────────────────────────────────┐
│              Main Orchestrator                          │
│  (Coordinates entire workflow)                          │
└────────────┬────────────────────────────────────────────┘
             │
             ├─► GitHub Repo Manager
             │   • Clone repository
             │   • Create branch
             │   • Commit & push changes
             │
             ├─► Advanced Dependency Analyzer (LLM-based)
             │   • Multi-language support
             │   • Function-level analysis
             │   • Class relationship tracking
             │   • Transitive dependency resolution
             │
             ├─► Enhanced Vulnerability Fixer
             │   • Context-aware fixing
             │   • Large file handling
             │   • Impact analysis
             │   • Comprehensive validation
             │
             └─► Flow Diagram Generator
                 • Mermaid diagram creation
                 • Vulnerability path visualization
```

## 📋 Features

### 1. Multi-Language Support
- Python, Java, JavaScript, TypeScript, C#, C++, C, Go, Ruby, PHP, Swift, Kotlin, Rust
- Language-specific analysis patterns
- Framework-aware dependency detection

### 2. LLM-Based Dependency Analysis
- **No Tree-sitter dependency** - uses GPT-4o for parsing
- Extracts:
  - Import/include statements
  - Class definitions and inheritance
  - Function definitions and calls
  - Internal file dependencies
  - External package dependencies
  - Data flow patterns
- Builds comprehensive dependency graph

### 3. Smart Context Handling
- **Automatic context window management**
- Extracts relevant code sections for large files
- Includes surrounding functions/classes
- Incorporates dependent file context
- Token counting and truncation

### 4. Comprehensive Vulnerability Fixing
- Security impact analysis
- Attack vector identification
- Multi-stage fix generation:
  1. Analyze vulnerability and impact
  2. Review dependent code
  3. Generate secure fix
  4. Validate fix comprehensively
  5. Apply with backup

### 5. Validation System
- Security validation (attack vectors blocked?)
- Functionality validation (code still works?)
- Dependency validation (breaking changes?)
- Code quality checks
- Performance impact analysis

## 🚀 Installation

```bash
# Clone the repository
git clone <repo-url>
cd vulnerability-resolver

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Set environment variables
export OPENAI_API_KEY="your-openai-api-key"
export GITHUB_TOKEN="your-github-token"  # Optional
```

## 📝 Usage

### Step 1: Prepare Vulnerability CSV

Create a CSV file with the following columns:
- `file_name`: Name of the file
- `file_path`: Relative path from repository root
- `line_number`: Line number of vulnerability
- `vulnerability_type`: Type (e.g., SQL Injection, XSS)
- `description`: Detailed description of the vulnerability

Example:
```csv
file_name,file_path,line_number,vulnerability_type,description
auth.py,src/auth/auth.py,45,SQL Injection,User input concatenated into SQL query
```

Or generate a sample:
```python
from main_orchestrator import create_sample_vulnerability_csv
create_sample_vulnerability_csv("vulnerabilities.csv")
```

### Step 2: Run the Complete Workflow

```python
from main_orchestrator import VulnerabilityResolutionOrchestrator
import os

# Initialize
orchestrator = VulnerabilityResolutionOrchestrator(
    openai_api_key=os.getenv("OPENAI_API_KEY"),
    github_token=os.getenv("GITHUB_TOKEN")
)

# Run workflow
success = orchestrator.run_complete_workflow(
    repo_url="https://github.com/your-org/your-repo.git",
    vulnerabilities_csv="vulnerabilities.csv",
    local_repo_path="./target_repo",
    branch_name="security-fixes-2024"
)
```

### Step 3: Review Results

The system generates:
- `output/dependencies.csv` - Complete dependency analysis
- `output/dependency_graph.json` - Full dependency graph
- `output/vulnerability_resolution_report.md` - Detailed report
- `output/diagrams/` - Flow diagrams for each vulnerability

## 🔧 Advanced Usage

### Custom Dependency Analysis

```python
from advanced_dependency_analyzer import AdvancedDependencyAnalyzer
from vuln_resolver_agent import OpenAIClient

client = OpenAIClient(api_key="your-key")
analyzer = AdvancedDependencyAnalyzer(client)

# Analyze repository
dependency_graph = analyzer.build_dependency_graph(
    repo_path=Path("./repo"),
    file_extensions=['.py', '.java', '.js']
)

# Find transitive dependencies
deps = analyzer.find_transitive_dependencies(
    file_path="src/main.py",
    dependency_graph=dependency_graph,
    max_depth=5
)

# Get context for vulnerability
context = analyzer.get_relevant_context_for_vulnerability(
    vuln_file="src/auth.py",
    vuln_line=45,
    dependency_graph=dependency_graph
)
```

### Manual Vulnerability Fixing

```python
from enhanced_vulnerability_fixer import EnhancedVulnerabilityFixer
from vuln_resolver_agent import VulnerabilityInput

fixer = EnhancedVulnerabilityFixer(client)

vuln = VulnerabilityInput(
    file_name="auth.py",
    file_path="src/auth.py",
    line_number=45,
    vulnerability_type="SQL Injection",
    description="User input in SQL query"
)

# Get smart context
context = fixer.get_smart_context(
    file_path=Path("./repo/src/auth.py"),
    line_number=45,
    dependency_graph=dependency_graph
)

# Analyze impact
impact = fixer.analyze_vulnerability_impact(
    vuln=vuln,
    context=context,
    dependency_graph=dependency_graph
)

# Generate fix
fix = fixer.generate_fix(
    vuln=vuln,
    context=context,
    dependent_code={},
    impact_analysis=impact,
    dependency_graph=dependency_graph
)

# Validate
validation = fixer.validate_fix_comprehensive(
    fix=fix,
    dependency_graph=dependency_graph,
    repo_path=Path("./repo")
)
```

## 📊 Context Limit Handling

The system intelligently manages GPT-4o's context limits:

### For Source Files
- **Token counting**: Uses tiktoken to count tokens
- **Smart truncation**: Preserves structure when truncating
- **Context extraction**: Extracts relevant sections (100 lines around vulnerability)
- **Function-aware**: Includes complete function/class definitions

### For Dependency Files
- **Selective inclusion**: Only includes directly dependent files
- **Size limits**: Truncates large dependencies to 1500-2000 tokens
- **Relevance ranking**: Prioritizes files based on usage

### Token Budget Allocation
```
Total Context: 128,000 tokens (GPT-4o)
├── System Prompt: ~2,000 tokens
├── Vulnerability Context: ~3,000-5,000 tokens
├── Dependent Files: ~5,000-10,000 tokens
├── Analysis Instructions: ~1,000 tokens
└── Response Buffer: 4,096 tokens
```

## 🔐 Security Considerations

### API Key Management
- Store API keys in environment variables
- Never commit keys to version control
- Use `.env` files (added to `.gitignore`)

### Code Validation
- Multiple validation stages before applying fixes
- Backup files created before modification
- Validation scores (0-100) for security and functionality
- Manual review recommended for production systems

### Branch Strategy
- All fixes committed to new branch
- Original code preserved in main branch
- Pull request workflow recommended

## 🎨 Flow Diagram Generation

The system automatically generates Mermaid flow diagrams showing:
- Entry points to vulnerable code
- Data flow paths
- Dependent functions and classes
- Attack vectors
- Fix implementation points

Example output:
```mermaid
graph TD
    A[User Input] -->|Unvalidated| B[SQL Query Builder]
    B --> C{Vulnerability: SQL Injection}
    C -->|Attack Vector| D[Database]
    E[Fix: Parameterized Query] -->|Replaces| B
    E -->|Safe| D
```

## 📈 Performance Optimization

### Batch Processing
- Files analyzed in batches
- Parallel analysis possible (modify code)
- Progress tracking with tqdm

### Caching
- Dependency graphs cached to JSON
- Re-use for multiple vulnerability fixes
- Incremental analysis for large repos

### Rate Limiting
- Built-in rate limit handling
- Exponential backoff for API errors
- Configurable delays between requests

## 🛠️ Troubleshooting

### Common Issues

**Issue**: "Repository clone failed"
- Check GitHub token permissions
- Verify repository URL
- Ensure git is installed

**Issue**: "Context limit exceeded"
- System automatically truncates
- Review truncation warnings in output
- Consider splitting large files

**Issue**: "Validation failed"
- Review validation report
- Check security scores
- Manual review may be needed

**Issue**: "LLM returns invalid JSON"
- System retries with error recovery
- Check OpenAI API status
- Review rate limits

## 📚 Output Files

### dependencies.csv
Complete dependency information for all files:
- File paths
- Imports and dependencies
- Classes and functions defined
- Relationships between files

### dependency_graph.json
Structured dependency graph with:
- Full analysis for each file
- Import chains
- Function call graphs
- Class inheritance trees

### vulnerability_resolution_report.md
Comprehensive report including:
- Summary statistics
- Fix details for each vulnerability
- Validation results
- Dependent files analyzed

## 🧪 Testing

```python
# Run with test repository
python main_orchestrator.py

# Custom test
from main_orchestrator import VulnerabilityResolutionOrchestrator

orchestrator = VulnerabilityResolutionOrchestrator("test-key")
success = orchestrator.run_complete_workflow(
    repo_url="https://github.com/test/test-repo.git",
    vulnerabilities_csv="test_vulns.csv",
    local_repo_path="./test_repo"
)
```

## 🤝 Contributing

Contributions welcome! Areas for improvement:
- Additional language support
- Enhanced validation rules
- Performance optimizations
- UI/Dashboard
- CI/CD integration

## 📄 License

MIT License - See LICENSE file

## 🙏 Acknowledgments

- OpenAI for GPT-4o API
- LangGraph for agent orchestration
- Anthropic Claude for documentation assistance

## 📞 Support

For issues and questions:
1. Check this README
2. Review error messages
3. Check OpenAI API status
4. Open GitHub issue

---

**Note**: This system is designed to assist in vulnerability remediation but should not replace manual security reviews and testing. Always review generated fixes before deploying to production.
