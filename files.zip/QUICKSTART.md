# Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 2: Set Your OpenAI API Key
```bash
export OPENAI_API_KEY="sk-your-api-key-here"
```

### Step 3: Create Sample CSV (Already Done!)
The sample vulnerability CSV has been created: `sample_vulnerabilities.csv`

### Step 4: Run the System

#### Option A: Demo Mode (Recommended First)
```bash
python integrated_resolver.py
```
This will show you how the system works without requiring a real repository.

#### Option B: With Your Repository
```bash
export REPO_URL="https://github.com/your-org/your-repo.git"
export GITHUB_TOKEN="your-github-token"  # Optional, for private repos

python integrated_resolver.py
```

## 📋 What the System Does

1. **Clones** your GitHub repository
2. **Analyzes** all code files using GPT-4o (LLM-based, no Tree-sitter)
3. **Builds** a complete dependency graph
4. **Identifies** relationships between files, functions, and classes
5. **Analyzes** each vulnerability's impact
6. **Generates** secure fixes
7. **Validates** fixes for security and functionality
8. **Applies** approved fixes to files
9. **Creates** flow diagrams
10. **Commits** changes to a new Git branch

## 📊 Sample Output

After running, you'll find:

```
output/
├── dependency_graph.json              # Full dependency analysis
├── dependencies.csv                   # Dependency table
├── reports/
│   ├── comprehensive_report.md       # Main report with all details
│   ├── dependency_analysis_report.md # Dependency breakdown
│   └── validation_*.json             # Validation results
└── diagrams/
    └── vuln_*_*.md                   # Flow diagrams (Mermaid)
```

## 🔍 Understanding the Sample Vulnerabilities

The sample CSV includes 5 common vulnerability types:

1. **SQL Injection** (auth.py:45)
   - User input directly in SQL query
   - Should use parameterized queries

2. **Hardcoded Credentials** (database.py:78)
   - Password in source code
   - Should use environment variables

3. **XSS - Cross-Site Scripting** (api_handler.py:120)
   - Unsanitized user data in HTML
   - Should sanitize/escape output

4. **Insecure Deserialization** (user_controller.cs:56)
   - Unvalidated deserialization
   - Should validate input before deserializing

5. **Path Traversal** (data_service.java:89)
   - User input in file paths
   - Should validate and sanitize paths

## 🎯 Key Features

### 1. LLM-Based Dependency Analysis
- **No Tree-sitter required** - uses GPT-4o for parsing
- Supports 13+ programming languages
- Extracts:
  - Classes and functions
  - Import statements
  - Dependencies between files
  - Function calls and data flows

### 2. Smart Context Handling
- Automatically manages GPT-4o's 128K token limit
- Extracts relevant code sections
- Includes dependent file context
- Function-aware truncation

### 3. Comprehensive Validation
- Security score (0-100)
- Functionality score (0-100)
- Dependency impact analysis
- Breaking change detection

### 4. Safety Features
- Automatic file backups
- New Git branch for changes
- Validation before applying
- Detailed audit trail

## 🔧 Customization

### Use Your Own Vulnerability List
Create a CSV with these columns:
```csv
file_name,file_path,line_number,vulnerability_type,description
myfile.py,src/myfile.py,42,SQL Injection,Description here
```

### Analyze Specific File Types
```python
from advanced_dependency_analyzer import AdvancedDependencyAnalyzer

analyzer = AdvancedDependencyAnalyzer(client)
dependency_graph = analyzer.build_dependency_graph(
    repo_path=Path("./repo"),
    file_extensions=['.py', '.js']  # Only Python and JavaScript
)
```

### Adjust Context Size
```python
from enhanced_vulnerability_fixer import EnhancedVulnerabilityFixer

fixer = EnhancedVulnerabilityFixer(client)
fixer.context_window_lines = 150  # Increase from default 100
```

## 📈 Performance Tips

### For Large Repositories
- Process specific directories only
- Increase batch sizes
- Use file filtering

### For Cost Optimization
- Analyze only files with known vulnerabilities
- Use dependency caching
- Implement incremental analysis

### For Rate Limits
- Built-in exponential backoff
- Add delays if needed
- Consider Azure OpenAI for higher limits

## ⚠️ Important Notes

1. **API Costs**: GPT-4o API calls cost money. Estimate ~$0.01-0.05 per file analyzed.

2. **Review Fixes**: Always review generated fixes before deploying to production.

3. **Test Changes**: Run your test suite after applying fixes.

4. **Backup Strategy**: Original files are backed up automatically with .backup extension.

5. **Git Workflow**: Changes are committed to a new branch. Create a PR for review.

## 🐛 Troubleshooting

### "OPENAI_API_KEY not set"
```bash
export OPENAI_API_KEY="your-key-here"
```

### "Repository clone failed"
- Check repository URL
- Verify GitHub token (for private repos)
- Ensure git is installed

### "Context limit exceeded"
- System automatically truncates
- Check truncation warnings
- Consider reducing context_window_lines

### "Rate limit hit"
- Built-in retry logic
- Add delays: `time.sleep(1)`
- Check OpenAI API status

## 📚 Next Steps

1. **Read the README**: Detailed architecture and design
2. **Review CONFIGURATION.md**: Advanced configuration options
3. **Check Output Files**: Understand the reports and diagrams
4. **Customize**: Adapt to your specific needs
5. **Integrate**: Add to your CI/CD pipeline

## 🤝 Getting Help

1. Check error messages (they're detailed)
2. Review the comprehensive report in `output/reports/`
3. Look at validation results in JSON files
4. Check the README for detailed explanations

## ✅ Checklist

Before running on production code:

- [ ] OpenAI API key is set
- [ ] Sample run completed successfully
- [ ] Understood the output structure
- [ ] Reviewed sample fixes
- [ ] Prepared vulnerability CSV
- [ ] Repository URL is correct
- [ ] GitHub token is set (if needed)
- [ ] Ready to review fixes manually
- [ ] Test suite is ready to run

## 🎉 Success!

If you've completed a run, congratulations! You now have:
- ✅ Complete dependency analysis
- ✅ Security vulnerability fixes
- ✅ Validation reports
- ✅ Flow diagrams
- ✅ Git branch with changes

Review the output and create a pull request for team review.

---

**Need more help?** Check README.md and CONFIGURATION.md for detailed information.
