"""
Advanced Dependency Analyzer
Uses LLM-based approach for comprehensive dependency analysis across multiple languages
"""

import json
from typing import Dict, List, Set, Tuple, Optional
from pathlib import Path
from dataclasses import dataclass, asdict
import re

from vuln_resolver_agent import OpenAIClient, DependencyInfo


@dataclass
class FunctionCall:
    """Represents a function call in code"""
    caller_file: str
    caller_function: str
    called_file: str
    called_function: str
    line_number: int


@dataclass
class ClassUsage:
    """Represents usage of a class"""
    using_file: str
    using_context: str  # function/class using it
    class_file: str
    class_name: str
    line_number: int


class AdvancedDependencyAnalyzer:
    """Advanced dependency analyzer using LLM for multi-language support"""
    
    def __init__(self, openai_client: OpenAIClient):
        self.client = openai_client
        self.language_extensions = {
            '.py': 'Python',
            '.java': 'Java',
            '.js': 'JavaScript',
            '.ts': 'TypeScript',
            '.cs': 'C#',
            '.cpp': 'C++',
            '.c': 'C',
            '.go': 'Go',
            '.rb': 'Ruby',
            '.php': 'PHP',
            '.swift': 'Swift',
            '.kt': 'Kotlin',
            '.rs': 'Rust'
        }
    
    def detect_language(self, file_path: Path) -> Optional[str]:
        """Detect programming language from file extension"""
        return self.language_extensions.get(file_path.suffix)
    
    def analyze_file_detailed(self, file_path: Path, file_content: str,
                              repo_path: Path, all_files: Set[str]) -> Dict:
        """Detailed analysis of a single file"""
        
        relative_path = str(file_path.relative_to(repo_path))
        language = self.detect_language(file_path)
        
        if not language:
            return None
        
        # Truncate if needed
        content_tokens = self.client.count_tokens(file_content)
        available_tokens = self.client.max_tokens - self.client.response_tokens - 3000
        
        if content_tokens > available_tokens:
            file_content = self.client.truncate_to_fit(file_content, available_tokens)
        
        # Create a list of other files for reference
        other_files_list = [f for f in all_files if f != relative_path][:50]
        
        prompt = f"""Analyze this {language} source code file and extract comprehensive dependency information.

File: {relative_path}

Code:
```{language.lower()}
{file_content}
```

Other files in repository (for reference):
{chr(10).join(other_files_list[:30])}

Provide detailed analysis in JSON format:
{{
    "imports": [
        {{"statement": "import statement", "module": "module name", "items": ["imported items"]}}
    ],
    "classes_defined": [
        {{"name": "ClassName", "inherits_from": ["ParentClass"], "line_number": 10}}
    ],
    "functions_defined": [
        {{"name": "function_name", "parameters": ["param1", "param2"], "line_number": 20}}
    ],
    "external_dependencies": [
        {{"type": "package/module", "name": "dependency_name"}}
    ],
    "internal_file_dependencies": [
        {{"file": "relative/path/to/file.ext", "reason": "imports Class/Function"}}
    ],
    "function_calls": [
        {{"function": "function_name", "called_from": "caller_function", "line": 30}}
    ],
    "class_instantiations": [
        {{"class": "ClassName", "location": "function_name", "line": 40}}
    ],
    "global_variables": [
        {{"name": "var_name", "type": "var_type", "line": 5}}
    ],
    "data_flows": [
        {{"from": "source", "to": "destination", "through": "intermediate"}}
    ]
}}

Be extremely thorough. Analyze:
1. All import/include/using statements
2. All class and function definitions with line numbers
3. Internal dependencies (files in this repo)
4. External dependencies (packages/libraries)
5. Function call chains
6. Class instantiations and inheritance
7. Data flow between components
"""
        
        messages = [
            {"role": "system", "content": f"You are an expert {language} code analyzer. Provide comprehensive, accurate dependency analysis."},
            {"role": "user", "content": prompt}
        ]
        
        try:
            response = self.client.chat_completion(messages, temperature=0.0)
            
            # Extract JSON
            json_start = response.find("{")
            json_end = response.rfind("}") + 1
            
            if json_start == -1 or json_end == 0:
                print(f"Warning: No JSON found in response for {relative_path}")
                return None
            
            json_str = response[json_start:json_end]
            data = json.loads(json_str)
            
            # Add metadata
            data['file_path'] = relative_path
            data['language'] = language
            
            return data
            
        except json.JSONDecodeError as e:
            print(f"JSON decode error for {relative_path}: {str(e)}")
            return None
        except Exception as e:
            print(f"Error analyzing {relative_path}: {str(e)}")
            return None
    
    def build_dependency_graph(self, repo_path: Path, 
                              file_extensions: Optional[List[str]] = None) -> Dict:
        """Build complete dependency graph for repository"""
        
        if file_extensions is None:
            file_extensions = list(self.language_extensions.keys())
        
        # Get all files
        all_files = []
        for ext in file_extensions:
            all_files.extend(repo_path.rglob(f"*{ext}"))
        
        # Filter out .git and common ignore patterns
        all_files = [
            f for f in all_files 
            if '.git' not in str(f) and 'node_modules' not in str(f)
            and '__pycache__' not in str(f) and 'venv' not in str(f)
        ]
        
        all_files_set = {str(f.relative_to(repo_path)) for f in all_files}
        
        print(f"Found {len(all_files)} files to analyze")
        
        # Analyze each file
        dependency_graph = {}
        
        for idx, file_path in enumerate(all_files, 1):
            print(f"Analyzing {idx}/{len(all_files)}: {file_path.name}")
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                analysis = self.analyze_file_detailed(
                    file_path, content, repo_path, all_files_set
                )
                
                if analysis:
                    dependency_graph[analysis['file_path']] = analysis
                    
            except Exception as e:
                print(f"Error processing {file_path}: {str(e)}")
        
        return dependency_graph
    
    def extract_dependency_relationships(self, dependency_graph: Dict) -> Dict:
        """Extract specific relationships from dependency graph"""
        
        relationships = {
            'file_to_file': {},  # file -> [dependent files]
            'function_calls': [],  # all function calls
            'class_usages': [],  # all class usages
            'import_chains': {}  # file -> imported items
        }
        
        for file_path, analysis in dependency_graph.items():
            # File-to-file dependencies
            deps = []
            if 'internal_file_dependencies' in analysis:
                deps = [d['file'] for d in analysis['internal_file_dependencies']]
            relationships['file_to_file'][file_path] = deps
            
            # Import chains
            if 'imports' in analysis:
                relationships['import_chains'][file_path] = analysis['imports']
        
        return relationships
    
    def find_transitive_dependencies(self, file_path: str, 
                                     dependency_graph: Dict,
                                     max_depth: int = 5) -> Set[str]:
        """Find all transitive dependencies of a file"""
        
        visited = set()
        to_visit = [(file_path, 0)]
        
        while to_visit:
            current_file, depth = to_visit.pop(0)
            
            if current_file in visited or depth >= max_depth:
                continue
            
            visited.add(current_file)
            
            if current_file not in dependency_graph:
                continue
            
            analysis = dependency_graph[current_file]
            
            if 'internal_file_dependencies' in analysis:
                for dep in analysis['internal_file_dependencies']:
                    dep_file = dep['file']
                    if dep_file not in visited:
                        to_visit.append((dep_file, depth + 1))
        
        visited.discard(file_path)  # Remove self
        return visited
    
    def get_relevant_context_for_vulnerability(self, vuln_file: str, 
                                               vuln_line: int,
                                               dependency_graph: Dict,
                                               max_context_files: int = 10) -> Dict:
        """Get relevant code context for fixing a vulnerability"""
        
        if vuln_file not in dependency_graph:
            return {
                'direct_dependencies': [],
                'transitive_dependencies': [],
                'relevant_functions': [],
                'relevant_classes': []
            }
        
        analysis = dependency_graph[vuln_file]
        
        # Find transitive dependencies
        transitive_deps = self.find_transitive_dependencies(vuln_file, dependency_graph)
        
        # Find direct dependencies
        direct_deps = []
        if 'internal_file_dependencies' in analysis:
            direct_deps = [d['file'] for d in analysis['internal_file_dependencies']]
        
        # Find functions/classes near vulnerability line
        relevant_functions = []
        relevant_classes = []
        
        if 'functions_defined' in analysis:
            for func in analysis['functions_defined']:
                if abs(func.get('line_number', 0) - vuln_line) < 50:
                    relevant_functions.append(func)
        
        if 'classes_defined' in analysis:
            for cls in analysis['classes_defined']:
                if abs(cls.get('line_number', 0) - vuln_line) < 100:
                    relevant_classes.append(cls)
        
        return {
            'direct_dependencies': direct_deps[:max_context_files],
            'transitive_dependencies': list(transitive_deps)[:max_context_files],
            'relevant_functions': relevant_functions,
            'relevant_classes': relevant_classes,
            'language': analysis.get('language', 'Unknown')
        }
    
    def save_dependency_graph(self, dependency_graph: Dict, output_path: str):
        """Save dependency graph to JSON file"""
        
        with open(output_path, 'w') as f:
            json.dump(dependency_graph, f, indent=2)
        
        print(f"Dependency graph saved to {output_path}")
    
    def generate_dependency_report(self, dependency_graph: Dict, 
                                   output_path: str):
        """Generate human-readable dependency report"""
        
        with open(output_path, 'w') as f:
            f.write("# Repository Dependency Analysis Report\n\n")
            f.write(f"Total Files Analyzed: {len(dependency_graph)}\n\n")
            
            # Language breakdown
            languages = {}
            for analysis in dependency_graph.values():
                lang = analysis.get('language', 'Unknown')
                languages[lang] = languages.get(lang, 0) + 1
            
            f.write("## Language Breakdown\n\n")
            for lang, count in sorted(languages.items(), key=lambda x: -x[1]):
                f.write(f"- {lang}: {count} files\n")
            f.write("\n")
            
            # Detailed file analysis
            f.write("## File-by-File Analysis\n\n")
            
            for file_path, analysis in sorted(dependency_graph.items()):
                f.write(f"### {file_path}\n\n")
                f.write(f"**Language:** {analysis.get('language', 'Unknown')}\n\n")
                
                if 'classes_defined' in analysis and analysis['classes_defined']:
                    f.write(f"**Classes Defined:** {len(analysis['classes_defined'])}\n")
                    for cls in analysis['classes_defined'][:5]:
                        f.write(f"  - {cls['name']} (line {cls.get('line_number', '?')})\n")
                    f.write("\n")
                
                if 'functions_defined' in analysis and analysis['functions_defined']:
                    f.write(f"**Functions Defined:** {len(analysis['functions_defined'])}\n")
                    for func in analysis['functions_defined'][:5]:
                        f.write(f"  - {func['name']} (line {func.get('line_number', '?')})\n")
                    f.write("\n")
                
                if 'internal_file_dependencies' in analysis and analysis['internal_file_dependencies']:
                    f.write(f"**Internal Dependencies:**\n")
                    for dep in analysis['internal_file_dependencies'][:10]:
                        f.write(f"  - {dep['file']}: {dep.get('reason', 'N/A')}\n")
                    f.write("\n")
                
                if 'external_dependencies' in analysis and analysis['external_dependencies']:
                    f.write(f"**External Dependencies:**\n")
                    for dep in analysis['external_dependencies'][:10]:
                        f.write(f"  - {dep['name']} ({dep['type']})\n")
                    f.write("\n")
                
                f.write("---\n\n")
        
        print(f"Dependency report saved to {output_path}")


if __name__ == "__main__":
    print("Advanced Dependency Analyzer - Module loaded")
