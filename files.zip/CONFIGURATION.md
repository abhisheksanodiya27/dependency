# Configuration File for Vulnerability Resolution System

## Environment Variables Template
# Copy this to .env and fill in your values

```bash
# Required: OpenAI API Key for GPT-4o
OPENAI_API_KEY=your-openai-api-key-here

# Optional: GitHub Personal Access Token (for private repos)
GITHUB_TOKEN=your-github-token-here

# Repository Configuration
REPO_URL=https://github.com/your-org/your-repo.git
LOCAL_REPO_PATH=./target_repo

# Branch Configuration
BRANCH_PREFIX=security-fix

# Output Configuration
OUTPUT_DIR=output
```

## Configuration Parameters

### OpenAI Configuration
- **Model**: gpt-4o (default)
- **Max Tokens**: 128000 (context window)
- **Response Tokens**: 4096
- **Temperature**: 0.0-0.1 (for deterministic outputs)

### Dependency Analysis Configuration
- **File Extensions**: ['.py', '.java', '.js', '.ts', '.cs', '.cpp', '.c', '.go', '.rb', '.php', '.swift', '.kt', '.rs']
- **Max Depth for Transitive Dependencies**: 5
- **Max Dependent Files per Vulnerability**: 10

### Context Window Management
- **Context Lines Around Vulnerability**: 100
- **Max Tokens per Dependency File**: 1500-2000
- **Function-aware Context**: Yes
- **Auto-truncation**: Enabled

### Validation Configuration
- **Security Score Threshold**: 70/100
- **Functionality Score Threshold**: 80/100
- **Validation Stages**: 5 (Security, Functionality, Dependencies, Code Quality, Performance)

### Git Configuration
- **Auto-commit**: Yes
- **Auto-push**: Yes
- **Create Backups**: Yes
- **Backup Extension**: .backup

## Usage Examples

### Basic Usage
```bash
# Set environment variables
export OPENAI_API_KEY="sk-..."
export REPO_URL="https://github.com/myorg/myrepo.git"

# Run the integrated resolver
python integrated_resolver.py
```

### Advanced Usage
```python
from integrated_resolver import IntegratedVulnerabilityResolver

resolver = IntegratedVulnerabilityResolver(
    openai_api_key="your-key",
    github_token="your-token"
)

success = resolver.execute_workflow(
    repo_url="https://github.com/myorg/myrepo.git",
    vulnerabilities_csv="my_vulns.csv",
    local_repo_path="./my_repo",
    branch_name="custom-security-fixes"
)
```

### Custom Dependency Analysis
```python
from advanced_dependency_analyzer import AdvancedDependencyAnalyzer
from vuln_resolver_agent import OpenAIClient

client = OpenAIClient(api_key="your-key")
analyzer = AdvancedDependencyAnalyzer(client)

# Analyze specific file types
dependency_graph = analyzer.build_dependency_graph(
    repo_path=Path("./repo"),
    file_extensions=['.py', '.java']  # Only Python and Java
)

# Find dependencies for a specific file
deps = analyzer.find_transitive_dependencies(
    file_path="src/main.py",
    dependency_graph=dependency_graph,
    max_depth=3
)
```

## Output Structure

```
output/
├── dependency_graph.json          # Complete dependency graph
├── dependencies.csv               # Dependency table
├── reports/
│   ├── comprehensive_report.md   # Main report
│   ├── dependency_analysis_report.md
│   └── validation_*.json         # Individual validation results
├── diagrams/
│   └── vuln_*_*.md              # Flow diagrams
└── backups/
    └── *.backup                  # Original file backups
```

## Performance Tuning

### For Large Repositories (1000+ files)
- Consider processing in batches
- Increase context window limits if needed
- Use file filtering to focus on specific directories

### For Rate Limit Issues
- Implement exponential backoff (built-in)
- Add delays between requests
- Consider using Azure OpenAI with higher limits

### For Cost Optimization
- Filter file types to only those with vulnerabilities
- Use caching for dependency analysis
- Implement incremental analysis

## Troubleshooting

### Common Issues and Solutions

**API Rate Limits**
```python
# Add delay between requests
import time
time.sleep(1)  # 1 second between API calls
```

**Large File Handling**
```python
# Adjust context window
fixer.context_window_lines = 50  # Reduce from default 100
```

**Memory Issues**
```python
# Process files in smaller batches
batch_size = 10
for i in range(0, len(files), batch_size):
    batch = files[i:i+batch_size]
    # Process batch
```

## Security Best Practices

1. **API Keys**: Never commit API keys to version control
2. **Validation**: Always review fixes before deploying
3. **Testing**: Run tests after applying fixes
4. **Backups**: Keep original files (automatic)
5. **Branch Strategy**: Use feature branches (automatic)

## Integration with CI/CD

### GitHub Actions Example
```yaml
name: Vulnerability Scan and Fix

on:
  schedule:
    - cron: '0 0 * * 0'  # Weekly

jobs:
  fix-vulnerabilities:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      
      - name: Set up Python
        uses: actions/setup-python@v2
        with:
          python-version: '3.9'
      
      - name: Install dependencies
        run: |
          pip install -r requirements.txt
      
      - name: Run vulnerability fixer
        env:
          OPENAI_API_KEY: ${{ secrets.OPENAI_API_KEY }}
        run: |
          python integrated_resolver.py
      
      - name: Create Pull Request
        uses: peter-evans/create-pull-request@v4
        with:
          title: 'Security: Automated vulnerability fixes'
          branch: security-fixes
```

## Extending the System

### Adding New Languages
```python
# In advanced_dependency_analyzer.py
self.language_extensions['.scala'] = 'Scala'
self.language_extensions['.r'] = 'R'
```

### Custom Validation Rules
```python
def custom_validation(fix, dependency_graph, repo_path):
    # Your custom validation logic
    pass

# Use in workflow
fixer.custom_validators.append(custom_validation)
```

### Adding New Vulnerability Types
Update the CSV with new types:
```csv
file_name,file_path,line_number,vulnerability_type,description
config.py,src/config.py,23,Weak Cryptography,Using MD5 for password hashing
```

## Support and Resources

- **Documentation**: README.md
- **Examples**: integrated_resolver.py
- **Issues**: Check error messages and logs
- **API Status**: https://status.openai.com/

## License

MIT License - See LICENSE file for details
