"""
Agentic Application for Automated Code Vulnerability Resolution
Orchestrates multiple agents for dependency analysis, vulnerability fixing, and validation
"""

import os
import json
import csv
import asyncio
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import dataclass, asdict
from pathlib import Path
import subprocess
from datetime import datetime

import openai
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolExecutor
from langchain_core.messages import HumanMessage, AIMessage, SystemMessage
import pandas as pd
import tiktoken


@dataclass
class VulnerabilityInput:
    """Structure for vulnerability input from CSV"""
    file_name: str
    file_path: str
    line_number: int
    vulnerability_type: str
    description: str


@dataclass
class DependencyInfo:
    """Structure for dependency information"""
    file_path: str
    imports: List[str]
    classes_defined: List[str]
    functions_defined: List[str]
    dependencies: List[str]
    classes_used_from: Dict[str, List[str]]  # {source_file: [class_names]}
    functions_used_from: Dict[str, List[str]]  # {source_file: [function_names]}


@dataclass
class VulnerabilityFix:
    """Structure for vulnerability fix result"""
    file_path: str
    line_number: int
    vulnerability_type: str
    original_code: str
    fixed_code: str
    explanation: str
    dependent_files_analyzed: List[str]
    validation_status: str


@dataclass
class AgentState:
    """State for the agent workflow"""
    repo_path: str
    vulnerabilities: List[VulnerabilityInput]
    dependencies: Dict[str, DependencyInfo]
    fixes: List[VulnerabilityFix]
    current_vulnerability: Optional[VulnerabilityInput]
    error: Optional[str]
    stage: str  # 'init', 'clone', 'analyze', 'fix', 'validate', 'commit', 'done'


class OpenAIClient:
    """Wrapper for OpenAI API with context management"""
    
    def __init__(self, api_key: str, model: str = "gpt-4o"):
        self.client = openai.OpenAI(api_key=api_key)
        self.model = model
        self.encoding = tiktoken.encoding_for_model(model)
        self.max_tokens = 128000  # GPT-4o context limit
        self.response_tokens = 4096  # Reserve for response
    
    def count_tokens(self, text: str) -> int:
        """Count tokens in text"""
        return len(self.encoding.encode(text))
    
    def truncate_to_fit(self, text: str, max_tokens: int) -> str:
        """Truncate text to fit within token limit"""
        tokens = self.encoding.encode(text)
        if len(tokens) <= max_tokens:
            return text
        return self.encoding.decode(tokens[:max_tokens])
    
    def chat_completion(self, messages: List[Dict[str, str]], 
                       temperature: float = 0.1) -> str:
        """Get chat completion from OpenAI"""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                temperature=temperature,
                max_tokens=self.response_tokens
            )
            return response.choices[0].message.content
        except Exception as e:
            raise Exception(f"OpenAI API error: {str(e)}")


class GitHubRepoManager:
    """Manages GitHub repository operations"""
    
    def __init__(self, repo_url: str, local_path: str, github_token: Optional[str] = None):
        self.repo_url = repo_url
        self.local_path = Path(local_path)
        self.github_token = github_token
    
    def clone_repo(self) -> bool:
        """Clone repository to local path"""
        try:
            if self.local_path.exists():
                print(f"Repository already exists at {self.local_path}")
                return True
            
            # Add token to URL if provided
            repo_url = self.repo_url
            if self.github_token:
                repo_url = repo_url.replace(
                    "https://", 
                    f"https://{self.github_token}@"
                )
            
            subprocess.run(
                ["git", "clone", repo_url, str(self.local_path)],
                check=True,
                capture_output=True
            )
            print(f"Successfully cloned repository to {self.local_path}")
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error cloning repository: {e.stderr.decode()}")
            return False
    
    def create_branch(self, branch_name: str) -> bool:
        """Create and checkout new branch"""
        try:
            subprocess.run(
                ["git", "checkout", "-b", branch_name],
                cwd=self.local_path,
                check=True,
                capture_output=True
            )
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error creating branch: {e.stderr.decode()}")
            return False
    
    def commit_changes(self, message: str) -> bool:
        """Commit changes"""
        try:
            subprocess.run(
                ["git", "add", "."],
                cwd=self.local_path,
                check=True
            )
            subprocess.run(
                ["git", "commit", "-m", message],
                cwd=self.local_path,
                check=True
            )
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error committing changes: {e.stderr.decode()}")
            return False
    
    def push_changes(self, branch_name: str) -> bool:
        """Push changes to remote"""
        try:
            subprocess.run(
                ["git", "push", "origin", branch_name],
                cwd=self.local_path,
                check=True,
                capture_output=True
            )
            return True
        except subprocess.CalledProcessError as e:
            print(f"Error pushing changes: {e.stderr.decode()}")
            return False
    
    def get_all_files(self, extensions: Optional[List[str]] = None) -> List[Path]:
        """Get all code files in repository"""
        files = []
        for file_path in self.local_path.rglob("*"):
            if file_path.is_file():
                if extensions is None or file_path.suffix in extensions:
                    if ".git" not in str(file_path):
                        files.append(file_path)
        return files


class DependencyAnalyzer:
    """Analyzes code dependencies using LLM"""
    
    def __init__(self, openai_client: OpenAIClient):
        self.client = openai_client
    
    def analyze_file(self, file_path: Path, file_content: str, 
                     repo_path: Path) -> DependencyInfo:
        """Analyze a single file for dependencies using LLM"""
        
        relative_path = str(file_path.relative_to(repo_path))
        
        # Check if content fits in context
        content_tokens = self.client.count_tokens(file_content)
        available_tokens = self.client.max_tokens - self.client.response_tokens - 2000
        
        if content_tokens > available_tokens:
            # Truncate file content
            file_content = self.client.truncate_to_fit(file_content, available_tokens)
            print(f"Warning: {relative_path} truncated to fit context window")
        
        prompt = f"""Analyze the following code file and extract dependency information.

File: {relative_path}

Code:
```
{file_content}
```

Provide the analysis in JSON format with the following structure:
{{
    "imports": ["list of import statements"],
    "classes_defined": ["list of class names defined in this file"],
    "functions_defined": ["list of function names defined in this file"],
    "dependencies": ["list of file paths this file depends on"],
    "classes_used_from": {{"source_file": ["class_names"]}},
    "functions_used_from": {{"source_file": ["function_names"]}}
}}

Be thorough in identifying:
1. All import/include statements
2. All classes and functions defined
3. External dependencies (files, modules, packages)
4. Which specific classes/functions are used from other files
"""
        
        messages = [
            {"role": "system", "content": "You are a code analysis expert. Analyze code dependencies accurately and provide structured output."},
            {"role": "user", "content": prompt}
        ]
        
        try:
            response = self.client.chat_completion(messages)
            
            # Extract JSON from response
            json_start = response.find("{")
            json_end = response.rfind("}") + 1
            json_str = response[json_start:json_end]
            
            data = json.loads(json_str)
            
            return DependencyInfo(
                file_path=relative_path,
                imports=data.get("imports", []),
                classes_defined=data.get("classes_defined", []),
                functions_defined=data.get("functions_defined", []),
                dependencies=data.get("dependencies", []),
                classes_used_from=data.get("classes_used_from", {}),
                functions_used_from=data.get("functions_used_from", {})
            )
        except Exception as e:
            print(f"Error analyzing {relative_path}: {str(e)}")
            return DependencyInfo(
                file_path=relative_path,
                imports=[],
                classes_defined=[],
                functions_defined=[],
                dependencies=[],
                classes_used_from={},
                functions_used_from={}
            )
    
    def analyze_repository(self, repo_path: Path, 
                          file_extensions: Optional[List[str]] = None) -> Dict[str, DependencyInfo]:
        """Analyze all files in repository"""
        
        if file_extensions is None:
            # Default extensions for common languages
            file_extensions = ['.py', '.java', '.js', '.ts', '.cs', '.cpp', '.c', '.go']
        
        repo_manager = GitHubRepoManager(repo_url="", local_path=str(repo_path))
        files = repo_manager.get_all_files(extensions=file_extensions)
        
        dependencies = {}
        total_files = len(files)
        
        for idx, file_path in enumerate(files, 1):
            print(f"Analyzing {idx}/{total_files}: {file_path.name}")
            
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                dep_info = self.analyze_file(file_path, content, repo_path)
                dependencies[dep_info.file_path] = dep_info
            except Exception as e:
                print(f"Error reading {file_path}: {str(e)}")
        
        return dependencies
    
    def save_dependencies_to_csv(self, dependencies: Dict[str, DependencyInfo], 
                                 output_path: str):
        """Save dependency information to CSV"""
        
        rows = []
        for file_path, dep_info in dependencies.items():
            row = {
                'file_path': file_path,
                'imports': '; '.join(dep_info.imports),
                'classes_defined': '; '.join(dep_info.classes_defined),
                'functions_defined': '; '.join(dep_info.functions_defined),
                'dependencies': '; '.join(dep_info.dependencies),
                'classes_used_from': json.dumps(dep_info.classes_used_from),
                'functions_used_from': json.dumps(dep_info.functions_used_from)
            }
            rows.append(row)
        
        df = pd.DataFrame(rows)
        df.to_csv(output_path, index=False)
        print(f"Dependency information saved to {output_path}")


class VulnerabilityFixer:
    """Fixes vulnerabilities using LLM"""
    
    def __init__(self, openai_client: OpenAIClient):
        self.client = openai_client
    
    def get_code_context(self, file_path: Path, line_number: int, 
                         context_lines: int = 50) -> Tuple[str, int, int]:
        """Get code context around vulnerability with line numbers"""
        
        with open(file_path, 'r', encoding='utf-8') as f:
            lines = f.readlines()
        
        total_lines = len(lines)
        start_line = max(0, line_number - context_lines)
        end_line = min(total_lines, line_number + context_lines)
        
        context = ''.join(lines[start_line:end_line])
        
        return context, start_line + 1, end_line
    
    def get_dependent_code(self, file_path: str, dependencies: Dict[str, DependencyInfo],
                          repo_path: Path) -> Dict[str, str]:
        """Get code from dependent files"""
        
        dependent_code = {}
        
        if file_path not in dependencies:
            return dependent_code
        
        dep_info = dependencies[file_path]
        
        for dep_file in dep_info.dependencies[:5]:  # Limit to top 5 dependencies
            dep_path = repo_path / dep_file
            if dep_path.exists():
                try:
                    with open(dep_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    
                    # Truncate if too large
                    tokens = self.client.count_tokens(content)
                    if tokens > 2000:
                        content = self.client.truncate_to_fit(content, 2000)
                    
                    dependent_code[dep_file] = content
                except Exception as e:
                    print(f"Error reading dependent file {dep_file}: {str(e)}")
        
        return dependent_code
    
    def fix_vulnerability(self, vuln: VulnerabilityInput, repo_path: Path,
                         dependencies: Dict[str, DependencyInfo]) -> VulnerabilityFix:
        """Fix a single vulnerability"""
        
        file_path = repo_path / vuln.file_path
        
        # Get code context
        code_context, start_line, end_line = self.get_code_context(
            file_path, vuln.line_number
        )
        
        # Get dependent code
        dependent_code = self.get_dependent_code(
            vuln.file_path, dependencies, repo_path
        )
        
        # Build prompt
        dependent_code_str = ""
        if dependent_code:
            dependent_code_str = "\n\nDependent Files:\n"
            for dep_file, dep_content in dependent_code.items():
                dependent_code_str += f"\n--- {dep_file} ---\n{dep_content}\n"
        
        prompt = f"""Fix the following security vulnerability in the code.

File: {vuln.file_path}
Line: {vuln.line_number}
Vulnerability Type: {vuln.vulnerability_type}
Description: {vuln.description}

Code Context (lines {start_line}-{end_line}):
```
{code_context}
```
{dependent_code_str}

Provide the fix in JSON format:
{{
    "fixed_code": "complete fixed code snippet",
    "explanation": "detailed explanation of the fix",
    "impact_analysis": "analysis of how this fix affects dependent code"
}}

Requirements:
1. Ensure the fix doesn't break dependencies or application flow
2. Analyze execution flow and data flow
3. Provide complete, working code
4. Consider security best practices
"""
        
        messages = [
            {"role": "system", "content": "You are a security expert specializing in vulnerability remediation. Provide secure, working fixes."},
            {"role": "user", "content": prompt}
        ]
        
        try:
            response = self.client.chat_completion(messages)
            
            # Extract JSON
            json_start = response.find("{")
            json_end = response.rfind("}") + 1
            json_str = response[json_start:json_end]
            data = json.loads(json_str)
            
            return VulnerabilityFix(
                file_path=vuln.file_path,
                line_number=vuln.line_number,
                vulnerability_type=vuln.vulnerability_type,
                original_code=code_context,
                fixed_code=data["fixed_code"],
                explanation=data["explanation"],
                dependent_files_analyzed=list(dependent_code.keys()),
                validation_status="pending"
            )
        except Exception as e:
            return VulnerabilityFix(
                file_path=vuln.file_path,
                line_number=vuln.line_number,
                vulnerability_type=vuln.vulnerability_type,
                original_code=code_context,
                fixed_code="",
                explanation=f"Error: {str(e)}",
                dependent_files_analyzed=[],
                validation_status="failed"
            )
    
    def apply_fix(self, fix: VulnerabilityFix, repo_path: Path) -> bool:
        """Apply fix to file"""
        
        if not fix.fixed_code or fix.validation_status == "failed":
            return False
        
        file_path = repo_path / fix.file_path
        
        try:
            # Read original file
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # For now, append fixed code as a comment
            # In production, you'd use more sophisticated patching
            backup_path = file_path.with_suffix(file_path.suffix + '.bak')
            with open(backup_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            # Write fixed code (simplified - should be more sophisticated)
            with open(file_path, 'w', encoding='utf-8') as f:
                f.write(f"# VULNERABILITY FIX APPLIED\n")
                f.write(f"# Type: {fix.vulnerability_type}\n")
                f.write(f"# Line: {fix.line_number}\n\n")
                f.write(fix.fixed_code)
            
            print(f"Applied fix to {fix.file_path}")
            return True
        except Exception as e:
            print(f"Error applying fix to {fix.file_path}: {str(e)}")
            return False


class FlowDiagramGenerator:
    """Generates flow diagrams for vulnerable code paths"""
    
    def __init__(self, openai_client: OpenAIClient):
        self.client = openai_client
    
    def generate_diagram(self, vuln: VulnerabilityInput, fix: VulnerabilityFix,
                        dependencies: Dict[str, DependencyInfo]) -> str:
        """Generate Mermaid flow diagram"""
        
        dep_info = dependencies.get(vuln.file_path)
        
        prompt = f"""Generate a Mermaid flowchart diagram showing the vulnerable code path and its dependencies.

Vulnerability:
- File: {vuln.file_path}
- Line: {vuln.line_number}
- Type: {vuln.vulnerability_type}

Dependencies: {dep_info.dependencies if dep_info else []}
Dependent Files Analyzed: {fix.dependent_files_analyzed}

Create a flowchart that shows:
1. Entry points
2. Data flow to vulnerable code
3. Dependent functions/classes
4. Impact of the vulnerability
5. The fix applied

Return ONLY the Mermaid diagram code starting with ```mermaid
"""
        
        messages = [
            {"role": "system", "content": "You are an expert at creating flow diagrams. Generate clear Mermaid diagrams."},
            {"role": "user", "content": prompt}
        ]
        
        response = self.client.chat_completion(messages)
        return response


# Agent workflow functions
def initialize_agent(state: AgentState) -> AgentState:
    """Initialize the agent state"""
    state.stage = "initialized"
    print("Agent initialized")
    return state


def clone_repository(state: AgentState) -> AgentState:
    """Clone GitHub repository"""
    print(f"Cloning repository to {state.repo_path}")
    state.stage = "cloned"
    return state


def analyze_dependencies(state: AgentState) -> AgentState:
    """Analyze repository dependencies"""
    print("Analyzing dependencies...")
    state.stage = "analyzed"
    return state


def fix_vulnerabilities(state: AgentState) -> AgentState:
    """Fix all vulnerabilities"""
    print("Fixing vulnerabilities...")
    state.stage = "fixed"
    return state


def validate_fixes(state: AgentState) -> AgentState:
    """Validate all fixes"""
    print("Validating fixes...")
    state.stage = "validated"
    return state


def commit_and_push(state: AgentState) -> AgentState:
    """Commit and push changes"""
    print("Committing and pushing changes...")
    state.stage = "committed"
    return state


def route_stage(state: AgentState) -> str:
    """Route to next stage based on current state"""
    stage_map = {
        "initialized": "clone",
        "cloned": "analyze",
        "analyzed": "fix",
        "fixed": "validate",
        "validated": "commit",
        "committed": END
    }
    return stage_map.get(state.stage, END)


def create_agent_workflow() -> StateGraph:
    """Create the LangGraph agent workflow"""
    
    workflow = StateGraph(AgentState)
    
    # Add nodes
    workflow.add_node("initialize", initialize_agent)
    workflow.add_node("clone", clone_repository)
    workflow.add_node("analyze", analyze_dependencies)
    workflow.add_node("fix", fix_vulnerabilities)
    workflow.add_node("validate", validate_fixes)
    workflow.add_node("commit", commit_and_push)
    
    # Add edges
    workflow.set_entry_point("initialize")
    workflow.add_conditional_edges("initialize", route_stage)
    workflow.add_conditional_edges("clone", route_stage)
    workflow.add_conditional_edges("analyze", route_stage)
    workflow.add_conditional_edges("fix", route_stage)
    workflow.add_conditional_edges("validate", route_stage)
    workflow.add_conditional_edges("commit", route_stage)
    
    return workflow.compile()


if __name__ == "__main__":
    print("Vulnerability Resolution Agent - Module loaded")
