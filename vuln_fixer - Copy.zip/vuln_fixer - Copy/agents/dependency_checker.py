"""
Dependency Checker Agent
Analyzes if dependency files are required to fix a vulnerability
"""

from core.gpt_client import create_gpt_client
from prompts.dependency_checker_prompts import SYSTEM_PROMPT, USER_PROMPT


def check_dependencies(project_tree, file_path, file_code, vulnerability, api_key):
    """
    Check if fixing vulnerability requires other dependency files
    
    Args:
        project_tree: Project directory structure
        file_path: Path to vulnerable file
        file_code: Content of vulnerable file
        vulnerability: Vulnerability dict from CSV
        api_key: OpenAI API key
        
    Returns:
        Dict with dependency requirements
    """
    gpt = create_gpt_client(api_key)
    
    user_prompt = USER_PROMPT.format(
        project_tree=project_tree,
        file_path=file_path,
        file_code=file_code,
        vuln_type=vulnerability['Vulnerability_Type'],
        cwe_id=vulnerability['CWE_ID'],
        line_number=vulnerability['Line_Number'],
        function_name=vulnerability['Function_Name'],
        description=vulnerability['Vulnerability_Description'],
        affected_code=vulnerability['Affected_Code'],
        recommendation=vulnerability['Recommendation'],
        dependency_chain=vulnerability['Dependency_Chain']
    )
    
    try:
        result = gpt.get_json_response(SYSTEM_PROMPT, user_prompt)
        return result
    except Exception as e:
        print(f"Error checking dependencies: {str(e)}")
        return {
            "requires_dependencies": False,
            "required_files": [],
            "reasoning": f"Error: {str(e)}"
        }