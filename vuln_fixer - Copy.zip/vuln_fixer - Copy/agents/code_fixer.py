"""
Code Fixer Agent
Generates vulnerability fixes using GPT-4o
"""

from core.gpt_client import create_gpt_client
from prompts.code_fixer_prompts import SYSTEM_PROMPT, USER_PROMPT


def add_line_numbers(code):
    """Add line numbers to code"""
    lines = code.split('\n')
    return '\n'.join([f"{i:4d} | {line}" for i, line in enumerate(lines, 1)])


def generate_fix(vulnerability, code, dependency_files, file_path, api_key, fix_context=""):
    """
    Generate fix for vulnerability
    
    Args:
        vulnerability: Vulnerability dict
        code: Code to fix
        dependency_files: Dict of {file_path: code} for context
        file_path: Path to file being fixed
        api_key: OpenAI API key
        fix_context: Additional context about the fix
        
    Returns:
        Dict with fix changes
    """
    gpt = create_gpt_client(api_key)
    
    # Build dependency context
    dependency_context = ""
    if dependency_files:
        dependency_context = "DEPENDENCY FILES FOR CONTEXT:\n\n" + "\n\n".join([
            f"--- {path} ---\n{dep_code}" 
            for path, dep_code in dependency_files.items()
        ])
    
    # Build fix context
    context_section = ""
    if fix_context:
        context_section = f"\nROOT CAUSE FIX CONTEXT:\n{fix_context}\n\nIMPORTANT: This file contains the ROOT CAUSE. Fix the underlying issue.\n"
    
    user_prompt = USER_PROMPT.format(
        file_path=file_path,
        fix_context=context_section,
        numbered_code=add_line_numbers(code),
        dependency_context=dependency_context if dependency_context else "",
        vuln_type=vulnerability['Vulnerability_Type'],
        cwe_id=vulnerability['CWE_ID'],
        severity=vulnerability['Severity'],
        cvss_score=vulnerability['CVSS_Score'],
        line_number=vulnerability['Line_Number'],
        function_name=vulnerability['Function_Name'],
        description=vulnerability['Vulnerability_Description'],
        affected_code=vulnerability['Affected_Code'],
        recommendation=vulnerability['Recommendation'],
        references=vulnerability['References']
    )
    
    try:
        result = gpt.get_json_response(SYSTEM_PROMPT, user_prompt)
        return result
    except Exception as e:
        print(f"Error generating fix: {str(e)}")
        return {
            "changes": [],
            "summary": f"Error: {str(e)}",
            "risk_assessment": "unknown"
        }