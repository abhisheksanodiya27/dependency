"""
Configuration File
Central place for all configuration settings
"""

import os
from pathlib import Path

# ===== PROJECT PATHS =====
# Replace these paths with your actual project paths

"""
Configuration Settings
"""

# OpenAI Configuration
OPENAI_API_KEY = ""
MODEL_NAME = "gpt-4o"
TEMPERATURE = 0

# Project Paths
PROJECT_ROOT = r"C:\Users\ABHISHEK SANODIYA\Desktop\Dependency\Auto_code\VulnerableApplication"
CSV_PATH = r"C:\Users\ABHISHEK SANODIYA\Desktop\Dependency\Auto_code\VulnerableApplication\vulnerability_report.csv"
OUTPUT_DIR = "output/fixed_code"

# Processing Options
MAX_RETRIES = 3
PROCESS_ALL = True