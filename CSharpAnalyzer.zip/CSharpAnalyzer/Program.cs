﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Newtonsoft.Json;

namespace CSharpAnalyzer;

public class AnalysisResult
{
    public string FilePath { get; set; } = string.Empty;
    public List<string> Usings { get; set; } = new();
    public List<ClassInfo> Classes { get; set; } = new();
}

public class ClassInfo
{
    public string ClassName { get; set; } = string.Empty;
    public string Namespace { get; set; } = string.Empty;
    public List<MethodInfo> Methods { get; set; } = new();
}

public class MethodInfo
{
    public string MethodName { get; set; } = string.Empty;
    public string ReturnType { get; set; } = string.Empty;
    public List<string> Parameters { get; set; } = new();
    public string AccessModifier { get; set; } = string.Empty;
    public bool IsStatic { get; set; }
    public bool IsAsync { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        if (args.Length == 0)
        {
            Console.WriteLine("Error: Please provide a file path as an argument.");
            Environment.Exit(1);
            return;
        }

        string filePath = args[0];

        if (!File.Exists(filePath))
        {
            Console.WriteLine($"Error: File not found: {filePath}");
            Environment.Exit(1);
            return;
        }

        try
        {
            var result = AnalyzeCSharpFile(filePath);
            string json = JsonConvert.SerializeObject(result, Formatting.Indented);
            Console.WriteLine(json);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error: {ex.Message}");
            Environment.Exit(1);
        }
    }

    static AnalysisResult AnalyzeCSharpFile(string filePath)
    {
        // Read the file content
        string code = File.ReadAllText(filePath);

        // Parse the code into a syntax tree
        SyntaxTree tree = CSharpSyntaxTree.ParseText(code);
        var root = (CompilationUnitSyntax)tree.GetRoot();

        var result = new AnalysisResult
        {
            FilePath = filePath,
            Usings = new List<string>(),
            Classes = new List<ClassInfo>()
        };

        // Extract using directives
        var usingDirectives = root.Usings;
        foreach (var usingDirective in usingDirectives)
        {
            result.Usings.Add(usingDirective.Name.ToString());
        }

        // Extract classes and their methods
        var classDeclarations = root.DescendantNodes().OfType<ClassDeclarationSyntax>();
        
        foreach (var classDecl in classDeclarations)
        {
            var classInfo = new ClassInfo
            {
                ClassName = classDecl.Identifier.Text,
                Namespace = GetNamespace(classDecl),
                Methods = new List<MethodInfo>()
            };

            // Extract methods from the class
            var methods = classDecl.Members.OfType<MethodDeclarationSyntax>();
            
            foreach (var method in methods)
            {
                var methodInfo = new MethodInfo
                {
                    MethodName = method.Identifier.Text,
                    ReturnType = method.ReturnType.ToString(),
                    Parameters = new List<string>(),
                    AccessModifier = GetAccessModifier(method.Modifiers),
                    IsStatic = method.Modifiers.Any(m => m.IsKind(SyntaxKind.StaticKeyword)),
                    IsAsync = method.Modifiers.Any(m => m.IsKind(SyntaxKind.AsyncKeyword))
                };

                // Extract parameters
                foreach (var param in method.ParameterList.Parameters)
                {
                    methodInfo.Parameters.Add($"{param.Type} {param.Identifier.Text}");
                }

                classInfo.Methods.Add(methodInfo);
            }

            result.Classes.Add(classInfo);
        }

        return result;
    }

    static string GetNamespace(ClassDeclarationSyntax classDecl)
    {
        var namespaceDecl = classDecl.Ancestors().OfType<NamespaceDeclarationSyntax>().FirstOrDefault();
        if (namespaceDecl != null)
        {
            return namespaceDecl.Name.ToString();
        }

        // Check for file-scoped namespace (C# 10+)
        var fileScopedNamespace = classDecl.Ancestors().OfType<FileScopedNamespaceDeclarationSyntax>().FirstOrDefault();
        if (fileScopedNamespace != null)
        {
            return fileScopedNamespace.Name.ToString();
        }

        return "Global";
    }

    static string GetAccessModifier(SyntaxTokenList modifiers)
    {
        if (modifiers.Any(m => m.IsKind(SyntaxKind.PublicKeyword)))
            return "public";
        if (modifiers.Any(m => m.IsKind(SyntaxKind.PrivateKeyword)))
            return "private";
        if (modifiers.Any(m => m.IsKind(SyntaxKind.ProtectedKeyword)))
            return "protected";
        if (modifiers.Any(m => m.IsKind(SyntaxKind.InternalKeyword)))
            return "internal";
        
        return "private"; // Default access modifier for methods
    }
}