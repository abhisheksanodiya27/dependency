#!/usr/bin/env python3
import subprocess
import json
import sys
import os

class CSharpAnalyzer:
    def __init__(self, analyzer_exe_path=None):
        """Initialize the C# analyzer"""
        if analyzer_exe_path is None:
            # Try to find the analyzer in common locations
            possible_paths = [
                "CSharpAnalyzer/bin/Release/net10.0/CSharpAnalyzer.exe",
                "CSharpAnalyzer/bin/Release/net10.0/CSharpAnalyzer.dll",
                "CSharpAnalyzer/bin/Release/net9.0/CSharpAnalyzer.exe",
                "CSharpAnalyzer/bin/Release/net9.0/CSharpAnalyzer.dll",
                "CSharpAnalyzer/bin/Release/net8.0/CSharpAnalyzer.exe",
                "CSharpAnalyzer/bin/Release/net8.0/CSharpAnalyzer.dll",
                "CSharpAnalyzer/bin/Release/net7.0/CSharpAnalyzer.exe",
                "CSharpAnalyzer/bin/Release/net7.0/CSharpAnalyzer.dll",
                "CSharpAnalyzer/bin/Release/net6.0/CSharpAnalyzer.exe",
                "CSharpAnalyzer/bin/Release/net6.0/CSharpAnalyzer.dll",
            ]
            
            for path in possible_paths:
                if os.path.exists(path):
                    analyzer_exe_path = path
                    break
            
            if analyzer_exe_path is None:
                raise FileNotFoundError(
                    "Could not find CSharpAnalyzer executable. "
                    "Please build the project first or specify the path manually."
                )
        
        self.analyzer_path = analyzer_exe_path
        print(f"Using analyzer: {self.analyzer_path}")
    
    def analyze_file(self, cs_file_path):
        """Analyze a C# file and return the results"""
        if not os.path.exists(cs_file_path):
            raise FileNotFoundError(f"C# file not found: {cs_file_path}")
        
        # Determine if we need to use 'dotnet' command
        if self.analyzer_path.endswith('.dll'):
            cmd = ['dotnet', self.analyzer_path, cs_file_path]
        else:
            cmd = [self.analyzer_path, cs_file_path]
        
        try:
            # Run the C# analyzer
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                check=True
            )
            
            # Parse JSON output
            analysis_result = json.loads(result.stdout)
            return analysis_result
            
        except subprocess.CalledProcessError as e:
            print(f"Error running analyzer: {e.stderr}", file=sys.stderr)
            raise
        except json.JSONDecodeError as e:
            print(f"Error parsing JSON output: {e}", file=sys.stderr)
            print(f"Output was: {result.stdout}", file=sys.stderr)
            raise
    
    def print_analysis(self, analysis_result):
        """Pretty print the analysis results"""
        print(f"\n{'='*60}")
        print(f"Analysis of: {analysis_result['FilePath']}")
        print(f"{'='*60}\n")
        
        # Print using statements
        print("Using Statements:")
        if analysis_result['Usings']:
            for using in analysis_result['Usings']:
                print(f"  - {using}")
        else:
            print("  (none)")
        
        print()
        
        # Print classes and methods
        print("Classes and Methods:")
        if analysis_result['Classes']:
            for class_info in analysis_result['Classes']:
                namespace = class_info['Namespace']
                class_name = class_info['ClassName']
                print(f"\n  Class: {namespace}.{class_name}")
                print(f"  {'-' * 50}")
                
                if class_info['Methods']:
                    for method in class_info['Methods']:
                        modifiers = []
                        if method['AccessModifier']:
                            modifiers.append(method['AccessModifier'])
                        if method['IsStatic']:
                            modifiers.append('static')
                        if method['IsAsync']:
                            modifiers.append('async')
                        
                        modifier_str = ' '.join(modifiers)
                        params = ', '.join(method['Parameters']) if method['Parameters'] else ''
                        
                        print(f"    {modifier_str} {method['ReturnType']} {method['MethodName']}({params})")
                else:
                    print("    (no methods)")
        else:
            print("  (no classes found)")
        
        print(f"\n{'='*60}\n")


# ============================================================
# CONFIGURATION - EDIT THIS SECTION
# ============================================================

# Set your C# file path here (use raw string or forward slashes)
CS_FILE_PATH = r"C:\Users\ABHISHEK SANODIYA\Desktop\vulnerability\Asp.Net-Core-Inventory-Order-Management-System\Presentation\ASPNET\FrontEnd\FrontEndConfiguration.cs"

# Specify the analyzer path manually
ANALYZER_PATH = r"C:\Users\ABHISHEK SANODIYA\Desktop\vulnerability\CSharpAnalyzer\bin\Release\net10.0\CSharpAnalyzer.dll"

# ============================================================
# MAIN EXECUTION
# ============================================================

if __name__ == "__main__":
    try:
        print(f"Analyzing file: {CS_FILE_PATH}\n")
        
        # Create analyzer instance
        analyzer = CSharpAnalyzer(ANALYZER_PATH)
        
        # Analyze the file
        result = analyzer.analyze_file(CS_FILE_PATH)
        
        # Print results
        # analyzer.print_analysis(result)
        
        # Optional: Print raw JSON
        print("\nRaw JSON:")
        print(json.dumps(result, indent=2))
        
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)