"""
Project analysis functionality
"""

try:
    import networkx as nx
except ImportError:
    print("❌ Error: networkx not installed")
    exit(1)

from pathlib import Path
from graph_builder import DependencyGraphBuilder


class ProjectAnalyzer:
    """Analyze project dependencies and generate statistics"""
    
    def __init__(self, graph: nx.DiGraph, builder: DependencyGraphBuilder):
        """
        Initialize analyzer
        
        Args:
            graph: NetworkX dependency graph
            builder: DependencyGraphBuilder instance
        """
        self.graph = graph
        self.builder = builder
    
    def analyze(self):
        """Run comprehensive project analysis"""
        if self.graph.number_of_nodes() == 0:
            print("❌ No files in graph")
            return
        
        print(f"\n{'='*60}")
        print("PROJECT ANALYSIS")
        print(f"{'='*60}")
        
        self._print_overall_statistics()
        self._print_language_breakdown()
        self._print_most_connected_files()
        self._print_most_depended_on_files()
    
    def _print_overall_statistics(self):
        """Print overall statistics"""
        print(f"\n📊 Overall Statistics:")
        print(f"  • Total files: {self.graph.number_of_nodes()}")
        print(f"  • Total dependencies: {self.graph.number_of_edges()}")
        print(f"  • Total functions: {len(self.builder.function_to_file)}")
        
        if self.graph.number_of_nodes() > 0:
            density = nx.density(self.graph)
            print(f"  • Graph density: {density:.3f}")
    
    def _print_language_breakdown(self):
        """Print language breakdown"""
        languages = {}
        for node in self.graph.nodes():
            lang = self.graph.nodes[node].get('language', 'unknown')
            languages[lang] = languages.get(lang, 0) + 1
        
        print(f"\n🔤 Language Breakdown:")
        for lang, count in sorted(languages.items(), key=lambda x: x[1], reverse=True):
            pct = (count / self.graph.number_of_nodes()) * 100
            print(f"  • {lang}: {count} files ({pct:.1f}%)")
    
    def _print_most_connected_files(self):
        """Print most connected files"""
        print(f"\n🔗 Most Connected Files:")
        top_files = self.builder.get_most_connected_files(5)
        for filepath, degree in top_files:
            print(f"  • {Path(filepath).name}: {degree} connections")
    
    def _print_most_depended_on_files(self):
        """Print most depended-on files"""
        print(f"\n⭐ Most Depended-On Files:")
        top_deps = self.builder.get_most_depended_on_files(5)
        for filepath, in_degree in top_deps:
            if in_degree > 0:
                print(f"  • {Path(filepath).name}: {in_degree} dependents")
    
    def query_file(self, filename: str):
        """
        Query dependencies for a specific file
        
        Args:
            filename: Name or path of file to query
        """
        matching_files = [node for node in self.graph.nodes() if filename in node]
        
        if not matching_files:
            print(f"❌ File '{filename}' not found")
            return
        
        if len(matching_files) > 1:
            print(f"⚠️  Multiple files match '{filename}':")
            for f in matching_files:
                print(f"  • {f}")
            return
        
        filepath = matching_files[0]
        info = self.builder.get_file_info(filepath)
        
        print(f"\n{'='*60}")
        print(f"FILE ANALYSIS: {Path(filepath).name}")
        print(f"{'='*60}")
        
        print(f"\n📍 Location: {filepath}")
        print(f"🔤 Language: {info['metadata'].get('language', 'unknown')}")
        print(f"📊 Functions: {info['metadata'].get('num_functions', 0)}")
        
        # Show functions defined
        functions_in_file = self.builder.file_functions.get(filepath, set())
        if functions_in_file:
            print(f"\n🔧 Functions defined in this file:")
            for func in sorted(functions_in_file):
                print(f"  • {func}")
        
        print(f"\n📥 Depends on: {info['out_degree']} files")
        if info['depends_on']:
            print(f"⬇️  This file depends on:")
            for dep in info['depends_on'][:10]:
                print(f"  • {Path(dep).name}")
        
        print(f"\n📤 Depended by: {info['in_degree']} files")
        if info['imported_by']:
            print(f"⬆️  This file is imported by:")
            for imp in info['imported_by'][:10]:
                print(f"  • {Path(imp).name}")