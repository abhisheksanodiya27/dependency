"""
AST parsing functionality using Tree-sitter
"""


from pathlib import Path
from typing import Optional, Set, Tuple
try:
    from tree_sitter_languages import get_parser, get_language
    from tree_sitter import Parser
except ImportError:
    print("❌ Error: tree-sitter-languages not installed")
    print("Install it with: pip install tree-sitter-languages tree-sitter")
    exit(1)

from config import LANG_CONFIG

class CodeParser:
    """Parse source code files and extract AST information"""
    
    def __init__(self):
        """Initialize parsers for all supported languages"""
        self.parsers = {}
        self._load_parsers()
    
    def _load_parsers(self):
        """Load Tree-sitter parsers for all configured languages"""
        print("🔧 Loading language parsers...")
        
        from tree_sitter_languages import get_language
        from tree_sitter import Parser
        
        for lang_name, config in LANG_CONFIG.items():
            try:
                # Get the language
                language = get_language(config['ts_name'])
                
                # Create parser and set language
                parser = Parser()
                parser.set_language(language)
                
                self.parsers[lang_name] = parser
                print(f"  ✓ {lang_name}")
            except Exception as e:
                print(f"  ✗ {lang_name}: {str(e)}")
        
        print(f"\n✅ Loaded {len(self.parsers)} language parsers\n")
    
    # Rest of the class remains the same...            
    def detect_language(self, filepath: Path) -> Optional[str]:
        """
        Detect programming language from file extension
        
        Args:
            filepath: Path to source file
        
        Returns:
            Language name or None if not supported
        """
        ext = filepath.suffix.lower()
        for lang, config in LANG_CONFIG.items():
            if ext in config['extensions']:
                return lang
        return None
    
    def parse_file(self, filepath: Path) -> Tuple[Optional[any], Optional[bytes], Optional[str]]:
        """
        Parse a source file and return its AST
        
        Args:
            filepath: Path to source file
        
        Returns:
            Tuple of (root_node, source_bytes, language) or (None, None, None)
        """
        language = self.detect_language(filepath)
        
        if not language or language not in self.parsers:
            return None, None, None
        
        try:
            with open(filepath, 'rb') as f:
                source = f.read()
            
            parser = self.parsers[language]
            tree = parser.parse(source)
            return tree.root_node, source, language
            
        except Exception as e:
            print(f"Failed to parse {filepath}: {e}")
            return None, None, None
    
    def extract_functions(self, node, source: bytes, language: str) -> Set[str]:
        """
        Extract all function names from AST
        
        Args:
            node: AST root node
            source: Source code bytes
            language: Programming language
        
        Returns:
            Set of function names
        """
        functions = set()
        config = LANG_CONFIG.get(language, {})
        function_types = config.get('function_types', [])
        
        def traverse(n):
            if n.type in function_types:
                name = self._extract_function_name(n, source, language)
                if name:
                    functions.add(name)
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return functions
    
    def extract_function_calls(self, node, source: bytes, language: str) -> Set[str]:
        """
        Extract all function call names from AST
        
        Args:
            node: AST root node
            source: Source code bytes
            language: Programming language
        
        Returns:
            Set of function call names
        """
        calls = set()
        config = LANG_CONFIG.get(language, {})
        call_types = config.get('call_types', [])
        
        def traverse(n):
            if n.type in call_types:
                call_name = self._extract_call_name(n, source, language)
                if call_name:
                    calls.add(call_name)
            for child in n.children:
                traverse(child)
        
        traverse(node)
        return calls
    
    def _extract_function_name(self, node, source: bytes, language: str) -> Optional[str]:
        """Extract function name from function definition node"""
        name_node = node.child_by_field_name('name')
        
        if not name_node:
            for child in node.children:
                if child.type == 'identifier':
                    name_node = child
                    break
        
        if name_node:
            try:
                return source[name_node.start_byte:name_node.end_byte].decode('utf-8', errors='ignore')
            except Exception:
                return None
        return None
    
    def _extract_call_name(self, node, source: bytes, language: str) -> Optional[str]:
        """Extract function name from call expression node"""
        func_node = node.child_by_field_name('function')
        
        if not func_node:
            func_node = node.children[0] if node.children else None
        
        if not func_node:
            return None
        
        try:
            call_text = source[func_node.start_byte:func_node.end_byte].decode('utf-8', errors='ignore')
            if '.' in call_text:
                call_text = call_text.split('.')[-1]
            return call_text
        except Exception:
            return None