"""
Visualization functionality for dependency graphs
"""

try:
    import networkx as nx
    import matplotlib.pyplot as plt
    from pyvis.network import Network
except ImportError:
    print("❌ Error: Required libraries not installed")
    print("Install with: pip install networkx matplotlib pyvis")
    exit(1)

from pathlib import Path

from config import OUTPUT_DIR


class DependencyVisualizer:
    """Visualize dependency graphs"""
    
    def __init__(self, graph: nx.DiGraph):
        """
        Initialize visualizer
        
        Args:
            graph: NetworkX dependency graph
        """
        self.graph = graph
        self.output_dir = OUTPUT_DIR
    
    def create_interactive_html(self):
        """Create interactive HTML visualization"""
        if self.graph.number_of_nodes() == 0:
            print("❌ Graph is empty")
            return None
        
        print("\n🎨 Creating interactive visualization...")
        
        net = Network(height='800px', width='100%', directed=True,
                     bgcolor='#222222', font_color='white')
        net.barnes_hut(gravity=-8000, central_gravity=0.3, spring_length=250)
        
        for node in self.graph.nodes():
            in_deg = self.graph.in_degree(node)
            out_deg = self.graph.out_degree(node)
            
            color = '#ff4444' if in_deg > 5 else '#ffaa00' if in_deg > 2 else '#4444ff'
            size = 10 + (in_deg + out_deg) * 2
            
            net.add_node(node, label=Path(node).name,
                        title=f"{Path(node).name}\nDeps: {out_deg}\nDependent: {in_deg}",
                        color=color, size=size)
        
        for source, target in self.graph.edges():
            weight = self.graph[source][target].get('weight', 1)
            net.add_edge(source, target, value=weight)
        
        output_file = self.output_dir / 'dependency_graph.html'
        net.save_graph(str(output_file))
        print(f"✅ Interactive graph saved to: {output_file}")
        
        return output_file
    
    def plot_statistics(self):
        """Create statistical plots"""
        if self.graph.number_of_nodes() == 0:
            print("❌ Graph is empty")
            return
        
        print("\n📊 Creating statistical plots...")
        
        in_degrees = [self.graph.in_degree(node) for node in self.graph.nodes()]
        out_degrees = [self.graph.out_degree(node) for node in self.graph.nodes()]
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # In-degree distribution
        axes[0, 0].hist(in_degrees, bins=20, color='skyblue', edgecolor='black')
        axes[0, 0].set_title('Files by Dependents')
        axes[0, 0].set_xlabel('Dependents')
        axes[0, 0].set_ylabel('Count')
        
        # Out-degree distribution
        axes[0, 1].hist(out_degrees, bins=20, color='lightcoral', edgecolor='black')
        axes[0, 1].set_title('Files by Dependencies')
        axes[0, 1].set_xlabel('Dependencies')
        axes[0, 1].set_ylabel('Count')
        
        # Top 10 most depended-on files
        in_deg_sorted = sorted([(node, self.graph.in_degree(node)) for node in self.graph.nodes()],
                               key=lambda x: x[1], reverse=True)[:10]
        
        if in_deg_sorted:
            files, degs = zip(*in_deg_sorted)
            files = [Path(f).name for f in files]
            axes[1, 0].barh(files, degs, color='green', alpha=0.7)
            axes[1, 0].set_title('Top 10 Most Depended-On')
            axes[1, 0].set_xlabel('Dependents')
            axes[1, 0].invert_yaxis()
        
        # Language distribution
        languages = {}
        for node in self.graph.nodes():
            lang = self.graph.nodes[node].get('language', 'unknown')
            languages[lang] = languages.get(lang, 0) + 1
        
        if languages:
            axes[1, 1].pie(languages.values(), labels=languages.keys(),
                          autopct='%1.1f%%', startangle=90)
            axes[1, 1].set_title('Language Distribution')
        
        plt.tight_layout()
        
        # Save plot
        output_file = self.output_dir / 'statistics.png'
        plt.savefig(output_file, dpi=150)
        print(f"✅ Statistics plot saved to: {output_file}")
        
        plt.show()
    
    def plot_matplotlib_graph(self):
        """Create static matplotlib graph visualization"""
        if self.graph.number_of_nodes() == 0:
            print("❌ Graph is empty")
            return
        
        if self.graph.number_of_nodes() > 50:
            print("⚠️  Graph too large for matplotlib (use interactive HTML instead)")
            return
        
        print("\n🎨 Creating matplotlib graph...")
        
        plt.figure(figsize=(20, 15))
        pos = nx.spring_layout(self.graph, k=2, iterations=50, seed=42)
        in_degrees = [self.graph.in_degree(node) for node in self.graph.nodes()]
        
        nx.draw_networkx_nodes(self.graph, pos, node_color=in_degrees, node_size=500,
                              cmap='YlOrRd', alpha=0.8)
        nx.draw_networkx_edges(self.graph, pos, edge_color='gray', alpha=0.3,
                              arrows=True, arrowsize=10, width=0.5)
        
        labels = {node: Path(node).name for node in self.graph.nodes()}
        nx.draw_networkx_labels(self.graph, pos, labels, font_size=6)
        
        plt.title("File Dependency Graph", fontsize=16)
        plt.axis('off')
        plt.tight_layout()
        
        # Save plot
        output_file = self.output_dir / 'graph_matplotlib.png'
        plt.savefig(output_file, dpi=150)
        print(f"✅ Graph saved to: {output_file}")
        
        plt.show()