"""
Core dependency graph builder
"""

try:
    import networkx as nx
except ImportError:
    print("❌ Error: networkx not installed")
    print("Install it with: pip install networkx")
    exit(1)

from pathlib import Path
from typing import Dict, List, Set, Optional
from collections import defaultdict

from config import EXCLUDED_DIRS
from parser import CodeParser


class DependencyGraphBuilder:
    """Build file-level dependency graphs from source code"""
    
    def __init__(self):
        """Initialize graph builder with code parser"""
        self.parser = CodeParser()
        self.graph = nx.DiGraph()
        self.file_functions = defaultdict(set)
        self.function_to_file = {}
    
    def build_from_directory(
        self, 
        repo_path: str,
        exclude_dirs: Optional[Set[str]] = None
    ) -> nx.DiGraph:
        """
        Build dependency graph from a directory
        
        Args:
            repo_path: Path to project directory
            exclude_dirs: Additional directories to exclude
        
        Returns:
            NetworkX DiGraph representing dependencies
        """
        if exclude_dirs is None:
            exclude_dirs = EXCLUDED_DIRS
        else:
            exclude_dirs = EXCLUDED_DIRS.union(exclude_dirs)
        
        repo_path = Path(repo_path).resolve()
        
        if not repo_path.exists():
            print(f"❌ Path does not exist: {repo_path}")
            return self.graph
        
        print(f"\n{'='*60}")
        print(f"📂 Scanning: {repo_path}")
        print(f"{'='*60}")
        
        # Collect source files
        source_files = self._collect_source_files(repo_path, exclude_dirs)
        
        if not source_files:
            print("⚠️  No source files found!")
            return self.graph
        
        print(f"📄 Found {len(source_files)} source files")
        self._print_language_breakdown(source_files)
        
        # Phase 1: Extract functions
        print(f"\n{'='*60}")
        print("Phase 1: Extracting Functions")
        print(f"{'='*60}")
        self._extract_all_functions(source_files)
        
        # Phase 2: Build dependencies
        print(f"\n{'='*60}")
        print("Phase 2: Building Dependencies")
        print(f"{'='*60}")
        self._build_all_dependencies(source_files)
        
        # Print summary
        self._print_summary()
        
        return self.graph
    
    def _collect_source_files(
        self, 
        repo_path: Path, 
        exclude_dirs: Set[str]
    ) -> List[Path]:
        """Collect all source files from directory"""
        all_files = []
        
        from config import LANG_CONFIG
        for config in LANG_CONFIG.values():
            for ext in config['extensions']:
                all_files.extend(repo_path.rglob(f'*{ext}'))
        
        # Filter excluded directories
        source_files = [
            f for f in all_files
            if not any(excluded in f.parts for excluded in exclude_dirs)
        ]
        
        return source_files
    
    def _print_language_breakdown(self, files: List[Path]):
        """Print breakdown of files by language"""
        lang_counts = defaultdict(int)
        for f in files:
            lang = self.parser.detect_language(f)
            if lang:
                lang_counts[lang] += 1
        
        print(f"\n Language breakdown:")
        for lang, count in sorted(lang_counts.items(), key=lambda x: x[1], reverse=True):
            print(f"  • {lang}: {count} files")
    
    def _extract_all_functions(self, files: List[Path]):
        """Extract functions from all files (Phase 1)"""
        processed = 0
        
        for filepath in files:
            try:
                self._process_single_file(filepath)
                processed += 1
                
                if processed % 100 == 0:
                    print(f"  Processed {processed}/{len(files)} files...")
            except Exception as e:
                pass
        
        print(f"  ✓ Processed: {processed} files")
        print(f"  ✓ Total functions: {len(self.function_to_file)}")
    
    def _process_single_file(self, filepath: Path):
        """Process a single file to extract functions"""
        root_node, source, language = self.parser.parse_file(filepath)
        
        if not root_node:
            return
        
        filepath_str = str(filepath)
        
        # Extract functions
        functions = self.parser.extract_functions(root_node, source, language)
        self.file_functions[filepath_str] = functions
        
        # Build function -> file mapping
        for func_name in functions:
            self.function_to_file[func_name] = filepath_str
        
        # Add node to graph
        if not self.graph.has_node(filepath_str):
            self.graph.add_node(
                filepath_str,
                filename=filepath.name,
                language=language,
                num_functions=len(functions)
            )
    
    def _build_all_dependencies(self, files: List[Path]):
        """Build dependencies for all files (Phase 2)"""
        dep_count = 0
        
        for filepath in files:
            try:
                deps = self._build_file_dependencies(filepath)
                dep_count += len(deps)
            except Exception as e:
                pass
        
        print(f"  ✓ Created {dep_count} dependency connections")
    
    def _build_file_dependencies(self, filepath: Path) -> List:
        """Build dependencies for a single file"""
        root_node, source, language = self.parser.parse_file(filepath)
        
        if not root_node:
            return []
        
        filepath_str = str(filepath)
        dependencies = []
        
        # Extract function calls
        calls = self.parser.extract_function_calls(root_node, source, language)
        
        # Map calls to their source files
        for call_name in calls:
            if call_name in self.function_to_file:
                target_file = self.function_to_file[call_name]
                
                # Skip self-dependencies
                if target_file != filepath_str:
                    if self.graph.has_edge(filepath_str, target_file):
                        self.graph[filepath_str][target_file]['weight'] += 1
                    else:
                        self.graph.add_edge(filepath_str, target_file, weight=1)
                        dependencies.append((filepath_str, target_file))
        
        return dependencies
    
    def _print_summary(self):
        """Print graph summary statistics"""
        print(f"\n{'='*60}")
        print("GRAPH SUMMARY")
        print(f"{'='*60}")
        
        nodes = self.graph.number_of_nodes()
        edges = self.graph.number_of_edges()
        
        print(f"  Files: {nodes}")
        print(f"  Dependencies: {edges}")
        
        if nodes > 0:
            avg_deps = edges / nodes
            print(f" Avg dependencies per file: {avg_deps:.1f}")
    
    def get_file_info(self, filepath: str) -> Optional[Dict]:
        """
        Get detailed information about a specific file
        
        Args:
            filepath: Path to file
        
        Returns:
            Dictionary with file information
        """
        if filepath not in self.graph:
            return None
        
        return {
            'file': filepath,
            'filename': Path(filepath).name,
            'metadata': self.graph.nodes[filepath],
            'depends_on': list(self.graph.successors(filepath)),
            'imported_by': list(self.graph.predecessors(filepath)),
            'in_degree': self.graph.in_degree(filepath),
            'out_degree': self.graph.out_degree(filepath),
        }
    
    def get_most_connected_files(self, top_n: int = 10) -> List:
        """Get files with most dependencies"""
        degrees = [(node, self.graph.degree(node)) for node in self.graph.nodes()]
        return sorted(degrees, key=lambda x: x[1], reverse=True)[:top_n]
    
    def get_most_depended_on_files(self, top_n: int = 10) -> List:
        """Get files that are most depended upon"""
        in_degrees = [(node, self.graph.in_degree(node)) for node in self.graph.nodes()]
        return sorted(in_degrees, key=lambda x: x[1], reverse=True)[:top_n]