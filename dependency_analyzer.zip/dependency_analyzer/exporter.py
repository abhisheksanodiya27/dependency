"""
Export analysis results to various formats
"""

try:
    import networkx as nx
    import pandas as pd
except ImportError:
    print("❌ Error: Required libraries not installed")
    print("Install with: pip install networkx pandas")
    exit(1)

import json
from pathlib import Path
from collections import defaultdict

from config import OUTPUT_DIR
from graph_builder import DependencyGraphBuilder


class ResultExporter:
    """Export dependency analysis results"""
    
    def __init__(self, graph: nx.DiGraph, builder: DependencyGraphBuilder):
        """
        Initialize exporter
        
        Args:
            graph: NetworkX dependency graph
            builder: DependencyGraphBuilder instance
        """
        self.graph = graph
        self.builder = builder
        self.output_dir = OUTPUT_DIR
    
    def export_all(self):
        """Export all results to various formats"""
        print(f"\n{'='*60}")
        print("EXPORTING RESULTS")
        print(f"{'='*60}")
        
        self._export_json()
        self._export_detailed_csv()
        self._export_functions_csv()
        self._export_function_calls_csv()
        
        print(f"\n✅ All results exported to: {self.output_dir}")
    
    def _export_json(self):
        """Export graph to JSON"""
        data = {
            'graph': nx.node_link_data(self.graph),
            'statistics': {
                'total_files': self.graph.number_of_nodes(),
                'total_dependencies': self.graph.number_of_edges(),
                'total_functions': len(self.builder.function_to_file),
            }
        }
        
        output_path = self.output_dir / 'dependency_graph.json'
        with open(output_path, 'w') as f:
            json.dump(data, f, indent=2)
        
        print(f"  ✓ dependency_graph.json")
    
    def _export_detailed_csv(self):
        """Export detailed file dependencies CSV"""
        # Build function call mapping
        file_to_file_functions = self._build_function_call_mapping()
        
        # Prepare detailed file data
        file_data = []
        for node in self.graph.nodes():
            info = self.builder.get_file_info(node)
            
            # Get functions in this file
            functions_in_file = self.builder.file_functions.get(node, set())
            functions_list = ', '.join(sorted(functions_in_file)) if functions_in_file else ''
            
            # Get dependency file paths WITH function calls
            depends_on_files = list(self.graph.successors(node))
            
            # Build detailed dependency info
            dependency_details = []
            for dep_file in depends_on_files:
                dep_filename = Path(dep_file).name
                functions_called = file_to_file_functions[node].get(dep_file, set())
                func_list = ', '.join(sorted(functions_called)) if functions_called else ''
                dependency_details.append(f"{dep_filename}[{func_list}]")
            
            depends_on_list = ' | '.join([Path(f).name for f in depends_on_files]) if depends_on_files else ''
            depends_on_with_functions = ' | '.join(dependency_details) if dependency_details else ''
            depends_on_full_paths = ' | '.join(depends_on_files) if depends_on_files else ''
            
            # Get dependent file paths
            imported_by_files = list(self.graph.predecessors(node))
            
            # Build detailed dependent info
            dependent_details = []
            for dep_file in imported_by_files:
                dep_filename = Path(dep_file).name
                functions_called = file_to_file_functions[dep_file].get(node, set())
                func_list = ', '.join(sorted(functions_called)) if functions_called else ''
                dependent_details.append(f"{dep_filename}[{func_list}]")
            
            imported_by_list = ' | '.join([Path(f).name for f in imported_by_files]) if imported_by_files else ''
            imported_by_with_functions = ' | '.join(dependent_details) if dependent_details else ''
            imported_by_full_paths = ' | '.join(imported_by_files) if imported_by_files else ''
            
            file_data.append({
                'file': Path(node).name,
                'full_path': node,
                'language': self.graph.nodes[node].get('language', 'unknown'),
                'num_functions': self.graph.nodes[node].get('num_functions', 0),
                'functions_defined': functions_list,
                'dependencies': self.graph.out_degree(node),
                'dependency_files': depends_on_list,
                'dependency_with_functions': depends_on_with_functions,
                'dependency_full_paths': depends_on_full_paths,
                'dependents': self.graph.in_degree(node),
                'dependent_files': imported_by_list,
                'dependent_with_functions': imported_by_with_functions,
                'dependent_full_paths': imported_by_full_paths,
                'total_connections': self.graph.degree(node)
            })
        
        # Create DataFrame and export
        df = pd.DataFrame(file_data)
        output_path = self.output_dir / 'file_dependencies_detailed.csv'
        df.to_csv(output_path, index=False)
        
        print(f"  ✓ file_dependencies_detailed.csv")
    
    def _export_functions_csv(self):
        """Export functions list CSV"""
        function_data = []
        for func_name, file_path in self.builder.function_to_file.items():
            function_data.append({
                'function_name': func_name,
                'defined_in_file': Path(file_path).name,
                'defined_in_full_path': file_path,
                'language': self.graph.nodes[file_path].get('language', 'unknown')
            })
        
        df = pd.DataFrame(function_data)
        output_path = self.output_dir / 'functions_list.csv'
        df.to_csv(output_path, index=False)
        
        print(f"  ✓ functions_list.csv")
    
    def _export_function_calls_csv(self):
        """Export function calls CSV"""
        file_to_file_functions = self._build_function_call_mapping()
        
        function_call_data = []
        for source_file, targets in file_to_file_functions.items():
            for target_file, functions_called in targets.items():
                for func in functions_called:
                    function_call_data.append({
                        'calling_file': Path(source_file).name,
                        'calling_file_full_path': source_file,
                        'function_called': func,
                        'defined_in_file': Path(target_file).name,
                        'defined_in_full_path': target_file
                    })
        
        df = pd.DataFrame(function_call_data)
        output_path = self.output_dir / 'function_calls_detailed.csv'
        df.to_csv(output_path, index=False)
        
        print(f"  ✓ function_calls_detailed.csv")
    
    def _build_function_call_mapping(self) -> dict:
        """Build mapping of which functions are called between files"""
        file_to_file_functions = defaultdict(lambda: defaultdict(set))
        
        for source_file in self.graph.nodes():
            root_node, source_code, language = self.builder.parser.parse_file(Path(source_file))
            
            if not root_node:
                continue
            
            # Get all function calls in this file
            calls = self.builder.parser.extract_function_calls(root_node, source_code, language)
            
            # Map each call to its target file
            for call_name in calls:
                if call_name in self.builder.function_to_file:
                    target_file = self.builder.function_to_file[call_name]
                    
                    # Only track cross-file calls
                    if target_file != source_file:
                        file_to_file_functions[source_file][target_file].add(call_name)
        
        return file_to_file_functions