"""
Configuration settings for dependency analyzer
"""

from pathlib import Path

# Output directory
OUTPUT_DIR = Path(__file__).parent / "output"
OUTPUT_DIR.mkdir(exist_ok=True)

# Supported languages configuration
LANG_CONFIG = {
    'python': {
        'extensions': ['.py'],
        'ts_name': 'python',
        'import_types': ['import_statement', 'import_from_statement'],
        'function_types': ['function_definition'],
        'call_types': ['call'],
    },
    'java': {
        'extensions': ['.java'],
        'ts_name': 'java',
        'import_types': ['import_declaration'],
        'function_types': ['method_declaration'],
        'call_types': ['method_invocation'],
    },
    'javascript': {
        'extensions': ['.js', '.jsx'],
        'ts_name': 'javascript',
        'import_types': ['import_statement'],
        'function_types': ['function_declaration', 'method_definition'],
        'call_types': ['call_expression'],
    },
    'typescript': {
        'extensions': ['.ts', '.tsx'],
        'ts_name': 'typescript',
        'import_types': ['import_statement'],
        'function_types': ['function_declaration', 'method_definition'],
        'call_types': ['call_expression'],
    },
    'go': {
        'extensions': ['.go'],
        'ts_name': 'go',
        'import_types': ['import_declaration'],
        'function_types': ['function_declaration'],
        'call_types': ['call_expression'],
    },
    'rust': {
        'extensions': ['.rs'],
        'ts_name': 'rust',
        'import_types': ['use_declaration'],
        'function_types': ['function_item'],
        'call_types': ['call_expression'],
    },
    'cpp': {
        'extensions': ['.cpp', '.cc', '.cxx', '.hpp', '.h', '.hxx'],
        'ts_name': 'cpp',
        'import_types': ['preproc_include'],
        'function_types': ['function_definition'],
        'call_types': ['call_expression'],
    },
    'c': {
        'extensions': ['.c', '.h'],
        'ts_name': 'c',
        'import_types': ['preproc_include'],
        'function_types': ['function_definition'],
        'call_types': ['call_expression'],
    },
    'c_sharp': {
        'extensions': ['.cs'],
        'ts_name': 'c_sharp',
        'import_types': ['using_directive'],
        'function_types': ['method_declaration'],
        'call_types': ['invocation_expression'],
    },
    'ruby': {
        'extensions': ['.rb'],
        'ts_name': 'ruby',
        'import_types': ['call'],
        'function_types': ['method'],
        'call_types': ['call'],
    },
}

# Directories to exclude from analysis
EXCLUDED_DIRS = {
    'node_modules', '.git', '__pycache__', 'venv', 'env',
    'build', 'dist', '.pytest_cache', '.venv', 'target',
    'out', 'bin', 'obj', '.idea', '.vscode', 'vendor',
    '.next', 'coverage', '.gradle', '.mvn', 'output'
}