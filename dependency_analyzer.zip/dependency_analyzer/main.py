"""
Main entry point for dependency analyzer
"""

import sys
from pathlib import Path

from graph_builder import DependencyGraphBuilder
from analyzer import ProjectAnalyzer
from exporter import ResultExporter
from visualizer import DependencyVisualizer


def analyze_project(project_path: str):
    """
    Analyze a project and generate all outputs
    
    Args:
        project_path: Path to project directory
    """
    print("\n" + "="*60)
    print(f"DEPENDENCY ANALYZER")
    print("="*60)
    
    # Build dependency graph
    builder = DependencyGraphBuilder()
    graph = builder.build_from_directory(project_path)
    
    if graph.number_of_nodes() == 0:
        print("\n❌ No source files found!")
        return
    
    # Analyze project
    analyzer = ProjectAnalyzer(graph, builder)
    analyzer.analyze()
    
    # Export results
    exporter = ResultExporter(graph, builder)
    exporter.export_all()
    
    # Create visualizations
    visualizer = DependencyVisualizer(graph)
    visualizer.create_interactive_html()
    
    if graph.number_of_nodes() <= 50:
        visualizer.plot_matplotlib_graph()
    
    visualizer.plot_statistics()
    
    print("\n" + "="*60)
    print("✅ ANALYSIS COMPLETE")
    print("="*60)
    print(f"\nResults saved to: output/")
    print("  • dependency_graph.json - Full graph data")
    print("  • file_dependencies_detailed.csv - File analysis")
    print("  • functions_list.csv - All functions")
    print("  • function_calls_detailed.csv - Function call mapping")
    print("  • dependency_graph.html - Interactive visualization")
    print("  • statistics.png - Statistical plots")
    if graph.number_of_nodes() <= 50:
        print("  • graph_matplotlib.png - Static graph visualization")
    
    return builder, graph, analyzer


def main(project_path):
    """Main function"""
    # if len(sys.argv) < 2:
    #     print("Usage: python main.py <project_path>")
    #     print("\nExample:")
    #     print("  python main.py ./demo_project")
    #     print("  python main.py /path/to/your/project")
    #     sys.exit(1)
    
    # project_path = sys.argv[1]
    
    try:
        analyze_project(project_path)
    except KeyboardInterrupt:
        print("\n\n⚠️  Analysis interrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    project_path = r"C:\Users\ABHISHEK SANODIYA\Desktop\Dependency\employee-attendance"
    main(project_path)