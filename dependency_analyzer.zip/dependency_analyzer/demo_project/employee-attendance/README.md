# employee-attendance
Visual C# employee attendance system

username: root
password: pass
