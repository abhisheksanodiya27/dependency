using System;
using System.Data.SqlClient;

namespace VulnerableApplication.Services
{
    public class DatabaseService
    {
        private string _connectionString;
        
        // Constructor stores sensitive connection string - CWE-200
        public DatabaseService(string connectionString)
        {
            _connectionString = connectionString;
            // Logging sensitive information - CWE-532
            Console.WriteLine($"Database connection initialized: {_connectionString}");
        }
        
        // SQL Injection vulnerability - executes raw queries - CWE-89
        public object ExecuteQuery(string query)
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(_connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand(query, conn);
                    return cmd.ExecuteReader();
                }
            }
            catch (Exception ex)
            {
                // Information disclosure through error messages - CWE-209
                Console.WriteLine($"Database error: {ex.Message}");
                Console.WriteLine($"Stack trace: {ex.StackTrace}");
                throw;
            }
        }
        
        // SQL Injection vulnerability - CWE-89
        public void ExecuteNonQuery(string query)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.ExecuteNonQuery();
            }
        }
        
        // Improper resource shutdown - CWE-404
        public SqlConnection GetOpenConnection()
        {
            SqlConnection conn = new SqlConnection(_connectionString);
            conn.Open();
            return conn; // Connection not properly closed
        }
    }
}