using System;
using System.Security.Cryptography;
using System.Text;
using VulnerableApplication.Utils;
using VulnerableApplication.Services;

namespace VulnerableApplication.Services
{
    public class AuthenticationService
    {
        private DatabaseService _dbService;
        private CryptoHelper _cryptoHelper;
        
        public AuthenticationService(DatabaseService dbService)
        {
            _dbService = dbService;
            _cryptoHelper = new CryptoHelper();
        }
        
        // Uses weak hashing algorithm - CWE-327
        public string HashPassword(string password)
        {
            return _cryptoHelper.WeakHash(password);
        }
        
        // Insecure random number generation - CWE-330
        public string GenerateSessionToken()
        {
            Random random = new Random();
            int token = random.Next(1000, 9999);
            return token.ToString();
        }
        
        // Session fixation vulnerability - CWE-384
        public void CreateSession(string username)
        {
            string sessionId = GenerateSessionToken();
            
            // Store in database without regenerating session ID
            string query = $"INSERT INTO Sessions (Username, SessionId) VALUES ('{username}', '{sessionId}')";
            _dbService.ExecuteNonQuery(query);
            
            Console.WriteLine($"Session created: {sessionId}");
        }
        
        // Timing attack vulnerability - CWE-208
        public bool ValidatePassword(string inputPassword, string storedHash)
        {
            string inputHash = HashPassword(inputPassword);
            
            // String comparison vulnerable to timing attacks
            if (inputHash == storedHash)
            {
                return true;
            }
            return false;
        }
    }
}