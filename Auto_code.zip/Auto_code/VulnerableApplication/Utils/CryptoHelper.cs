using System;
using System.Security.Cryptography;
using System.Text;

namespace VulnerableApplication.Utils
{
    public class CryptoHelper
    {
        // Use of broken cryptographic algorithm - CWE-327
        public string WeakHash(string input)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    sb.Append(hashBytes[i].ToString("x2"));
                }
                return sb.ToString();
            }
        }
        
        // Weak encryption with hard-coded key - CWE-321, CWE-798
        public string Encrypt(string plainText)
        {
            // Hard-coded encryption key
            byte[] key = Encoding.UTF8.GetBytes("1234567890123456");
            byte[] iv = Encoding.UTF8.GetBytes("1234567890123456");
            
            using (Aes aes = Aes.Create())
            {
                aes.Key = key;
                aes.IV = iv;
                aes.Mode = CipherMode.ECB; // Insecure mode - CWE-327
                
                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
                byte[] plainBytes = Encoding.UTF8.GetBytes(plainText);
                byte[] encryptedBytes = encryptor.TransformFinalBlock(plainBytes, 0, plainBytes.Length);
                
                return Convert.ToBase64String(encryptedBytes);
            }
        }
        
        // Insecure random for security purposes - CWE-338
        public string GenerateToken()
        {
            Random rand = new Random();
            return rand.Next().ToString();
        }
    }
}