using System;
using VulnerableApplication.Controllers;
using VulnerableApplication.Services;

namespace VulnerableApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Vulnerable Application...");
            
            // Hard-coded credentials - CWE-798
            string adminPassword = "Admin@123";
            string connectionString = "Server=localhost;Database=UserDB;User Id=sa;Password=P@ssw0rd;";
            
            DatabaseService dbService = new DatabaseService(connectionString);
            AuthenticationService authService = new AuthenticationService(dbService);
            UserController userController = new UserController(authService, dbService);
            
            // Simulate user login
            userController.Login("admin", adminPassword);
            
            // Simulate user registration
            userController.Register("newuser", "password123", "user@example.com");
            
            Console.WriteLine("Application running...");
            Console.ReadLine();
        }
    }
}