"""
Dependency Checker Agent
Analyzes if dependency files are required to fix a vulnerability
"""

import json
from openai import OpenAI


def check_dependency_requirements(project_tree, file_path, file_code, vulnerability, api_key):
    """
    Check if fixing the vulnerability requires other dependency files
    
    Args:
        project_tree: Project directory structure
        file_path: Path to the vulnerable file
        file_code: Content of the vulnerable file
        vulnerability: Vulnerability details dictionary
        api_key: OpenAI API key
        
    Returns:
        Dictionary with dependency requirements
    """
    client = OpenAI(api_key=api_key)
    
    prompt = build_dependency_check_prompt(
        project_tree=project_tree,
        file_path=file_path,
        file_code=file_code,
        vulnerability=vulnerability
    )
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": "You are a senior security engineer and code analyzer. Analyze if fixing a vulnerability requires access to other project files."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return result
        
    except Exception as e:
        print(f"Error in dependency check: {str(e)}")
        return {
            "requires_dependencies": False,
            "required_files": [],
            "reasoning": f"Error occurred: {str(e)}"
        }


def build_dependency_check_prompt(project_tree, file_path, file_code, vulnerability):
    """Build the prompt for dependency checking"""
    
    return f"""You are analyzing a vulnerability to determine if fixing it requires access to other project files.

PROJECT TREE:
{project_tree}

TARGET FILE PATH:
{file_path}

TARGET FILE CODE:
```
{file_code}
```

VULNERABILITY DETAILS:
- Type: {vulnerability['Vulnerability_Type']}
- CWE ID: {vulnerability['CWE_ID']}
- Line Number: {vulnerability['Line_Number']}
- Function: {vulnerability['Function_Name']}
- Description: {vulnerability['Vulnerability_Description']}
- Affected Code: {vulnerability['Affected_Code']}
- Recommendation: {vulnerability['Recommendation']}
- Dependency Chain: {vulnerability['Dependency_Chain']}

ANALYSIS TASK:
1. Analyze the vulnerability and the recommended fix
2. Determine if fixing this vulnerability requires understanding or modifying code in OTHER files
3. If yes, identify which files from the project tree are needed
4. Explain WHY each file is needed

RULES:
- Use ONLY files that exist in the provided project tree
- Consider the dependency chain mentioned in the vulnerability
- If the fix can be done entirely within the target file, set requires_dependencies to false
- Be specific about which files are needed and why

OUTPUT FORMAT (JSON):
{{
  "requires_dependencies": true/false,
  "required_files": [
    {{
      "file_path": "Services/DatabaseService.cs",
      "reason": "Need to see how ExecuteQuery is implemented to ensure parameterized queries",
      "confidence": "high"
    }}
  ],
  "reasoning": "Explain your decision here"
}}

Return ONLY valid JSON, no markdown formatting."""


def extract_internal_dependencies(project_tree, file_path, file_code, api_key):
    """
    Extract internal file dependencies from imports/usings
    
    Args:
        project_tree: Project structure
        file_path: Current file path
        file_code: File content
        api_key: OpenAI API key
        
    Returns:
        Dictionary with internal and external dependencies
    """
    client = OpenAI(api_key=api_key)
    
    prompt = f"""Analyze this C# file and identify all internal project dependencies.

PROJECT TREE:
{project_tree}

FILE PATH:
{file_path}

FILE CODE:
```
{file_code}
```

TASK:
1. Extract all 'using' statements
2. Match them against the project tree to identify internal files
3. Return the probable file paths for internal dependencies
4. Separate external framework/library dependencies

OUTPUT (JSON):
{{
  "internal_dependencies": [
    {{
      "using_statement": "VulnerableApp.Services",
      "probable_path": "Services/DatabaseService.cs",
      "confidence": "high"
    }}
  ],
  "external_dependencies": ["System", "System.Data.SqlClient"],
  "unresolved": []
}}"""
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a code dependency analyzer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0,
            response_format={"type": "json_object"}
        )
        
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        return {
            "internal_dependencies": [],
            "external_dependencies": [],
            "unresolved": [],
            "error": str(e)
        }