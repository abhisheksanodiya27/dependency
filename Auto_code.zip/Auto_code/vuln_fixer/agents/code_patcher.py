"""
Code Patcher Agent
Applies the generated fixes to the original code
"""


def apply_code_patch(original_code, changes):
    """
    Apply code changes to the original code
    
    Args:
        original_code: Original code content
        changes: List of change dictionaries from the fixer
        
    Returns:
        Patched code string
    """
    lines = original_code.split('\n')
    
    # Sort changes by line number in reverse order to avoid index shifting
    sorted_changes = sorted(changes, key=lambda x: x.get('line_number', 0), reverse=True)
    
    for change in sorted_changes:
        change_type = change.get('change_type', 'replace')
        line_num = change.get('line_number', 0)
        old_code = change.get('old_code', '')
        new_code = change.get('new_code', '')
        
        if change_type == 'replace':
            lines = apply_replace(lines, line_num, old_code, new_code)
        elif change_type == 'add':
            lines = apply_add(lines, line_num, new_code)
        elif change_type == 'delete':
            lines = apply_delete(lines, line_num, old_code)
    
    return '\n'.join(lines)


def apply_replace(lines, line_num, old_code, new_code):
    """
    Replace code at specified line
    
    Args:
        lines: List of code lines
        line_num: Line number (1-indexed)
        old_code: Code to find and replace
        new_code: New code to insert
        
    Returns:
        Modified lines list
    """
    if line_num < 1 or line_num > len(lines):
        print(f"Warning: Line number {line_num} out of range")
        return lines
    
    # Try exact line match first
    idx = line_num - 1
    if old_code.strip() in lines[idx]:
        lines[idx] = lines[idx].replace(old_code.strip(), new_code)
        return lines
    
    # Try to find the code in nearby lines
    search_range = 5
    start = max(0, idx - search_range)
    end = min(len(lines), idx + search_range + 1)
    
    for i in range(start, end):
        if old_code.strip() in lines[i]:
            lines[i] = lines[i].replace(old_code.strip(), new_code)
            return lines
    
    # If old_code not found, try multi-line replacement
    old_lines = old_code.split('\n')
    if len(old_lines) > 1:
        for i in range(len(lines) - len(old_lines) + 1):
            match = True
            for j, old_line in enumerate(old_lines):
                if old_line.strip() not in lines[i + j]:
                    match = False
                    break
            
            if match:
                # Remove old lines and insert new code
                for _ in range(len(old_lines)):
                    lines.pop(i)
                
                new_lines = new_code.split('\n')
                for j, new_line in enumerate(new_lines):
                    lines.insert(i + j, new_line)
                
                return lines
    
    # If still not found, insert at the specified line
    print(f"Warning: Could not find exact match for old_code at line {line_num}, inserting new code")
    lines[idx] = new_code
    
    return lines


def apply_add(lines, line_num, new_code):
    """
    Add new code at specified line
    
    Args:
        lines: List of code lines
        line_num: Line number where to insert (1-indexed)
        new_code: Code to insert
        
    Returns:
        Modified lines list
    """
    if line_num < 1:
        line_num = 1
    if line_num > len(lines):
        line_num = len(lines)
    
    idx = line_num - 1
    new_lines = new_code.split('\n')
    
    # Insert in reverse order to maintain positions
    for i, new_line in enumerate(reversed(new_lines)):
        lines.insert(idx, new_line)
    
    return lines


def apply_delete(lines, line_num, old_code):
    """
    Delete code at specified line
    
    Args:
        lines: List of code lines
        line_num: Line number to delete (1-indexed)
        old_code: Code to verify before deletion
        
    Returns:
        Modified lines list
    """
    if line_num < 1 or line_num > len(lines):
        print(f"Warning: Line number {line_num} out of range")
        return lines
    
    idx = line_num - 1
    
    # Verify the code matches before deleting
    if old_code.strip() in lines[idx]:
        lines.pop(idx)
    else:
        # Try to find in nearby lines
        search_range = 3
        start = max(0, idx - search_range)
        end = min(len(lines), idx + search_range + 1)
        
        for i in range(start, end):
            if old_code.strip() in lines[i]:
                lines.pop(i)
                return lines
        
        print(f"Warning: Could not find old_code to delete at line {line_num}")
    
    return lines


def smart_patch(original_code, changes):
    """
    Advanced patching with fuzzy matching and context awareness
    
    Args:
        original_code: Original code
        changes: List of changes
        
    Returns:
        Patched code
    """
    lines = original_code.split('\n')
    
    # Group changes by proximity
    grouped_changes = group_changes_by_context(changes)
    
    for group in grouped_changes:
        lines = apply_change_group(lines, group)
    
    return '\n'.join(lines)


def group_changes_by_context(changes, proximity=5):
    """Group changes that are close to each other"""
    if not changes:
        return []
    
    sorted_changes = sorted(changes, key=lambda x: x.get('line_number', 0))
    groups = []
    current_group = [sorted_changes[0]]
    
    for change in sorted_changes[1:]:
        prev_line = current_group[-1].get('line_number', 0)
        curr_line = change.get('line_number', 0)
        
        if curr_line - prev_line <= proximity:
            current_group.append(change)
        else:
            groups.append(current_group)
            current_group = [change]
    
    groups.append(current_group)
    return groups


def apply_change_group(lines, group):
    """Apply a group of related changes together"""
    # Sort in reverse to avoid index shifting
    sorted_group = sorted(group, key=lambda x: x.get('line_number', 0), reverse=True)
    
    for change in sorted_group:
        change_type = change.get('change_type', 'replace')
        
        if change_type == 'replace':
            lines = apply_replace(
                lines,
                change['line_number'],
                change['old_code'],
                change['new_code']
            )
        elif change_type == 'add':
            lines = apply_add(
                lines,
                change['line_number'],
                change['new_code']
            )
        elif change_type == 'delete':
            lines = apply_delete(
                lines,
                change['line_number'],
                change['old_code']
            )
    
    return lines


def validate_patch(original_code, patched_code):
    """
    Validate that the patch was applied successfully
    
    Args:
        original_code: Original code
        patched_code: Patched code
        
    Returns:
        Dictionary with validation results
    """
    original_lines = original_code.split('\n')
    patched_lines = patched_code.split('\n')
    
    return {
        "original_line_count": len(original_lines),
        "patched_line_count": len(patched_lines),
        "lines_changed": len(patched_lines) - len(original_lines),
        "is_valid": len(patched_lines) > 0,
        "patch_applied": original_code != patched_code
    }