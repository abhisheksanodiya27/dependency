"""
Method-Based Code Fixer - Handles single or multiple vulnerabilities per method
"""

from core.gpt_client import create_gpt_client
from prompts.code_fixer_prompts import SYSTEM_PROMPT, USER_PROMPT_SINGLE, USER_PROMPT_MULTIPLE
from utils.method_extractor import parse_line_range, find_method_containing_lines


def generate_method_fix_multiple(vulnerabilities, full_code, dependency_files, file_path, api_key, method_signature=None):
    """
    Fix multiple vulnerabilities in same method at once
    
    Args:
        vulnerabilities: List of vulnerability dicts (all in same method)
        full_code: Complete file code
        dependency_files: Dict of dependencies
        file_path: Path to file
        api_key: OpenAI API key
        method_signature: Optional method signature for finding method in modified code
        
    Returns:
        Dict with fix result
    """
    gpt = create_gpt_client(api_key)
    
    # Get method info - use signature if provided, otherwise use line numbers
    if method_signature:
        # Find method by signature (for cached/modified files)
        method_info = find_method_by_signature(full_code, method_signature)
    else:
        # Find method by line numbers (for original files)
        first_vuln = vulnerabilities[0]
        start_line, end_line = parse_line_range(first_vuln['Line_Number'])
        method_info = find_method_containing_lines(full_code, start_line, end_line)
    
    if not method_info:
        return {
            'method_info': None,
            'fixed_method': None,
            'error': 'Method not found'
        }
    
    print(f"  → Method: {method_info['name']} (lines {method_info['start_line']}-{method_info['end_line']})")
    print(f"  → Fixing {len(vulnerabilities)} vulnerabilities in one iteration")
    
    # Build dependency context
    dependency_context = ""
    if dependency_files:
        dependency_context = "\n\n".join([
            f"--- {path} ---\n{code}" 
            for path, code in dependency_files.items()
        ])
    else:
        dependency_context = "None"
    
    # Format vulnerabilities list
    vuln_list = []
    for i, vuln in enumerate(vulnerabilities, 1):
        vuln_list.append(
            f"{i}. {vuln['Vulnerability_Type']} (CWE-{vuln['CWE_ID']}) at line {vuln['Line_Number']}\n"
            f"   Description: {vuln['Vulnerability_Description']}\n"
            f"   Affected: {vuln['Affected_Code']}"
        )
    vulnerabilities_text = '\n\n'.join(vuln_list)
    
    # Choose prompt based on count
    if len(vulnerabilities) == 1:
        vuln = vulnerabilities[0]
        user_prompt = USER_PROMPT_SINGLE.format(
            full_code=full_code,
            method_code=method_info['code'],
            vuln_type=vuln['Vulnerability_Type'],
            line_number=vuln['Line_Number']
        )
    else:
        user_prompt = USER_PROMPT_MULTIPLE.format(
            full_code=full_code,
            dependency_context=dependency_context,
            method_code=method_info['code'],
            vulnerabilities_list=vulnerabilities_text,
            vuln_count=len(vulnerabilities)
        )
    
    try:
        result = gpt.get_json_response(SYSTEM_PROMPT, user_prompt)
        
        return {
            'method_info': method_info,
            'fixed_method': result.get('fixed_method', ''),
            'summary': result.get('summary', f"Fixed {len(vulnerabilities)} vulnerabilities"),
            'vulnerabilities_fixed': len(vulnerabilities)
        }
        
    except Exception as e:
        print(f"  ✗ Error: {str(e)}")
        return {
            'method_info': method_info,
            'fixed_method': None,
            'error': str(e)
        }


def find_method_by_signature(code, signature):
    """
    Find method in code by signature
    Used when line numbers don't match (cached/modified files)
    """
    from utils.method_extractor import find_method_end
    
    lines = code.split('\n')
    normalized_sig = ' '.join(signature.split())
    
    # Find method start by signature
    method_start = None
    method_name = None
    
    for i, line in enumerate(lines):
        line_normalized = ' '.join(line.strip().split())
        if normalized_sig in line_normalized or line_normalized in normalized_sig:
            method_start = i
            # Extract method name
            if '(' in line:
                before_paren = line.split('(')[0]
                words = before_paren.split()
                if words:
                    method_name = words[-1]
            break
    
    if method_start is None:
        return None
    
    # Find method end
    method_end = find_method_end(lines, method_start)
    if method_end is None:
        return None
    
    # Extract method code
    method_code = '\n'.join(lines[method_start:method_end + 1])
    
    return {
        'name': method_name,
        'start_line': method_start + 1,
        'end_line': method_end + 1,
        'code': method_code,
        'indent_level': len(lines[method_start]) - len(lines[method_start].lstrip())
    }