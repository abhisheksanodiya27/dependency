"""
Code Fixer Agent
Generates vulnerability fixes using GPT-4o with context from dependency files
"""

import json
from openai import OpenAI


def generate_code_fix(vulnerability, vulnerable_code, dependency_files, file_path, api_key):
    """
    Generate a fix for the vulnerability using LLM
    
    Args:
        vulnerability: Vulnerability details dictionary
        vulnerable_code: Original vulnerable code
        dependency_files: Dictionary of {file_path: file_content} for context
        file_path: Path to the file being fixed
        api_key: OpenAI API key
        
    Returns:
        Dictionary with fix details including specific code changes
    """
    client = OpenAI(api_key=api_key)
    
    prompt = build_fix_generation_prompt(
        vulnerability=vulnerability,
        vulnerable_code=vulnerable_code,
        dependency_files=dependency_files,
        file_path=file_path
    )
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {
                    "role": "system",
                    "content": """You are a senior security engineer specializing in fixing code vulnerabilities.
Your task is to generate PRECISE code changes to fix security vulnerabilities.

CRITICAL RULES:
1. Return ONLY the specific code changes needed, not the entire file
2. Include exact line numbers where changes should be applied
3. Provide both the code to REMOVE and code to ADD
4. Ensure the fix follows security best practices
5. Maintain code style and formatting
6. Add security comments where appropriate"""
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0,
            response_format={"type": "json_object"}
        )
        
        result = json.loads(response.choices[0].message.content)
        return result
        
    except Exception as e:
        print(f"Error generating fix: {str(e)}")
        return {
            "changes": [],
            "summary": f"Error occurred: {str(e)}",
            "risk_assessment": "unknown"
        }


def build_fix_generation_prompt(vulnerability, vulnerable_code, dependency_files, file_path):
    """Build the prompt for fix generation"""
    
    # Build dependency context section
    dependency_context = ""
    if dependency_files:
        dependency_context = "\n\nDEPENDENCY FILES FOR CONTEXT:\n"
        for dep_path, dep_code in dependency_files.items():
            dependency_context += f"\n--- {dep_path} ---\n{dep_code}\n"
    
    prompt = f"""Fix the following security vulnerability with PRECISE code changes.

FILE PATH:
{file_path}

VULNERABLE CODE (with line numbers):
```
{add_line_numbers(vulnerable_code)}
```
{dependency_context}

VULNERABILITY DETAILS:
- Type: {vulnerability['Vulnerability_Type']}
- CWE ID: {vulnerability['CWE_ID']}
- Severity: {vulnerability['Severity']} (CVSS: {vulnerability['CVSS_Score']})
- Line Number: {vulnerability['Line_Number']}
- Function: {vulnerability['Function_Name']}
- Description: {vulnerability['Vulnerability_Description']}
- Affected Code: {vulnerability['Affected_Code']}
- Recommendation: {vulnerability['Recommendation']}
- References: {vulnerability['References']}

TASK:
Generate the EXACT code changes needed to fix this vulnerability.

REQUIREMENTS:
1. Identify the exact lines that need to be changed
2. Provide the OLD code to remove (exact match)
3. Provide the NEW code to add
4. Include security comments explaining the fix
5. Ensure the fix addresses the root cause
6. Maintain existing code structure and style
7. If multiple changes are needed, provide them all

OUTPUT FORMAT (JSON):
{{
  "changes": [
    {{
      "line_number": 21,
      "change_type": "replace",
      "old_code": "string query = \\"SELECT * FROM Users WHERE Username = '\\" + username + \\"'\\";",
      "new_code": "// Use parameterized queries to prevent SQL injection\\nstring query = \\"SELECT * FROM Users WHERE Username = @username\\";\\nSqlCommand cmd = new SqlCommand(query, conn);\\ncmd.Parameters.AddWithValue(\\"@username\\", username);",
      "reason": "Replaced string concatenation with parameterized query to prevent SQL injection"
    }},
    {{
      "line_number": 15,
      "change_type": "add",
      "old_code": "",
      "new_code": "using System.Data.SqlClient;",
      "reason": "Added required using statement for SqlParameter"
    }}
  ],
  "summary": "Fixed SQL injection by implementing parameterized queries",
  "risk_assessment": "Changes are safe and do not affect other functionality",
  "additional_recommendations": "Consider implementing input validation and using an ORM like Entity Framework"
}}

CHANGE TYPES:
- "replace": Replace old_code with new_code
- "add": Insert new_code at line_number
- "delete": Remove old_code at line_number

Return ONLY valid JSON."""

    return prompt


def add_line_numbers(code):
    """Add line numbers to code for reference"""
    lines = code.split('\n')
    numbered_lines = []
    for i, line in enumerate(lines, 1):
        numbered_lines.append(f"{i:4d} | {line}")
    return '\n'.join(numbered_lines)


def validate_fix(original_code, fixed_code, vulnerability, api_key):
    """
    Validate that the fix properly addresses the vulnerability
    
    Args:
        original_code: Original vulnerable code
        fixed_code: Fixed code
        vulnerability: Vulnerability details
        api_key: OpenAI API key
        
    Returns:
        Dictionary with validation results
    """
    client = OpenAI(api_key=api_key)
    
    prompt = f"""Validate that this vulnerability fix is correct and complete.

VULNERABILITY:
- Type: {vulnerability['Vulnerability_Type']}
- CWE: {vulnerability['CWE_ID']}
- Description: {vulnerability['Vulnerability_Description']}

ORIGINAL CODE:
```
{original_code}
```

FIXED CODE:
```
{fixed_code}
```

VALIDATION CHECKLIST:
1. Does the fix address the root cause of the vulnerability?
2. Are there any new vulnerabilities introduced?
3. Is the code functionally equivalent (same behavior)?
4. Are best practices followed?
5. Is the fix complete or are additional changes needed?

OUTPUT (JSON):
{{
  "is_valid": true/false,
  "addresses_vulnerability": true/false,
  "introduces_new_issues": false/true,
  "maintains_functionality": true/false,
  "follows_best_practices": true/false,
  "confidence_score": 0.95,
  "issues_found": [],
  "recommendations": []
}}"""
    
    try:
        response = client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are a security code reviewer."},
                {"role": "user", "content": prompt}
            ],
            temperature=0,
            response_format={"type": "json_object"}
        )
        
        return json.loads(response.choices[0].message.content)
    except Exception as e:
        return {
            "is_valid": False,
            "error": str(e)
        }