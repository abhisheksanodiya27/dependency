"""
File Utilities
Handles file I/O and project tree generation
"""

import os


def read_file(file_path):
    """Read file content"""
    with open(file_path, 'r', encoding='utf-8') as f:
        return f.read()


def write_file(file_path, content):
    """Write content to file, creating directories if needed"""
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    with open(file_path, 'w', encoding='utf-8') as f:
        f.write(content)


def generate_project_tree(root_path, max_depth=3):
    """Generate project tree structure"""
    tree_lines = []
    
    def walk_directory(path, prefix="", depth=0):
        if depth > max_depth:
            return
        
        try:
            items = sorted(os.listdir(path))
        except PermissionError:
            return
        
        # Filter out common non-source directories
        excluded = {'.git', '.vs', 'bin', 'obj', 'node_modules', '__pycache__', '.idea'}
        items = [item for item in items if item not in excluded and not item.startswith('.')]
        
        for i, item in enumerate(items):
            item_path = os.path.join(path, item)
            is_last = i == len(items) - 1
            
            current_prefix = "└── " if is_last else "├── "
            tree_lines.append(f"{prefix}{current_prefix}{item}")
            
            if os.path.isdir(item_path):
                extension_prefix = "    " if is_last else "│   "
                walk_directory(item_path, prefix + extension_prefix, depth + 1)
    
    tree_lines.append(os.path.basename(root_path))
    walk_directory(root_path, "", 0)
    
    return '\n'.join(tree_lines)