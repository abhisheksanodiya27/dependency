"""
File Utilities
Handle file operations and project tree generation
"""

import os


EXCLUDE_DIRS = {
    "venv", "__pycache__", ".git", "node_modules", 
    "bin", "obj", ".vs", "packages", "dist", "build"
}

EXCLUDE_FILES = {
    ".gitignore", ".env", "*.pyc", "*.pyo", "*.pyd",
    ".DS_Store", "Thumbs.db", "desktop.ini"
}


def generate_project_tree(root_path, max_depth=5, level=0, prefix=""):
    """
    Generate a tree structure of the project directory
    
    Args:
        root_path: Root directory path
        max_depth: Maximum depth to traverse
        level: Current depth level
        prefix: Prefix for tree formatting
        
    Returns:
        String representation of directory tree
    """
    if level > max_depth:
        return ""
    
    if not os.path.exists(root_path):
        return f"Error: Path not found - {root_path}\n"
    
    tree = ""
    
    try:
        items = sorted(os.listdir(root_path))
    except PermissionError:
        return f"{prefix}[Permission Denied]\n"
    
    # Filter out excluded items
    items = [item for item in items if item not in EXCLUDE_DIRS]
    
    for i, item in enumerate(items):
        path = os.path.join(root_path, item)
        is_last = i == len(items) - 1
        
        # Tree characters
        connector = "└── " if is_last else "├── "
        extension = "    " if is_last else "│   "
        
        tree += f"{prefix}{connector}{item}\n"
        
        # Recurse for directories
        if os.path.isdir(path):
            tree += generate_project_tree(
                path, 
                max_depth, 
                level + 1, 
                prefix + extension
            )
    
    return tree


def read_file(file_path):
    """
    Read file content with encoding handling
    
    Args:
        file_path: Path to file
        
    Returns:
        File content as string
    """
    encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
        except Exception as e:
            raise Exception(f"Error reading file {file_path}: {str(e)}")
    
    raise Exception(f"Could not decode file {file_path} with any encoding")


def write_file(file_path, content):
    """
    Write content to file
    
    Args:
        file_path: Path to file
        content: Content to write
    """
    try:
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
    except Exception as e:
        raise Exception(f"Error writing file {file_path}: {str(e)}")


def get_file_info(file_path):
    """
    Get file information
    
    Args:
        file_path: Path to file
        
    Returns:
        Dictionary with file info
    """
    if not os.path.exists(file_path):
        return None
    
    stat = os.stat(file_path)
    
    return {
        "path": file_path,
        "size": stat.st_size,
        "modified": stat.st_mtime,
        "is_file": os.path.isfile(file_path),
        "is_dir": os.path.isdir(file_path),
        "extension": os.path.splitext(file_path)[1]
    }


def list_files_recursively(root_path, extensions=None):
    """
    List all files in directory recursively
    
    Args:
        root_path: Root directory
        extensions: List of file extensions to include (e.g., ['.cs', '.py'])
        
    Returns:
        List of file paths
    """
    files = []
    
    for root, dirs, filenames in os.walk(root_path):
        # Remove excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        
        for filename in filenames:
            if extensions:
                if any(filename.endswith(ext) for ext in extensions):
                    files.append(os.path.join(root, filename))
            else:
                files.append(os.path.join(root, filename))
    
    return files


def backup_file(file_path):
    """
    Create a backup of the file
    
    Args:
        file_path: Path to file to backup
        
    Returns:
        Path to backup file
    """
    if not os.path.exists(file_path):
        raise Exception(f"File not found: {file_path}")
    
    backup_path = f"{file_path}.backup"
    counter = 1
    
    while os.path.exists(backup_path):
        backup_path = f"{file_path}.backup{counter}"
        counter += 1
    
    content = read_file(file_path)
    write_file(backup_path, content)
    
    return backup_path


def compare_files(file1_path, file2_path):
    """
    Compare two files
    
    Args:
        file1_path: First file path
        file2_path: Second file path
        
    Returns:
        Dictionary with comparison results
    """
    content1 = read_file(file1_path)
    content2 = read_file(file2_path)
    
    lines1 = content1.split('\n')
    lines2 = content2.split('\n')
    
    differences = []
    max_lines = max(len(lines1), len(lines2))
    
    for i in range(max_lines):
        line1 = lines1[i] if i < len(lines1) else ""
        line2 = lines2[i] if i < len(lines2) else ""
        
        if line1 != line2:
            differences.append({
                "line_number": i + 1,
                "file1": line1,
                "file2": line2
            })
    
    return {
        "identical": len(differences) == 0,
        "total_differences": len(differences),
        "file1_lines": len(lines1),
        "file2_lines": len(lines2),
        "differences": differences[:10]  # First 10 differences
    }


def get_relative_path(file_path, root_path):
    """
    Get relative path from root
    
    Args:
        file_path: Absolute file path
        root_path: Root directory path
        
    Returns:
        Relative path string
    """
    return os.path.relpath(file_path, root_path)


def ensure_directory_exists(directory_path):
    """
    Ensure directory exists, create if not
    
    Args:
        directory_path: Directory path
    """
    os.makedirs(directory_path, exist_ok=True)