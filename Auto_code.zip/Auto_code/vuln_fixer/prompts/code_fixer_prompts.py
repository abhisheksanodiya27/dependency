"""
Prompts for Method-Based Code Fixer - Handles Multiple Vulnerabilities
"""

SYSTEM_PROMPT = """You are a senior security engineer.

RULES:
1. Return COMPLETE fixed method
2. Fix ALL vulnerabilities listed
3. Use ONLY existing variables (_dbService, _authService)
4. NEVER create: SqlConnection, SqlCommand, conn, connection
5. Maintain original indentation"""


USER_PROMPT_SINGLE = """Fix vulnerability in this method.

ENTIRE FILE:
```csharp
{full_code}
```

METHOD TO FIX:
```csharp
{method_code}
```

VULNERABILITY: {vuln_type} at line {line_number}

OUTPUT JSON:
{{
  "fixed_method": "complete method code here"
}}

Use ONLY _dbService. NO SqlConnection."""


USER_PROMPT_MULTIPLE = """Fix ALL vulnerabilities in this method in ONE iteration.

ENTIRE FILE:
```csharp
{full_code}
```

DEPENDENCIES:
{dependency_context}

METHOD TO FIX:
```csharp
{method_code}
```

VULNERABILITIES TO FIX (ALL OF THEM):
{vulnerabilities_list}

CRITICAL:
1. Fix ALL {vuln_count} vulnerabilities listed above
2. Return COMPLETE fixed method
3. Use ONLY _dbService and _authService
4. NO SqlConnection, SqlCommand, conn

OUTPUT JSON:
{{
  "fixed_method": "complete fixed method with ALL vulnerabilities fixed",
  "summary": "Fixed {vuln_count} vulnerabilities: list them"
}}

Fix ALL issues in ONE method. Use _dbService ONLY."""