"""
Automated Vulnerability Fixer - ONE METHOD AT A TIME
"""

import os
import csv
import json
from config import OPENAI_API_KEY, PROJECT_ROOT, CSV_PATH, OUTPUT_DIR
from utils.file_utils import read_file, write_file, generate_project_tree
from agents.dependency_checker import check_dependencies


def load_vulnerabilities(csv_path):
    """Load vulnerabilities from CSV file"""
    vulnerabilities = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            vulnerabilities.append(row)
    return vulnerabilities


def process_single_method(group, project_tree, project_root, output_dir, api_key, fixed_files_cache):
    """Process and fix ONE method with all its vulnerabilities"""
    try:
        print(f"Step 1: Reading file: {group['file_path']}")
        
        file_path = os.path.join(project_root, group['file_path'])
        
        # Use previously fixed version if available
        if group['file_path'] in fixed_files_cache:
            code = fixed_files_cache[group['file_path']]
            print(f"✓ Using previously fixed version\n")
        elif os.path.exists(file_path):
            code = read_file(file_path)
            print(f"✓ Read original file\n")
        else:
            print(f"ERROR: File not found\n")
            return {"status": "failed", "error": "File not found"}
        
        # Step 2: Check dependencies
        print("Step 2: Analyzing dependencies...")
        first_vuln = group['vulnerabilities'][0]
        
        dep_result = check_dependencies(
            project_tree=project_tree,
            file_path=file_path,
            file_code=code,
            vulnerability=first_vuln,
            api_key=api_key
        )
        print(f"Requires dependencies: {dep_result['requires_dependencies']}\n")
        
        # Step 3: Load dependencies
        dependency_files = {}
        if dep_result['requires_dependencies']:
            print("Step 3: Loading dependencies...")
            for dep in dep_result.get('required_files', []):
                dep_path = os.path.join(project_root, dep['file_path'])
                if os.path.exists(dep_path):
                    dependency_files[dep['file_path']] = read_file(dep_path)
                print(f"  ✓ {dep['file_path']}")
            print()
        
        # Step 4: Fix this ONE method
        print(f"Step 4: Fixing method {group['method_name']} with {group['count']} vulnerabilities...")
        
        from agents.code_fixer import generate_method_fix_multiple
        from utils.method_extractor import replace_method_in_code
        
        fix_result = generate_method_fix_multiple(
            vulnerabilities=group['vulnerabilities'],
            full_code=code,
            dependency_files=dependency_files,
            file_path=file_path,
            api_key=api_key,
            method_signature=group.get('method_signature')
        )
        
        if not fix_result.get('fixed_method'):
            print(f"✗ Failed: {fix_result.get('error', 'Unknown error')}\n")
            return {
                "status": "failed",
                "file": group['file_path'],
                "method": group['method_name'],
                "error": fix_result.get('error', 'Unknown')
            }
        
        print(f"✓ Generated fix\n")
        
        # Step 5: Replace ONLY this method
        print("Step 5: Replacing method...")
        
        fixed_code = replace_method_in_code(
            code=code,
            old_method_code=fix_result['method_info']['code'],
            new_method_code=fix_result['fixed_method'],
            indent_level=fix_result['method_info'].get('indent_level', 0)
        )
        
        print(f"✓ Replaced method {group['method_name']}\n")
        
        # Update cache for next iteration
        fixed_files_cache[group['file_path']] = fixed_code
        
        # Step 6: Save
        print("Step 6: Saving...")
        output_path = os.path.join(output_dir, group['file_path'])
        write_file(output_path, fixed_code)
        print(f"✓ Saved: {output_path}\n")
        
        return {
            "status": "success",
            "file": group['file_path'],
            "method": group['method_name'],
            "vulnerabilities_fixed": group['count'],
            "output_path": output_path
        }
        
    except Exception as e:
        print(f"\nERROR: {str(e)}\n")
        return {
            "status": "failed",
            "file": group.get('file_path', 'unknown'),
            "method": group.get('method_name', 'unknown'),
            "error": str(e)
        }


def generate_report(results, output_dir):
    """Generate final report"""
    report_path = os.path.join(output_dir, "fix_report.json")
    
    successful = [r for r in results if r['status'] == 'success']
    failed = [r for r in results if r['status'] == 'failed']
    
    total_vulns_fixed = sum(r.get('vulnerabilities_fixed', 0) for r in successful)
    
    report = {
        "methods_processed": len(results),
        "successful": len(successful),
        "failed": len(failed),
        "total_vulnerabilities_fixed": total_vulns_fixed,
        "success_rate": f"{(len(successful)/len(results)*100):.1f}%" if results else "0%",
        "details": {
            "successful": successful,
            "failed": failed
        }
    }
    
    write_file(report_path, json.dumps(report, indent=2))
    return report


def main():
    """Main execution - ONE METHOD AT A TIME"""
    print("="*80)
    print("AUTOMATED VULNERABILITY FIXER - ONE METHOD AT A TIME")
    print("="*80)
    print(f"Project: {PROJECT_ROOT}")
    print(f"CSV: {CSV_PATH}")
    print(f"Output: {OUTPUT_DIR}")
    print("="*80)
    
    if OPENAI_API_KEY == "your-openai-api-key-here":
        print("\nERROR: Please set OPENAI_API_KEY in config.py")
        return
    
    # Load vulnerabilities
    print("\nLoading vulnerabilities...")
    vulnerabilities = load_vulnerabilities(CSV_PATH)
    print(f"Loaded {len(vulnerabilities)} vulnerabilities\n")
    
    # Generate project tree
    print("Generating project tree...")
    project_tree = generate_project_tree(PROJECT_ROOT)
    print("✓ Project tree generated\n")
    
    # Group vulnerabilities by method
    print("Grouping vulnerabilities by method...")
    from utils.vuln_grouper import group_vulnerabilities_by_function
    
    file_cache = {}
    grouped = group_vulnerabilities_by_function(vulnerabilities, PROJECT_ROOT, file_cache)
    
    print(f"✓ Grouped into {len(grouped)} methods")
    print(f"✓ Will fix ONE method per iteration\n")
    
    # Track fixed files across iterations
    fixed_files_cache = {}
    
    # Process ONE METHOD AT A TIME
    results = []
    for i, group in enumerate(grouped, 1):
        print(f"\n{'#'*80}")
        print(f"METHOD {i}/{len(grouped)}")
        print(f"{'#'*80}")
        print(f"File: {group['file_path']}")
        print(f"Method: {group['method_name']}")
        print(f"Vulnerabilities in this method: {group['count']}")
        
        for vuln in group['vulnerabilities']:
            print(f"  - {vuln['Vulnerability_Type']} at line {vuln['Line_Number']}")
        print()
        
        result = process_single_method(
            group=group,
            project_tree=project_tree,
            project_root=PROJECT_ROOT,
            output_dir=OUTPUT_DIR,
            api_key=OPENAI_API_KEY,
            fixed_files_cache=fixed_files_cache
        )
        
        results.append(result)
    
    # Generate report
    print(f"\n{'='*80}")
    print("GENERATING REPORT")
    print(f"{'='*80}\n")
    
    report = generate_report(results, OUTPUT_DIR)
    
    print(f"{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    print(f"Methods Processed: {report['methods_processed']}")
    print(f"Successful: {report['successful']}")
    print(f"Failed: {report['failed']}")
    print(f"Total Vulnerabilities Fixed: {report['total_vulnerabilities_fixed']}")
    print(f"Success Rate: {report['success_rate']}")
    print(f"{'='*80}\n")


if __name__ == "__main__":
    main()