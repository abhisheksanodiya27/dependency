"""
Automated Vulnerability Fixer - Main Entry Point
Fixes vulnerabilities from CSV using GPT-4o with dependency analysis
"""

import os
import csv
import json
from pathlib import Path
from agents.dependency_checker import check_dependency_requirements
from agents.code_fixer import generate_code_fix
from agents.code_patcher import apply_code_patch
from utils.file_utils import read_file, write_file, generate_project_tree
from utils.logger import log_info, log_error, log_success, log_warning

# Configuration
API_KEY = "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"  # Replace with your OpenAI API key


# ===== PROJECT PATHS =====
# Replace these paths with your actual project paths
PROJECT_ROOT = r"C:\Users\ABHISHEK SANODIYA\Desktop\Dependency\Auto_code\VulnerableApplication"
CSV_PATH = r"C:\Users\ABHISHEK SANODIYA\Desktop\Dependency\Auto_code\VulnerableApplication\vulnerability_report.csv"
OUTPUT_DIR = "output/fixed_code"



def load_vulnerabilities_from_csv(csv_path):
    """Load all vulnerabilities from CSV file"""
    log_info(f"Loading vulnerabilities from: {csv_path}")
    vulnerabilities = []
    
    try:
        with open(csv_path, 'r', encoding='utf-8') as file:
            reader = csv.DictReader(file)
            for row in reader:
                vulnerabilities.append(row)
        
        log_success(f"Loaded {len(vulnerabilities)} vulnerabilities")
        return vulnerabilities
    except Exception as e:
        log_error(f"Failed to load CSV: {str(e)}")
        return []


def process_single_vulnerability(vuln, project_tree, project_root, output_dir, api_key):
    """Process and fix a single vulnerability"""
    try:
        log_info("\n" + "="*80)
        log_info(f"Processing: {vuln['File_Name']} - Line {vuln['Line_Number']}")
        log_info(f"Vulnerability: {vuln['Vulnerability_Type']} ({vuln['CWE_ID']})")
        log_info(f"Severity: {vuln['Severity']} | CVSS: {vuln['CVSS_Score']}")
        log_info("="*80)
        
        # Step 1: Read the vulnerable file
        file_path = os.path.join(project_root, vuln['File_Path'])
        log_info(f"\nStep 1: Reading vulnerable file: {file_path}")
        
        if not os.path.exists(file_path):
            log_error(f"File not found: {file_path}")
            return {"status": "failed", "error": "File not found"}
        
        vulnerable_code = read_file(file_path)
        log_success(f"File loaded successfully ({len(vulnerable_code)} characters)")
        
        # Step 2: Check if dependency files are required
        log_info("\nStep 2: Analyzing dependency requirements...")
        dependency_result = check_dependency_requirements(
            project_tree=project_tree,
            file_path=file_path,
            file_code=vulnerable_code,
            vulnerability=vuln,
            api_key=api_key
        )
        
        log_info(f"Requires dependencies: {dependency_result['requires_dependencies']}")
        
        # Step 3: Load required dependency files
        dependency_files = {}
        if dependency_result['requires_dependencies']:
            log_info("\nStep 3: Loading required dependency files...")
            required_files = dependency_result.get('required_files', [])
            
            for dep_file in required_files:
                dep_path = os.path.join(project_root, dep_file['file_path'])
                if os.path.exists(dep_path):
                    dependency_files[dep_file['file_path']] = read_file(dep_path)
                    log_success(f"  ✓ Loaded: {dep_file['file_path']} ({dep_file['reason']})")
                else:
                    log_warning(f"  ✗ Not found: {dep_file['file_path']}")
        else:
            log_info("\nStep 3: No dependency files required")
        
        # Step 4: Generate the fix using LLM
        log_info("\nStep 4: Generating vulnerability fix using GPT-4o...")
        fix_result = generate_code_fix(
            vulnerability=vuln,
            vulnerable_code=vulnerable_code,
            dependency_files=dependency_files,
            file_path=file_path,
            api_key=api_key
        )
        
        log_success(f"Fix generated: {len(fix_result['changes'])} changes to apply")
        
        # Step 5: Apply the patch to the code
        log_info("\nStep 5: Applying code patch...")
        fixed_code = apply_code_patch(
            original_code=vulnerable_code,
            changes=fix_result['changes']
        )
        
        log_success("Patch applied successfully")
        
        # Step 6: Save the fixed file
        log_info("\nStep 6: Saving fixed file...")
        output_path = os.path.join(output_dir, vuln['File_Path'])
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        write_file(output_path, fixed_code)
        log_success(f"Fixed file saved: {output_path}")
        
        return {
            "status": "success",
            "file": vuln['File_Name'],
            "vulnerability": vuln['Vulnerability_Type'],
            "line": vuln['Line_Number'],
            "output_path": output_path,
            "changes_applied": len(fix_result['changes'])
        }
        
    except Exception as e:
        log_error(f"Failed to fix vulnerability: {str(e)}")
        import traceback
        log_error(traceback.format_exc())
        return {
            "status": "failed",
            "file": vuln.get('File_Name', 'unknown'),
            "vulnerability": vuln.get('Vulnerability_Type', 'unknown'),
            "error": str(e)
        }


def generate_fix_report(results, output_dir):
    """Generate a summary report of all fixes"""
    report_path = os.path.join(output_dir, "fix_report.json")
    
    successful = [r for r in results if r['status'] == 'success']
    failed = [r for r in results if r['status'] == 'failed']
    
    report = {
        "total_vulnerabilities": len(results),
        "successful_fixes": len(successful),
        "failed_fixes": len(failed),
        "success_rate": f"{(len(successful)/len(results)*100):.2f}%" if results else "0%",
        "details": {
            "successful": successful,
            "failed": failed
        }
    }
    
    write_file(report_path, json.dumps(report, indent=2))
    log_success(f"\nFix report saved: {report_path}")
    
    return report


def main():
    """Main execution flow"""
    log_info("="*80)
    log_info("AUTOMATED VULNERABILITY FIXER - Starting")
    log_info("="*80)
    log_info(f"Project Root: {PROJECT_ROOT}")
    log_info(f"CSV Path: {CSV_PATH}")
    log_info(f"Output Directory: {OUTPUT_DIR}")
    
    # Validate API key
    if API_KEY == "your-openai-api-key-here":
        log_error("\n⚠️  ERROR: Please set your OpenAI API key in main.py")
        return
    
    # Load vulnerabilities from CSV
    vulnerabilities = load_vulnerabilities_from_csv(CSV_PATH)
    if not vulnerabilities:
        log_error("No vulnerabilities found. Exiting.")
        return
    
    # Generate project tree once
    log_info("\nGenerating project tree structure...")
    project_tree = generate_project_tree(PROJECT_ROOT)
    log_success("Project tree generated")
    
    # Process each vulnerability
    results = []
    total = len(vulnerabilities)
    
    for idx, vuln in enumerate(vulnerabilities, 1):
        log_info(f"\n\n{'#'*80}")
        log_info(f"VULNERABILITY {idx}/{total}")
        log_info(f"{'#'*80}")
        
        result = process_single_vulnerability(
            vuln=vuln,
            project_tree=project_tree,
            project_root=PROJECT_ROOT,
            output_dir=OUTPUT_DIR,
            api_key=API_KEY
        )
        
        results.append(result)
    
    # Generate final report
    log_info("\n\n" + "="*80)
    log_info("GENERATING FINAL REPORT")
    log_info("="*80)
    
    report = generate_fix_report(results, OUTPUT_DIR)
    
    # Print summary
    log_info("\n" + "="*80)
    log_info("SUMMARY")
    log_info("="*80)
    log_info(f"Total Vulnerabilities: {report['total_vulnerabilities']}")
    log_success(f"Successfully Fixed: {report['successful_fixes']}")
    log_error(f"Failed: {report['failed_fixes']}")
    log_info(f"Success Rate: {report['success_rate']}")
    log_info("="*80)


if __name__ == "__main__":
    main()