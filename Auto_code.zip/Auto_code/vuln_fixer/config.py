"""
Configuration File
Central place for all configuration settings
"""

import os
from pathlib import Path

# ===== API CONFIGURATION =====
OPENAI_API_KEY = "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"
MODEL_NAME = "gpt-4o"
TEMPERATURE = 0

# ===== PROJECT PATHS =====
# Replace these paths with your actual project paths
PROJECT_ROOT = r"C:\Users\ABHISHEK SANODIYA\Desktop\Dependency\Auto_code\VulnerableApplication"
CSV_PATH = r"C:\Users\ABHISHEK SANODIYA\Desktop\Dependency\Auto_code\VulnerableApplication\vulnerability_report.csv"
OUTPUT_DIR = "output/fixed_code"

# ===== PROCESSING OPTIONS =====
MAX_DEPTH = 5  # Maximum depth for directory tree
PROCESS_ALL = True  # Set to False to process only specific vulnerabilities
MAX_RETRIES = 3  # Maximum retries for LLM calls

# ===== LOGGING =====
LOG_LEVEL = "INFO"  # DEBUG, INFO, WARNING, ERROR
LOG_FILE = "logs/execution.log"

# ===== FILTERING =====
# Process only specific severity levels (leave empty for all)
SEVERITY_FILTER = []  # e.g., ["CRITICAL", "HIGH"]

# Process only specific CWE IDs (leave empty for all)
CWE_FILTER = []  # e.g., ["CWE-89", "CWE-798"]

# Process only specific files (leave empty for all)
FILE_FILTER = []  # e.g., ["UserController.cs", "DatabaseService.cs"]

# ===== VALIDATION =====
def validate_config():
    """Validate configuration settings"""
    errors = []
    
    if OPENAI_API_KEY == "your-openai-api-key-here":
        errors.append("OPENAI_API_KEY not set. Please set your API key.")
    
    if not os.path.exists(CSV_PATH):
        errors.append(f"CSV file not found: {CSV_PATH}")
    
    # Note: PROJECT_ROOT might not exist in the current environment
    # This is just a placeholder for when the user sets their path
    
    return errors


def get_config_summary():
    """Get configuration summary"""
    return f"""
Configuration Summary:
=====================
API Key: {'*' * 10}{OPENAI_API_KEY[-4:] if len(OPENAI_API_KEY) > 4 else '****'}
Model: {MODEL_NAME}
Project Root: {PROJECT_ROOT}
CSV Path: {CSV_PATH}
Output Directory: {OUTPUT_DIR}
Max Depth: {MAX_DEPTH}
Severity Filter: {SEVERITY_FILTER if SEVERITY_FILTER else 'All'}
CWE Filter: {CWE_FILTER if CWE_FILTER else 'All'}
File Filter: {FILE_FILTER if FILE_FILTER else 'All'}
"""