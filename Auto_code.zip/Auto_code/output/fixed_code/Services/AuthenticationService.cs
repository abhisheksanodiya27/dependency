using System;
using System.Security.Cryptography;
using System.Text;
using VulnerableApplication.Utils;
using VulnerableApplication.Services;

namespace VulnerableApplication.Services
{
    public class AuthenticationService
    {
        private DatabaseService _dbService;
        private CryptoHelper _cryptoHelper;
        
        public AuthenticationService(DatabaseService dbService)
        {
            _dbService = dbService;
            _cryptoHelper = new CryptoHelper();
        }
        
        // Uses weak hashing algorithm - CWE-327
        public string HashPassword(string password)
        {
            return _cryptoHelper.StrongHash(password);
        }
        
        // Insecure random number generation - CWE-330
        public string GenerateSessionToken()
        {
            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            byte[] tokenData = new byte[16];
rng.GetBytes(tokenData);
string token = Convert.ToBase64String(tokenData);
            return token.ToString();
        }
        
        // Session fixation vulnerability - CWE-384
        public void CreateSession(string username)
        {
            string sessionId = GenerateSessionToken();
            
            // Store in database without regenerating session ID
            string query = $"INSERT INTO Sessions (Username, SessionId) VALUES ('{username}', '{sessionId}')";
            _dbService.ExecuteNonQuery(query);
            
            Console.WriteLine($"Session created: {sessionId}");
        }
        
        // Timing attack vulnerability - CWE-208
        public bool ValidatePassword(string inputPassword, string storedHash)
        {
            string inputHash = HashPassword(inputPassword);
            
            // String comparison vulnerable to timing attacks
            if (CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(inputHash), Encoding.UTF8.GetBytes(storedHash)))
            {
                return true;
            }
            return false;
        }
    }
}