using System;
using System.Security.Cryptography;
using System.Text;
using VulnerableApplication.Utils;
using VulnerableApplication.Services;

namespace VulnerableApplication.Services
{
    public class AuthenticationService
    {
        private DatabaseService _dbService;
        private CryptoHelper _cryptoHelper;
        
        public AuthenticationService(DatabaseService dbService)
        {
            _dbService = dbService;
            _cryptoHelper = new CryptoHelper();
        }
        
        // Uses strong hashing algorithm
        public string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        
        // Secure random number generation
        public string GenerateSessionToken()
        {
            using (var rng = new RNGCryptoServiceProvider())
            {
                byte[] tokenData = new byte[16];
                rng.GetBytes(tokenData);
                return Convert.ToBase64String(tokenData);
            }
        }
        
        // Regenerate session ID to prevent session fixation
        public void CreateSession(string username)
        {
            string sessionId = GenerateSessionToken();
            
            // Store in database with a new session ID
            string query = "INSERT INTO Sessions (Username, SessionId) VALUES (@username, @sessionId)";
            _dbService.ExecuteNonQuery(query, new { username, sessionId });
            
            Console.WriteLine($"Session created: {sessionId}");
        }
        
        // Secure password validation to prevent timing attacks
        public bool ValidatePassword(string inputPassword, string storedHash)
        {
            string inputHash = HashPassword(inputPassword);
            
            // Use constant time comparison
            return CryptographicOperations.FixedTimeEquals(Encoding.UTF8.GetBytes(inputHash), Encoding.UTF8.GetBytes(storedHash));
        }
    }
}
