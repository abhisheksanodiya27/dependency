using System;

namespace VulnerableApplication.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Username { get; set; }
        
        // Storing password in plain text field - CWE-256
        public string Password { get; set; }
        
        public string Email { get; set; }
        
        // Sensitive data in serializable object - CWE-499
        public string SocialSecurityNumber { get; set; }
        public string CreditCardNumber { get; set; }
        
        // Overly permissive access - CWE-732
        public void DisplaySensitiveInfo()
        {
            Console.WriteLine($"SSN: {SocialSecurityNumber}");
            Console.WriteLine($"Credit Card: {CreditCardNumber}");
        }
        
        // ToString exposes sensitive data - CWE-200
        public override string ToString()
        {
            // Exclude sensitive fields from ToString to prevent information exposure
return $"User: {Username}, Email: {Email}";
        }
    }
}