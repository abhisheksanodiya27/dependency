using System;
using VulnerableApplication.Controllers;
using VulnerableApplication.Services;

namespace VulnerableApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Vulnerable Application...");
            
            // Hard-coded credentials - CWE-798
            // Retrieve connection string securely from environment variables or configuration
string connectionString = Environment.GetEnvironmentVariable("DB_CONNECTION_STRING");
            
            DatabaseService dbService = new DatabaseService(connectionString);
            AuthenticationService authService = new AuthenticationService(dbService);
            UserController userController = new UserController(authService, dbService);
            
            // Simulate user login
            userController.Login("admin", adminPassword);
            
            // Simulate user registration
            userController.Register("newuser", "password123", "user@example.com");
            
            Console.WriteLine("Application running...");
            Console.ReadLine();
        }
    }
}