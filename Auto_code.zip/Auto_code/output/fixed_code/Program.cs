using System;
using VulnerableApplication.Controllers;
using VulnerableApplication.Services;
namespace VulnerableApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Starting Vulnerable Application...");
            
            // Retrieve credentials from a secure source
            string adminPassword = Environment.GetEnvironmentVariable("ADMIN_PASSWORD");
            string connectionString = Environment.GetEnvironmentVariable("DB_CONNECTION_STRING");
            
            if (string.IsNullOrEmpty(adminPassword) || string.IsNullOrEmpty(connectionString))
            {
                Console.WriteLine("Error: Missing environment variables for credentials.");
                return;
            }
            
            DatabaseService dbService = new DatabaseService(connectionString);
            AuthenticationService authService = new AuthenticationService(dbService);
            UserController userController = new UserController(authService, dbService);
            
            // Simulate user login
            userController.Login("admin", adminPassword);
            
            // Simulate user registration
            userController.Register("newuser", "password123", "user@example.com");
            
            Console.WriteLine("Application running...");
            Console.ReadLine();
        }
    }
}