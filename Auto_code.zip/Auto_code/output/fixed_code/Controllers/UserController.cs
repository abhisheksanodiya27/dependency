using System;
using VulnerableApplication.Services;
using VulnerableApplication.Models;

namespace VulnerableApplication.Controllers
{
    public class UserController
    {
        private AuthenticationService _authService;
        private DatabaseService _dbService;
        
        public UserController(AuthenticationService authService, DatabaseService dbService)
        {
            _authService = authService;
using System.Data.SqlClient;
            _dbService = dbService;
        }
        
        // SQL Injection vulnerability - CWE-89
        public void Login(string username, string password)
        {
            string query = "SELECT * FROM Users WHERE Username = '" + username + 
                          "' AND Password = '" + password + "'";
            
            var result = _dbService.ExecuteQuery(query);
            
            if (result != null)
            {
                // Logging sensitive data - CWE-532
                Console.WriteLine($"User logged in: {username} with password: {password}");
                _authService.CreateSession(username);
            }
        }
        
        // Weak password validation - CWE-521
        public void Register(string username, string password, string email)
        {
            if (password.Length < 6)
            {
                Console.WriteLine("Password too short");
                return;
            }
            
            // Uses weak encryption from CryptoHelper
            string hashedPassword = _authService.HashPassword(password);
            
            // SQL Injection - CWE-89
            string insertQuery = $"INSERT INTO Users (Username, Password, Email) VALUES ('{username}', '{hashedPassword}', '{email}')";
            _dbService.ExecuteNonQuery(insertQuery);
            
            Console.WriteLine($"User registered: {username}");
        }
        
        // Path Traversal vulnerability - CWE-22
        public string GetUserProfile(string userId)
        {
            string filePath = "/profiles/" + userId + ".txt";
            return System.IO.File.ReadAllText(filePath);
        }
        
        // CSRF vulnerability - missing token validation - CWE-352
        public void UpdateEmail(string username, string newEmail)
        {
            // Use parameterized queries to prevent SQL injection
string updateQuery = "UPDATE Users SET Email = @newEmail WHERE Username = @username";
SqlCommand cmd = new SqlCommand(updateQuery, conn);
cmd.Parameters.AddWithValue("@newEmail", newEmail);
cmd.Parameters.AddWithValue("@username", username);
            _dbService.ExecuteNonQuery(updateQuery);
        }
    }
}