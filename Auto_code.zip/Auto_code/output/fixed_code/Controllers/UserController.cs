using System;
using VulnerableApplication.Services;
using VulnerableApplication.Models;
using System;
using System.Text.RegularExpressions;
using VulnerableApplication.Services;
using VulnerableApplication.Models;

namespace VulnerableApplication.Controllers
{
    public class UserController
    {
        private AuthenticationService _authService;
        private DatabaseService _dbService;
        
        public UserController(AuthenticationService authService, DatabaseService dbService)
        {
            _authService = authService;
            _dbService = dbService;
        }
        
        // SQL Injection vulnerability - CWE-89
        public void Login(string username, string password)
        {
            string query = "SELECT * FROM Users WHERE Username = @username AND Password = @password";
            var parameters = new { username, password };
            var result = _dbService.ExecuteQuery(query, parameters);
            
            if (result != null)
            {
                // Logging sensitive data - CWE-532
                Console.WriteLine($"User logged in: {username}");
                _authService.CreateSession(username);
            }
        }
        
        // Weak password validation - CWE-521
        public void Register(string username, string password, string email)
        {
            if (!IsValidPassword(password))
            {
                Console.WriteLine("Password does not meet complexity requirements");
                return;
            }
            
            string hashedPassword = _authService.HashPassword(password);
            
            string insertQuery = "INSERT INTO Users (Username, Password, Email) VALUES (@username, @hashedPassword, @email)";
            var parameters = new { username, hashedPassword, email };
            _dbService.ExecuteNonQuery(insertQuery, parameters);
            
            Console.WriteLine($"User registered: {username}");
        }
        
        private bool IsValidPassword(string password)
        {
            // Password must be at least 8 characters long and contain at least one number and one special character
            return password.Length >= 8 &&
                   Regex.IsMatch(password, @"[0-9]") &&
                   Regex.IsMatch(password, @"[!@#$%^&*(),.?":{}|<>]");
        }
    }
}
