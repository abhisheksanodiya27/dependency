"""
Automated Vulnerability Fixer
Main application entry point
"""

import os
import csv
import json
from config import OPENAI_API_KEY, PROJECT_ROOT, CSV_PATH, OUTPUT_DIR
from utils.file_utils import read_file, write_file, generate_project_tree
from agents.dependency_checker import check_dependencies
from agents.root_cause_analyzer import analyze_root_cause
from agents.code_fixer import generate_fix
from agents.code_patcher import apply_patch, check_syntax_balance, format_code


def load_vulnerabilities(csv_path):
    """Load vulnerabilities from CSV file"""
    vulnerabilities = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            vulnerabilities.append(row)
    return vulnerabilities


def process_vulnerability(vuln, project_tree, project_root, output_dir, api_key, fixed_files_cache):
    """Process and fix a single vulnerability"""
    print(f"\n{'='*80}")
    print(f"Processing: {vuln['File_Name']} - Line {vuln['Line_Number']}")
    print(f"Vulnerability: {vuln['Vulnerability_Type']} ({vuln['CWE_ID']})")
    print(f"Severity: {vuln['Severity']} | CVSS: {vuln['CVSS_Score']}")
    print(f"{'='*80}\n")
    
    try:
        # Step 1: Read vulnerable file (use previously fixed version if exists)
        file_path = os.path.join(project_root, vuln['File_Path'])
        print(f"Step 1: Reading file: {file_path}")
        
        if not os.path.exists(file_path):
            print(f"ERROR: File not found")
            return {"status": "failed", "error": "File not found"}
        
        # Check if we've already fixed this file in a previous iteration
        if vuln['File_Path'] in fixed_files_cache:
            vulnerable_code = fixed_files_cache[vuln['File_Path']]
            print(f"✓ Using previously fixed version ({len(vulnerable_code)} chars)")
        else:
            vulnerable_code = read_file(file_path)
            print(f"✓ File loaded from disk ({len(vulnerable_code)} chars)")
        print()
        
        # Step 2: Check dependencies
        print("Step 2: Analyzing dependency requirements...")
        dep_result = check_dependencies(
            project_tree=project_tree,
            file_path=file_path,
            file_code=vulnerable_code,
            vulnerability=vuln,
            api_key=api_key
        )
        print(f"Requires dependencies: {dep_result['requires_dependencies']}\n")
        
        # Step 3: Load dependency files (use cache if available)
        dependency_files = {}
        if dep_result['requires_dependencies']:
            print("Step 3: Loading dependency files...")
            for dep in dep_result.get('required_files', []):
                dep_path = os.path.join(project_root, dep['file_path'])
                
                # Use cached version if available, otherwise read from disk
                if dep['file_path'] in fixed_files_cache:
                    dependency_files[dep['file_path']] = fixed_files_cache[dep['file_path']]
                    print(f"  ✓ {dep['file_path']} (cached)")
                elif os.path.exists(dep_path):
                    dependency_files[dep['file_path']] = read_file(dep_path)
                    print(f"  ✓ {dep['file_path']} (disk)")
            print()
        
        # Step 4: Analyze root cause
        print("Step 4: Analyzing root cause...")
        root_cause = analyze_root_cause(
            vulnerability=vuln,
            target_code=vulnerable_code,
            dependency_files=dependency_files,
            api_key=api_key
        )
        print(f"Root cause: {root_cause['root_cause_location']}")
        print(f"Files to fix: {len(root_cause.get('files_to_fix', []))}\n")
        
        if len(root_cause.get('files_to_fix', [])) > 1:
            print("Multi-file fix required:")
            for f in root_cause['files_to_fix']:
                print(f"  - {f['file_path']} ({f['fix_priority']})")
            print()
        
        # Step 5: Generate fixes for all affected files
        print("Step 5: Generating fixes...")
        all_fixes = []
        
        for file_info in root_cause.get('files_to_fix', [{'file_path': vuln['File_Path']}]):
            fix_file_path = os.path.join(project_root, file_info['file_path'])
            
            if not os.path.exists(fix_file_path):
                continue
            
            # Use cached version if available
            if file_info['file_path'] in fixed_files_cache:
                code_to_fix = fixed_files_cache[file_info['file_path']]
            else:
                code_to_fix = read_file(fix_file_path)
            
            fix_result = generate_fix(
                vulnerability=vuln,
                code=code_to_fix,
                dependency_files=dependency_files,
                file_path=fix_file_path,
                api_key=api_key,
                fix_context=file_info.get('reason', '')
            )
            
            all_fixes.append({
                'file_path': file_info['file_path'],
                'original_code': code_to_fix,
                'fix_result': fix_result
            })
            
            print(f"  ✓ {file_info['file_path']}: {len(fix_result['changes'])} changes")
        print()
        
        # Step 6: Apply patches
        print("Step 6: Applying patches...")
        fixed_files = []
        
        for fix in all_fixes:
            patched_code = apply_patch(
                original_code=fix['original_code'],
                changes=fix['fix_result']['changes']
            )
            
            # Validate bracket syntax
            syntax_check = check_syntax_balance(patched_code)
            if syntax_check['is_balanced']:
                print(f"  ✓ {fix['file_path']}: Brackets balanced")
            else:
                print(f"  ⚠ {fix['file_path']}: {len(syntax_check['errors'])} bracket errors")
                for error in syntax_check['errors'][:3]:
                    print(f"    - {error}")
            
            # Validate C# syntax
            from agents.code_patcher import validate_csharp_syntax
            csharp_check = validate_csharp_syntax(patched_code)
            if not csharp_check['is_valid']:
                print(f"  ⚠ {fix['file_path']}: {len(csharp_check['errors'])} syntax errors detected:")
                for error in csharp_check['errors'][:5]:
                    print(f"    - {error}")
                print(f"  WARNING: This file may not compile! Manual review required.")
            else:
                print(f"  ✓ {fix['file_path']}: Syntax validation passed")
            
            if csharp_check['warnings']:
                print(f"  ℹ {fix['file_path']}: {len(csharp_check['warnings'])} warnings")
            
            # Format code
            patched_code = format_code(patched_code)
            
            # Update cache with newly fixed version
            fixed_files_cache[fix['file_path']] = patched_code
            
            fixed_files.append({
                'file_path': fix['file_path'],
                'code': patched_code
            })
        print()
        
        # Step 7: Save fixed files
        print("Step 7: Saving fixed files...")
        saved_paths = []
        
        for fixed in fixed_files:
            output_path = os.path.join(output_dir, fixed['file_path'])
            write_file(output_path, fixed['code'])
            saved_paths.append(output_path)
            print(f"  ✓ {output_path}")
        print()
        
        return {
            "status": "success",
            "file": vuln['File_Name'],
            "vulnerability": vuln['Vulnerability_Type'],
            "files_fixed": len(saved_paths),
            "output_paths": saved_paths
        }
        
    except Exception as e:
        print(f"\nERROR: {str(e)}\n")
        return {
            "status": "failed",
            "file": vuln.get('File_Name', 'unknown'),
            "error": str(e)
        }


def generate_report(results, output_dir):
    """Generate final report"""
    report_path = os.path.join(output_dir, "fix_report.json")
    
    successful = [r for r in results if r['status'] == 'success']
    failed = [r for r in results if r['status'] == 'failed']
    
    report = {
        "total": len(results),
        "successful": len(successful),
        "failed": len(failed),
        "success_rate": f"{(len(successful)/len(results)*100):.1f}%" if results else "0%",
        "details": {
            "successful": successful,
            "failed": failed
        }
    }
    
    write_file(report_path, json.dumps(report, indent=2))
    return report


def main():
    """Main execution"""
    print("="*80)
    print("AUTOMATED VULNERABILITY FIXER")
    print("="*80)
    print(f"Project: {PROJECT_ROOT}")
    print(f"CSV: {CSV_PATH}")
    print(f"Output: {OUTPUT_DIR}")
    print("="*80)
    
    if OPENAI_API_KEY == "your-openai-api-key-here":
        print("\nERROR: Please set OPENAI_API_KEY in config.py")
        return
    
    # Load vulnerabilities
    print("\nLoading vulnerabilities...")
    vulnerabilities = load_vulnerabilities(CSV_PATH)
    print(f"Loaded {len(vulnerabilities)} vulnerabilities\n")
    
    # Generate project tree
    print("Generating project tree...")
    project_tree = generate_project_tree(PROJECT_ROOT)
    print("✓ Project tree generated\n")
    
    # Track fixed files to use cumulative fixes
    fixed_files_cache = {}
    
    # Process each vulnerability
    results = []
    for i, vuln in enumerate(vulnerabilities, 1):
        print(f"\n{'#'*80}")
        print(f"VULNERABILITY {i}/{len(vulnerabilities)}")
        print(f"{'#'*80}")
        
        result = process_vulnerability(
            vuln=vuln,
            project_tree=project_tree,
            project_root=PROJECT_ROOT,
            output_dir=OUTPUT_DIR,
            api_key=OPENAI_API_KEY,
            fixed_files_cache=fixed_files_cache
        )
        
        results.append(result)
    
    # Generate report
    print(f"\n{'='*80}")
    print("GENERATING REPORT")
    print(f"{'='*80}\n")
    
    report = generate_report(results, OUTPUT_DIR)
    
    print(f"{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    print(f"Total: {report['total']}")
    print(f"Successful: {report['successful']}")
    print(f"Failed: {report['failed']}")
    print(f"Success Rate: {report['success_rate']}")
    print(f"{'='*80}\n")


if __name__ == "__main__":
    main()