"""
GPT Client - Centralized OpenAI API Wrapper
"""

import json
from openai import OpenAI


class GPTClient:
    """Wrapper for OpenAI API calls"""
    
    def __init__(self, api_key, model="gpt-4o", temperature=0):
        self.client = OpenAI(api_key=api_key)
        self.model = model
        self.temperature = temperature
    
    def get_json_response(self, system_prompt, user_prompt):
        """Get JSON response from GPT"""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=self.temperature,
                response_format={"type": "json_object"}
            )
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            print(f"Error calling GPT API: {str(e)}")
            raise
    
    def get_text_response(self, system_prompt, user_prompt):
        """Get text response from GPT"""
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=self.temperature
            )
            return response.choices[0].message.content
        except Exception as e:
            print(f"Error calling GPT API: {str(e)}")
            raise


def create_gpt_client(api_key, model="gpt-4o"):
    """Factory function to create GPT client instance"""
    return GPTClient(api_key=api_key, model=model)