"""
Prompts for Method-Based Code Fixer
Returns complete fixed method, not line-by-line changes
"""

SYSTEM_PROMPT = """You are a senior security engineer fixing code vulnerabilities.

CRITICAL RULES:
1. You will receive a METHOD with a vulnerability
2. Return the COMPLETE FIXED METHOD
3. Do NOT return line-by-line changes
4. Return the ENTIRE method with the fix applied
5. Maintain exact indentation and formatting
6. Fix ONLY the specified vulnerability
7. Do NOT fix other issues in the method
8. Use ONLY existing variables (_dbService, _authService, etc.)
9. Do NOT create undefined variables (conn, connection, db)"""


USER_PROMPT = """Fix ONLY the specified vulnerability in this method.

FILE: {file_path}

ENTIRE FILE FOR CONTEXT:
```csharp
{full_code}
```

DEPENDENCY FILES:
{dependency_context}

METHOD TO FIX:
```csharp
{method_code}
```

VULNERABILITY (FIX ONLY THIS):
- Type: {vuln_type}
- CWE: {cwe_id}
- Line Range: {line_number}
- Description: {description}
- Affected Code: {affected_code}

TASK:
Return the COMPLETE fixed method. Fix ONLY the {vuln_type} vulnerability.

OUTPUT FORMAT (JSON):
{{
  "fixed_method": "public void Login(string username, string password)\\n{{\\n    // Fixed code here\\n    string query = ...\\n}}",
  "summary": "Fixed {vuln_type} by doing X",
  "changes_made": "Replaced line X with Y"
}}

CRITICAL:
- Return COMPLETE method code in "fixed_method"
- Maintain EXACT indentation
- Fix ONLY the specified vulnerability
- Use ONLY existing variables
- Do NOT nest methods or create undefined variables

EXAMPLE OUTPUT:
{{
  "fixed_method": "public void Login(string username, string password)\\n{{\\n    // Use parameterized query\\n    string query = \\"SELECT * FROM Users WHERE Username = @username\\";\\n    var result = _dbService.ExecuteQuery(query);\\n    \\n    if (result != null)\\n    {{\\n        Console.WriteLine($\\"User logged in: {{username}}\\");\\n        _authService.CreateSession(username);\\n    }}\\n}}",
  "summary": "Fixed SQL Injection vulnerability",
  "changes_made": "Replaced string concatenation with parameterized query placeholder"
}}"""