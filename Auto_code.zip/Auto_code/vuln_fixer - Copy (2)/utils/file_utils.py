"""
File Utilities - File operations and project tree generation
"""

import os


EXCLUDE_DIRS = {"venv", "__pycache__", ".git", "node_modules", "bin", "obj", ".vs", "packages"}


def read_file(file_path):
    """Read file content with encoding handling"""
    encodings = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
        except Exception as e:
            raise Exception(f"Error reading {file_path}: {str(e)}")
    
    raise Exception(f"Could not decode {file_path}")


def write_file(file_path, content):
    """Write content to file"""
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content)
    except Exception as e:
        raise Exception(f"Error writing {file_path}: {str(e)}")


def generate_project_tree(root_path, max_depth=5, level=0, prefix=""):
    """Generate directory tree structure"""
    if level > max_depth or not os.path.exists(root_path):
        return ""
    
    tree = ""
    
    try:
        items = sorted(os.listdir(root_path))
    except PermissionError:
        return f"{prefix}[Permission Denied]\n"
    
    items = [item for item in items if item not in EXCLUDE_DIRS]
    
    for i, item in enumerate(items):
        path = os.path.join(root_path, item)
        is_last = i == len(items) - 1
        connector = "└── " if is_last else "├── "
        extension = "    " if is_last else "│   "
        
        tree += f"{prefix}{connector}{item}\n"
        
        if os.path.isdir(path):
            tree += generate_project_tree(path, max_depth, level + 1, prefix + extension)
    
    return tree


def list_files_by_extension(root_path, extensions):
    """List all files with given extensions"""
    files = []
    for root, dirs, filenames in os.walk(root_path):
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]
        for filename in filenames:
            if any(filename.endswith(ext) for ext in extensions):
                files.append(os.path.join(root, filename))
    return files