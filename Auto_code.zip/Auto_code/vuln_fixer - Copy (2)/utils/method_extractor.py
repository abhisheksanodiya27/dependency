"""
Method Extractor - Find and extract methods from code
"""

import re


def parse_line_range(line_number_str):
    """
    Parse line number string into start and end
    
    Supports formats: "21", "21-22", "21:36", "41-44"
    
    Returns: (start_line, end_line)
    """
    line_str = str(line_number_str).strip()
    
    # Check for range formats
    if '-' in line_str:
        parts = line_str.split('-')
        return int(parts[0]), int(parts[1])
    elif ':' in line_str:
        parts = line_str.split(':')
        return int(parts[0]), int(parts[1])
    else:
        # Single line
        line = int(line_str)
        return line, line


def find_method_containing_lines(code, start_line, end_line):
    """
    Find the method that contains the given line range
    
    Args:
        code: Source code string
        start_line: Start line number (1-indexed)
        end_line: End line number (1-indexed)
        
    Returns:
        Dict with method info or None
    """
    lines = code.split('\n')
    
    # Search backwards from start_line to find method signature
    method_start = None
    method_name = None
    
    for i in range(start_line - 1, -1, -1):
        line = lines[i].strip()
        
        # Look for method signature - broader pattern
        # Matches: public/private/static void/string/etc MethodName(
        if ('(' in line and ')' in line and 
            any(keyword in line for keyword in ['public', 'private', 'protected', 'internal', 'static']) and
            not line.strip().startswith('//')):
            
            method_start = i
            
            # Extract method name - get word before (
            before_paren = line.split('(')[0]
            words = before_paren.split()
            if words:
                method_name = words[-1]  # Last word before (
            
            break
    
    if method_start is None:
        print(f"    Could not find method signature before line {start_line}")
        return None
    
    # Find method end by counting braces
    method_end = find_method_end(lines, method_start)
    
    if method_end is None:
        print(f"    Could not find method end after line {method_start + 1}")
        return None
    
    # Extract method code
    method_code = '\n'.join(lines[method_start:method_end + 1])
    
    return {
        'name': method_name,
        'start_line': method_start + 1,  # Convert to 1-indexed
        'end_line': method_end + 1,
        'code': method_code,
        'indent_level': len(lines[method_start]) - len(lines[method_start].lstrip())
    }


def find_method_end(lines, start_index):
    """
    Find the closing brace of a method
    
    Args:
        lines: List of code lines
        start_index: Index where method starts (0-indexed)
        
    Returns:
        Index of method closing brace or None
    """
    brace_count = 0
    found_opening = False
    
    for i in range(start_index, len(lines)):
        line = lines[i]
        
        # Count braces
        for char in line:
            if char == '{':
                brace_count += 1
                found_opening = True
            elif char == '}':
                brace_count -= 1
                
                # If we're back to 0, we found the method end
                if found_opening and brace_count == 0:
                    return i
    
    return None


def replace_method_in_code(code, old_method_code, new_method_code, indent_level=0):
    """
    Replace old method with new method in code, preserving indentation
    
    Args:
        code: Original source code
        old_method_code: Old method to replace
        new_method_code: New method code
        indent_level: Indentation level of the method
        
    Returns:
        Updated code string
    """
    # Apply indentation to new method if it doesn't have it
    if indent_level > 0:
        indent = ' ' * indent_level
        new_lines = []
        for line in new_method_code.split('\n'):
            if line.strip():  # Non-empty line
                # Check if line already has indentation
                if not line.startswith(' '):
                    new_lines.append(indent + line)
                else:
                    new_lines.append(line)
            else:
                new_lines.append(line)
        new_method_code = '\n'.join(new_lines)
    
    # Try simple replacement
    if old_method_code in code:
        return code.replace(old_method_code, new_method_code)
    
    # Try with normalized whitespace
    print("    Warning: Exact match failed, trying normalized replacement")
    return code


def normalize_whitespace(text):
    """Normalize whitespace for comparison"""
    return ' '.join(text.split())