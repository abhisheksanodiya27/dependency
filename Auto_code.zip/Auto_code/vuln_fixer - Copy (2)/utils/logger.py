"""
Logger Utility
Simple colored logging for console output
"""

import datetime
import os


# ANSI color codes
class Colors:
    RESET = '\033[0m'
    RED = '\033[91m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    BLUE = '\033[94m'
    MAGENTA = '\033[95m'
    CYAN = '\033[96m'
    WHITE = '\033[97m'
    BOLD = '\033[1m'


LOG_FILE = "logs/execution.log"


def setup_logging():
    """Setup logging directory"""
    os.makedirs("logs", exist_ok=True)


def get_timestamp():
    """Get formatted timestamp"""
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log_to_file(message, level="INFO"):
    """Write log to file"""
    try:
        setup_logging()
        with open(LOG_FILE, 'a', encoding='utf-8') as f:
            f.write(f"[{get_timestamp()}] [{level}] {message}\n")
    except:
        pass


def log_info(message):
    """Log info message in blue"""
    timestamp = get_timestamp()
    formatted = f"{Colors.BLUE}[INFO]{Colors.RESET} [{timestamp}] {message}"
    print(formatted)
    log_to_file(message, "INFO")


def log_success(message):
    """Log success message in green"""
    timestamp = get_timestamp()
    formatted = f"{Colors.GREEN}[SUCCESS]{Colors.RESET} [{timestamp}] {message}"
    print(formatted)
    log_to_file(message, "SUCCESS")


def log_warning(message):
    """Log warning message in yellow"""
    timestamp = get_timestamp()
    formatted = f"{Colors.YELLOW}[WARNING]{Colors.RESET} [{timestamp}] {message}"
    print(formatted)
    log_to_file(message, "WARNING")


def log_error(message):
    """Log error message in red"""
    timestamp = get_timestamp()
    formatted = f"{Colors.RED}[ERROR]{Colors.RESET} [{timestamp}] {message}"
    print(formatted)
    log_to_file(message, "ERROR")


def log_debug(message):
    """Log debug message in cyan"""
    timestamp = get_timestamp()
    formatted = f"{Colors.CYAN}[DEBUG]{Colors.RESET} [{timestamp}] {message}"
    print(formatted)
    log_to_file(message, "DEBUG")


def log_header(message):
    """Log header message in bold"""
    formatted = f"{Colors.BOLD}{Colors.MAGENTA}{message}{Colors.RESET}"
    print(formatted)
    log_to_file(message, "HEADER")


def log_separator():
    """Print a separator line"""
    print("=" * 80)


def clear_log_file():
    """Clear the log file"""
    try:
        setup_logging()
        with open(LOG_FILE, 'w', encoding='utf-8') as f:
            f.write(f"Log started at {get_timestamp()}\n")
            f.write("=" * 80 + "\n")
    except:
        pass