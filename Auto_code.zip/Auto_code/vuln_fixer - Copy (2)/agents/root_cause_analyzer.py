"""
Root Cause Analyzer Agent
Determines if vulnerability originates in a dependency file
"""

from core.gpt_client import create_gpt_client
from prompts.root_cause_prompts import SYSTEM_PROMPT, USER_PROMPT


def analyze_root_cause(vulnerability, target_code, dependency_files, api_key):
    """
    Analyze where the vulnerability originates
    
    Args:
        vulnerability: Vulnerability dict from CSV
        target_code: Code of target file
        dependency_files: Dict of {file_path: code}
        api_key: OpenAI API key
        
    Returns:
        Dict with root cause analysis
    """
    gpt = create_gpt_client(api_key)
    
    # Build dependency context
    dependency_context = ""
    if dependency_files:
        dependency_context = "\n\n".join([
            f"--- {path} ---\n{code}" 
            for path, code in dependency_files.items()
        ])
    
    user_prompt = USER_PROMPT.format(
        file_path=vulnerability['File_Path'],
        line_number=vulnerability['Line_Number'],
        function_name=vulnerability['Function_Name'],
        vuln_type=vulnerability['Vulnerability_Type'],
        cwe_id=vulnerability['CWE_ID'],
        description=vulnerability['Vulnerability_Description'],
        affected_code=vulnerability['Affected_Code'],
        dependency_chain=vulnerability['Dependency_Chain'],
        target_code=target_code,
        dependency_context=dependency_context if dependency_context else "None"
    )
    
    try:
        result = gpt.get_json_response(SYSTEM_PROMPT, user_prompt)
        return result
    except Exception as e:
        print(f"Error analyzing root cause: {str(e)}")
        return {
            "root_cause_location": "target_file",
            "files_to_fix": [{"file_path": vulnerability['File_Path'], "fix_priority": "primary"}],
            "reasoning": f"Error: {str(e)}"
        }