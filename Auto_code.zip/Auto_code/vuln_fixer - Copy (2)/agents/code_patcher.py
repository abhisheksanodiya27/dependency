"""
Code Patcher Agent
Applies code changes with dynamic indentation preservation
"""

from math import gcd
from functools import reduce


def get_indentation(line):
    """Extract indentation from line"""
    return line[:len(line) - len(line.lstrip())]


def detect_indentation_style(lines):
    """Detect indentation style (spaces or tabs)"""
    space_counts = {}
    
    for line in lines:
        if not line.strip():
            continue
        indent = get_indentation(line)
        if '\t' in indent:
            return ('\t', 1)
        if indent:
            space_counts[len(indent)] = space_counts.get(len(indent), 0) + 1
    
    if space_counts:
        indent_size = reduce(gcd, space_counts.keys())
        return (' ', indent_size if indent_size > 0 else 4)
    
    return (' ', 4)


def apply_dynamic_indentation(code, base_indent):
    """
    Apply base indentation to all lines of code
    Simple and safe - just adds the same indent to every line
    
    Args:
        code: Code string (new_code from LLM)
        base_indent: Base indentation to apply (from original line)
        
    Returns:
        Indented code string
    """
    if not code:
        return ""
    
    lines = code.split('\n')
    result = []
    
    for line in lines:
        if not line.strip():
            # Empty line - keep empty
            result.append("")
        else:
            # Apply base indent to every non-empty line
            result.append(base_indent + line.strip())
    
    return '\n'.join(result)




def apply_replace(lines, line_num, old_code, new_code):
    """Replace code at specified line - SIMPLE AND SAFE"""
    if line_num < 1 or line_num > len(lines):
        print(f"Warning: Line {line_num} out of range")
        return lines
    
    idx = line_num - 1
    old_code_stripped = old_code.strip()
    
    # Search for the line (check nearby lines)
    search_range = 3
    start = max(0, idx - search_range)
    end = min(len(lines), idx + search_range + 1)
    
    for i in range(start, end):
        line_stripped = lines[i].strip()
        
        # Check if this line matches
        if old_code_stripped == line_stripped or old_code_stripped in line_stripped:
            # Get the indentation from this line
            base_indent = get_indentation(lines[i])
            
            # Apply indentation to new code
            new_code_indented = apply_dynamic_indentation(new_code, base_indent)
            
            # Replace THIS line only
            lines[i] = new_code_indented
            return lines
    
    # Not found - insert at specified line
    print(f"Warning: Could not find old_code at line {line_num}, inserting new code")
    base_indent = get_indentation(lines[idx]) if idx < len(lines) else ""
    lines[idx] = apply_dynamic_indentation(new_code, base_indent)
    
    return lines


def apply_add(lines, line_num, new_code):
    """Add code at specified line"""
    if line_num < 1:
        line_num = 1
    if line_num > len(lines):
        line_num = len(lines)
    
    idx = line_num - 1
    base_indent = get_indentation(lines[idx - 1]) if idx > 0 else ""
    
    new_lines = apply_dynamic_indentation(new_code, base_indent).split('\n')
    
    for i, new_line in enumerate(reversed(new_lines)):
        lines.insert(idx, new_line)
    
    return lines


def apply_delete(lines, line_num, old_code):
    """Delete code at specified line"""
    if line_num < 1 or line_num > len(lines):
        print(f"Warning: Line {line_num} out of range")
        return lines
    
    idx = line_num - 1
    
    if old_code.strip() in lines[idx]:
        lines.pop(idx)
        return lines
    
    search_range = 3
    start = max(0, idx - search_range)
    end = min(len(lines), idx + search_range + 1)
    
    for i in range(start, end):
        if old_code.strip() in lines[i]:
            lines.pop(i)
            return lines
    
    print(f"Warning: Could not find code to delete at line {line_num}")
    return lines


def apply_patch(original_code, changes):
    """
    Apply code changes to original code
    
    Args:
        original_code: Original code string
        changes: List of change dicts
        
    Returns:
        Patched code string
    """
    lines = original_code.split('\n')
    sorted_changes = sorted(changes, key=lambda x: x.get('line_number', 0), reverse=True)
    
    for change in sorted_changes:
        change_type = change.get('change_type', 'replace')
        line_num = change.get('line_number', 0)
        old_code = change.get('old_code', '')
        new_code = change.get('new_code', '')
        
        if change_type == 'replace':
            lines = apply_replace(lines, line_num, old_code, new_code)
        elif change_type == 'add':
            lines = apply_add(lines, line_num, new_code)
        elif change_type == 'delete':
            lines = apply_delete(lines, line_num, old_code)
    
    return '\n'.join(lines)


def validate_csharp_syntax(code):
    """
    Basic validation for C# syntax errors
    
    Returns:
        Dict with validation results
    """
    errors = []
    warnings = []
    lines = code.split('\n')
    
    # Check for undefined variables that are commonly introduced
    undefined_vars = ['conn', 'connection', 'db']
    for i, line in enumerate(lines, 1):
        for var in undefined_vars:
            # Check if variable is used but not declared
            if f' {var}' in line or f'({var}' in line or f', {var}' in line:
                # Check if it's being declared on this line
                if not ('var ' in line or 'SqlConnection ' in line or 'new ' in line):
                    # Check if it was declared earlier
                    found_declaration = False
                    for prev_line in lines[:i-1]:
                        if f' {var} =' in prev_line or f' {var};' in prev_line:
                            found_declaration = True
                            break
                    
                    if not found_declaration:
                        errors.append(f"Line {i}: Undefined variable '{var}' may be used")
    
    # Check for nested method definitions (method inside method)
    method_stack = []
    brace_count = 0
    in_method = False
    
    for i, line in enumerate(lines, 1):
        stripped = line.strip()
        
        # Detect method definition
        if ('public ' in stripped or 'private ' in stripped or 'protected ' in stripped) and '(' in stripped and ')' in stripped and not ';' in stripped:
            if in_method and brace_count > 0:
                errors.append(f"Line {i}: Method appears to be nested inside another method")
            method_stack.append(i)
            in_method = True
        
        # Count braces
        brace_count += stripped.count('{')
        brace_count -= stripped.count('}')
        
        if brace_count == 0:
            in_method = False
    
    # Check for duplicate code (same line appears multiple times consecutively)
    for i in range(len(lines) - 1):
        if lines[i].strip() and lines[i] == lines[i+1]:
            warnings.append(f"Line {i+1}: Duplicate line detected")
    
    return {
        "is_valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings
    }


def check_syntax_balance(code):
    """Check if brackets are balanced"""
    brackets = {'(': ')', '{': '}', '[': ']'}
    stack = []
    errors = []
    
    for i, char in enumerate(code):
        if char in brackets.keys():
            stack.append((char, i))
        elif char in brackets.values():
            if stack and brackets[stack[-1][0]] == char:
                stack.pop()
            else:
                errors.append(f"Unmatched '{char}' at position {i}")
    
    for char, pos in stack:
        errors.append(f"Unclosed '{char}' at position {pos}")
    
    return {
        "is_balanced": len(errors) == 0,
        "errors": errors
    }


def format_code(code):
    """Format code by removing excessive blank lines"""
    lines = code.split('\n')
    result = []
    blank_count = 0
    
    for line in lines:
        if not line.strip():
            blank_count += 1
            if blank_count <= 2:
                result.append(line)
        else:
            blank_count = 0
            result.append(line)
    
    return '\n'.join(result)