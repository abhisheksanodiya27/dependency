"""
Method-Based Code Fixer
Returns complete fixed method instead of line-by-line changes
"""

from core.gpt_client import create_gpt_client
from prompts.code_fixer_prompts import SYSTEM_PROMPT, USER_PROMPT
from utils.method_extractor import parse_line_range, find_method_containing_lines


def generate_method_fix(vulnerability, full_code, dependency_files, file_path, api_key):
    """
    Generate fix by returning complete fixed method
    
    Args:
        vulnerability: Vulnerability dict from CSV
        full_code: Complete file code
        dependency_files: Dict of {file_path: code} for context
        file_path: Path to file being fixed
        api_key: OpenAI API key
        
    Returns:
        Dict with method_info and fixed_method
    """
    gpt = create_gpt_client(api_key)
    
    # Parse line number range
    start_line, end_line = parse_line_range(vulnerability['Line_Number'])
    
    # Find method containing these lines
    method_info = find_method_containing_lines(full_code, start_line, end_line)
    
    if not method_info:
        print(f"  ⚠ Could not find method containing lines {start_line}-{end_line}")
        return {
            'method_info': None,
            'fixed_method': None,
            'error': 'Method not found'
        }
    
    print(f"  → Found method: {method_info['name']} (lines {method_info['start_line']}-{method_info['end_line']})")
    
    # Build dependency context
    dependency_context = ""
    if dependency_files:
        dependency_context = "\n\n".join([
            f"--- {path} ---\n{code}" 
            for path, code in dependency_files.items()
        ])
    else:
        dependency_context = "None"
    
    # Build prompt
    user_prompt = USER_PROMPT.format(
        file_path=file_path,
        full_code=full_code,
        dependency_context=dependency_context,
        method_code=method_info['code'],
        vuln_type=vulnerability['Vulnerability_Type'],
        cwe_id=vulnerability['CWE_ID'],
        line_number=vulnerability['Line_Number'],
        description=vulnerability['Vulnerability_Description'],
        affected_code=vulnerability['Affected_Code']
    )
    
    try:
        result = gpt.get_json_response(SYSTEM_PROMPT, user_prompt)
        
        return {
            'method_info': method_info,
            'fixed_method': result.get('fixed_method', ''),
            'summary': result.get('summary', ''),
            'changes_made': result.get('changes_made', '')
        }
        
    except Exception as e:
        print(f"  ✗ Error generating fix: {str(e)}")
        return {
            'method_info': method_info,
            'fixed_method': None,
            'error': str(e)
        }