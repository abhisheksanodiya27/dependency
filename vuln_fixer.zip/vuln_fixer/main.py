"""
Automated Vulnerability Fixer - FILE-BASED
Fix all vulnerabilities in a file at once
"""

import os
import csv
import json
from config import OPENAI_API_KEY, PROJECT_ROOT, CSV_PATH, OUTPUT_DIR
from utils.file_utils import read_file, write_file, generate_project_tree
from agents.dependency_checker import check_dependencies
from agents.file_fixer import fix_entire_file
from utils.file_grouper import group_vulnerabilities_by_file


def load_vulnerabilities(csv_path):
    """Load vulnerabilities from CSV file"""
    vulnerabilities = []
    with open(csv_path, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            vulnerabilities.append(row)
    return vulnerabilities


def process_file(file_group, project_tree, project_root, output_dir, api_key):
    """Process and fix ALL vulnerabilities in a file at once"""
    try:
        print(f"Step 1: Reading file: {file_group['file_path']}")
        
        file_path = os.path.join(project_root, file_group['file_path'])
        
        if not os.path.exists(file_path):
            print(f"ERROR: File not found\n")
            return {"status": "failed", "error": "File not found"}
        
        file_code = read_file(file_path)
        print(f"✓ Read file ({len(file_code)} characters)\n")
        
        # Step 2: Check dependencies
        print("Step 2: Analyzing dependencies...")
        first_vuln = file_group['vulnerabilities'][0]
        
        dep_result = check_dependencies(
            project_tree=project_tree,
            file_path=file_path,
            file_code=file_code,
            vulnerability=first_vuln,
            api_key=api_key
        )
        print(f"Requires dependencies: {dep_result['requires_dependencies']}\n")
        
        # Step 3: Load dependencies
        dependency_files = {}
        if dep_result['requires_dependencies']:
            print("Step 3: Loading dependencies...")
            for dep in dep_result.get('required_files', []):
                dep_path = os.path.join(project_root, dep['file_path'])
                if os.path.exists(dep_path):
                    dependency_files[dep['file_path']] = read_file(dep_path)
                    print(f"  ✓ {dep['file_path']}")
            print()
        
        # Step 4: Fix entire file
        print(f"Step 4: Fixing ALL {file_group['count']} vulnerabilities in file...")
        
        fix_result = fix_entire_file(
            file_path=file_group['file_path'],
            file_code=file_code,
            vulnerabilities=file_group['vulnerabilities'],
            dependency_files=dependency_files,
            api_key=api_key
        )
        
        if not fix_result.get('fixed_file'):
            print(f"✗ Failed: {fix_result.get('error', 'Unknown error')}\n")
            return {
                "status": "failed",
                "file": file_group['file_path'],
                "error": fix_result.get('error', 'Unknown')
            }
        
        print(f"✓ Generated fixed file\n")
        
        # Step 5: Save fixed file
        print("Step 5: Saving fixed file...")
        output_path = os.path.join(output_dir, file_group['file_path'])
        write_file(output_path, fix_result['fixed_file'])
        print(f"✓ Saved: {output_path}\n")
        
        return {
            "status": "success",
            "file": file_group['file_path'],
            "vulnerabilities_fixed": file_group['count'],
            "output_path": output_path
        }
        
    except Exception as e:
        print(f"\nERROR: {str(e)}\n")
        return {
            "status": "failed",
            "file": file_group.get('file_path', 'unknown'),
            "error": str(e)
        }


def generate_report(results, output_dir):
    """Generate final report"""
    report_path = os.path.join(output_dir, "fix_report.json")
    
    successful = [r for r in results if r['status'] == 'success']
    failed = [r for r in results if r['status'] == 'failed']
    
    total_vulns_fixed = sum(r.get('vulnerabilities_fixed', 0) for r in successful)
    
    report = {
        "files_processed": len(results),
        "successful": len(successful),
        "failed": len(failed),
        "total_vulnerabilities_fixed": total_vulns_fixed,
        "success_rate": f"{(len(successful)/len(results)*100):.1f}%" if results else "0%",
        "details": {
            "successful": successful,
            "failed": failed
        }
    }
    
    write_file(report_path, json.dumps(report, indent=2))
    return report


def main():
    """Main execution - FILE-BASED FIXING"""
    print("="*80)
    print("AUTOMATED VULNERABILITY FIXER - FILE-BASED")
    print("="*80)
    print(f"Project: {PROJECT_ROOT}")
    print(f"CSV: {CSV_PATH}")
    print(f"Output: {OUTPUT_DIR}")
    print("="*80)
    
    if OPENAI_API_KEY == "your-openai-api-key-here":
        print("\nERROR: Please set OPENAI_API_KEY in config.py")
        return
    
    # Load vulnerabilities
    print("\nLoading vulnerabilities...")
    vulnerabilities = load_vulnerabilities(CSV_PATH)
    print(f"Loaded {len(vulnerabilities)} vulnerabilities\n")
    
    # Generate project tree
    print("Generating project tree...")
    project_tree = generate_project_tree(PROJECT_ROOT)
    print("✓ Project tree generated\n")
    
    # Group vulnerabilities by FILE
    print("Grouping vulnerabilities by file...")
    file_groups = group_vulnerabilities_by_file(vulnerabilities)
    
    print(f"✓ Grouped into {len(file_groups)} files")
    print(f"✓ Will fix ALL vulnerabilities in each file at once\n")
    
    # Process each file
    results = []
    for i, file_group in enumerate(file_groups, 1):
        print(f"\n{'#'*80}")
        print(f"FILE {i}/{len(file_groups)}")
        print(f"{'#'*80}")
        print(f"File: {file_group['file_path']}")
        print(f"Total Vulnerabilities: {file_group['count']}")
        
        for vuln in file_group['vulnerabilities']:
            print(f"  - Line {vuln['Line_Number']}: {vuln['Vulnerability_Type']}")
        print()
        
        result = process_file(
            file_group=file_group,
            project_tree=project_tree,
            project_root=PROJECT_ROOT,
            output_dir=OUTPUT_DIR,
            api_key=OPENAI_API_KEY
        )
        
        results.append(result)
    
    # Generate report
    print(f"\n{'='*80}")
    print("GENERATING REPORT")
    print(f"{'='*80}\n")
    
    report = generate_report(results, OUTPUT_DIR)
    
    print(f"{'='*80}")
    print("SUMMARY")
    print(f"{'='*80}")
    print(f"Files Processed: {report['files_processed']}")
    print(f"Successful: {report['successful']}")
    print(f"Failed: {report['failed']}")
    print(f"Total Vulnerabilities Fixed: {report['total_vulnerabilities_fixed']}")
    print(f"Success Rate: {report['success_rate']}")
    print(f"{'='*80}\n")


if __name__ == "__main__":
    main()