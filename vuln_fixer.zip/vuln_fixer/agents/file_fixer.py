"""
File-Based Fixer - Fix entire file at once
"""

from core.gpt_client import create_gpt_client
from prompts.file_fixer_prompts import SYSTEM_PROMPT, USER_PROMPT
import re


def clean_file_output(code):
    """
    Clean LLM output - remove markdown, ensure proper structure
    """
    # Remove markdown code fences
    code = re.sub(r'^```[a-z]*\n', '', code, flags=re.MULTILINE)
    code = re.sub(r'\n```$', '', code, flags=re.MULTILINE)
    code = code.replace('```csharp', '')
    code = code.replace('```', '')
    
    # Remove duplicate using statements
    lines = code.split('\n')
    seen_usings = set()
    clean_lines = []
    
    in_using_section = True
    for line in lines:
        stripped = line.strip()
        
        # Handle using statements
        if stripped.startswith('using '):
            if in_using_section:
                if stripped not in seen_usings:
                    seen_usings.add(stripped)
                    clean_lines.append(line)
            else:
                # using statement after code started - skip duplicate
                if stripped not in seen_usings:
                    pass  # Skip late using statements
        else:
            if stripped and not stripped.startswith('//'):
                in_using_section = False
            clean_lines.append(line)
    
    return '\n'.join(clean_lines)


def fix_entire_file(file_path, file_code, vulnerabilities, dependency_files, api_key):
    """
    Fix ALL vulnerabilities in a file at once
    
    Args:
        file_path: Path to file
        file_code: Complete file code
        vulnerabilities: List of ALL vulnerabilities in this file
        dependency_files: Dict of dependency files
        api_key: OpenAI API key
        
    Returns:
        Dict with fix result
    """
    gpt = create_gpt_client(api_key)
    
    print(f"  → File: {file_path}")
    print(f"  → Fixing {len(vulnerabilities)} vulnerabilities")
    
    # Build dependency context
    dependency_context = ""
    if dependency_files:
        dependency_context = "\n\n".join([
            f"--- {path} ---\n{code}" 
            for path, code in dependency_files.items()
        ])
    else:
        dependency_context = "None"
    
    # Format vulnerabilities list
    vuln_list = []
    for i, vuln in enumerate(vulnerabilities, 1):
        vuln_list.append(
            f"{i}. {vuln['Vulnerability_Type']} (CWE-{vuln['CWE_ID']}) at line {vuln['Line_Number']}\n"
            f"   Description: {vuln['Vulnerability_Description']}\n"
            f"   Affected Code: {vuln['Affected_Code']}"
        )
    vulnerabilities_text = '\n\n'.join(vuln_list)
    
    # Create prompt
    user_prompt = USER_PROMPT.format(
        file_code=file_code,
        dependency_context=dependency_context,
        vulnerabilities_list=vulnerabilities_text,
        vuln_count=len(vulnerabilities)
    )
    
    try:
        result = gpt.get_json_response(SYSTEM_PROMPT, user_prompt)
        
        # Get fixed file and clean it
        fixed_file = result.get('fixed_file', '')
        fixed_file = clean_file_output(fixed_file)
        
        return {
            'fixed_file': fixed_file,
            'summary': result.get('summary', f"Fixed {len(vulnerabilities)} vulnerabilities"),
            'vulnerabilities_fixed': len(vulnerabilities)
        }
        
    except Exception as e:
        print(f"  ✗ Error: {str(e)}")
        return {
            'fixed_file': None,
            'error': str(e)
        }