"""
File Grouper - Group vulnerabilities by file
"""


def group_vulnerabilities_by_file(vulnerabilities):
    """
    Group vulnerabilities by file path
    
    Args:
        vulnerabilities: List of vulnerability dicts from CSV
        
    Returns:
        List of file groups with all their vulnerabilities
    """
    # Group by file path
    file_groups = {}
    
    for vuln in vulnerabilities:
        file_path = vuln['File_Path']
        
        if file_path not in file_groups:
            file_groups[file_path] = []
        
        file_groups[file_path].append(vuln)
    
    # Convert to list
    grouped = []
    for file_path, vulns in file_groups.items():
        grouped.append({
            'file_path': file_path,
            'vulnerabilities': vulns,
            'count': len(vulns)
        })
    
    return grouped