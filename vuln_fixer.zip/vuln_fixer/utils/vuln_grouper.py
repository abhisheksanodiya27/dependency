"""
Vulnerability Grouper - Group vulnerabilities by file and function
"""

from utils.method_extractor import parse_line_range, find_method_containing_lines


def group_vulnerabilities_by_function(vulnerabilities, project_root, file_cache):
    """
    Group vulnerabilities that are in the same function
    
    Args:
        vulnerabilities: List of vulnerability dicts from CSV
        project_root: Project root path
        file_cache: Dict to cache file contents
        
    Returns:
        List of grouped vulnerabilities
    """
    import os
    from utils.file_utils import read_file
    
    # Step 1: Extract function info for each vulnerability
    vuln_with_methods = []
    
    for vuln in vulnerabilities:
        file_path = os.path.join(project_root, vuln['File_Path'])
        
        # Get file content (use cache)
        if vuln['File_Path'] not in file_cache:
            if os.path.exists(file_path):
                file_cache[vuln['File_Path']] = read_file(file_path)
            else:
                continue
        
        code = file_cache[vuln['File_Path']]
        
        # Find method containing this vulnerability
        start_line, end_line = parse_line_range(vuln['Line_Number'])
        method_info = find_method_containing_lines(code, start_line, end_line)
        
        if method_info:
            vuln_with_methods.append({
                'vulnerability': vuln,
                'method_key': f"{vuln['File_Path']}::{method_info['name']}",
                'method_signature': extract_method_signature(method_info['code'])
            })
    
    # Step 2: Group by method_key
    groups = {}
    for item in vuln_with_methods:
        key = item['method_key']
        if key not in groups:
            groups[key] = {
                'vulns': [],
                'signature': item.get('method_signature')
            }
        groups[key]['vulns'].append(item['vulnerability'])
    
    # Step 3: Convert to list of groups
    grouped = []
    for method_key, data in groups.items():
        file_path = method_key.split('::')[0]
        method_name = method_key.split('::')[1]
        
        grouped.append({
            'file_path': file_path,
            'method_name': method_name,
            'method_signature': data['signature'],
            'vulnerabilities': data['vulns'],
            'count': len(data['vulns'])
        })
    
    return grouped


def extract_method_signature(method_code):
    """Extract method signature from method code"""
    if not method_code:
        return None
    lines = method_code.strip().split('\n')
    for line in lines:
        stripped = line.strip()
        if ('(' in stripped and ')' in stripped and 
            any(kw in stripped for kw in ['public', 'private', 'protected', 'static'])):
            # Found signature line - return normalized version
            return ' '.join(stripped.split())
    return None


def format_multiple_vulnerabilities(vulnerabilities):
    """Format multiple vulnerabilities for prompt"""
    result = []
    for i, vuln in enumerate(vulnerabilities, 1):
        result.append(f"{i}. {vuln['Vulnerability_Type']} (CWE-{vuln['CWE_ID']}) at line {vuln['Line_Number']}")
        result.append(f"   Description: {vuln['Vulnerability_Description']}")
        result.append(f"   Affected: {vuln['Affected_Code']}")
    return '\n'.join(result)



"""
File Grouper - Group vulnerabilities by file
"""


def group_vulnerabilities_by_file(vulnerabilities):
    """
    Group vulnerabilities by file path
    
    Args:
        vulnerabilities: List of vulnerability dicts from CSV
        
    Returns:
        List of file groups with all their vulnerabilities
    """
    # Group by file path
    file_groups = {}
    
    for vuln in vulnerabilities:
        file_path = vuln['File_Path']
        
        if file_path not in file_groups:
            file_groups[file_path] = []
        
        file_groups[file_path].append(vuln)
    
    # Convert to list
    grouped = []
    for file_path, vulns in file_groups.items():
        grouped.append({
            'file_path': file_path,
            'vulnerabilities': vulns,
            'count': len(vulns)
        })
    
    return grouped