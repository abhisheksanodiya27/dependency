"""
Prompts for File-Based Fixer - Fix entire file at once
"""

SYSTEM_PROMPT = """You are a senior security engineer.

CRITICAL OUTPUT RULES:
1. Return the COMPLETE fixed file
2. Fix ALL vulnerabilities listed
3. Maintain exact file structure (using statements, namespace, class)
4. Use ONLY existing variables (_dbService, _authService)
5. NEVER create: SqlConnection, SqlCommand, conn, connection
6. NO markdown formatting (no ```csharp, no backticks)
7. Return valid, compilable C# code"""


USER_PROMPT = """Fix ALL vulnerabilities in this file.

ENTIRE FILE TO FIX:
```csharp
{file_code}
```

DEPENDENCIES FOR CONTEXT:
{dependency_context}

ALL VULNERABILITIES IN THIS FILE:
{vulnerabilities_list}

CRITICAL REQUIREMENTS:
1. Fix ALL {vuln_count} vulnerabilities listed above
2. Return the COMPLETE fixed file
3. Maintain exact structure: using statements, namespace, class declarations
4. Use ONLY existing class variables (_dbService, _authService)
5. NEVER create SqlConnection, SqlCommand, conn
6. NO markdown (no ```csharp, no ```)
7. Return ONLY raw C# code
8. DO NOT include dependency files in output
9. Return ONLY the target file being fixed
10. Dependencies are for context only - DO NOT modify them

OUTPUT JSON:
{{
  "fixed_file": "using System;\\nusing ...\\n\\nnamespace ...\\n{{\\n    public class ...\\n}}",
  "summary": "Fixed {vuln_count} vulnerabilities in this file"
}}

Return the COMPLETE fixed file as raw C# code with \\n for newlines."""