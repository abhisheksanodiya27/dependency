"""
Prompts for Dependency Checker Agent
"""

SYSTEM_PROMPT = """You are a senior security engineer and code analyzer. Analyze if fixing a vulnerability requires access to other project files."""

USER_PROMPT = """Analyze if fixing this vulnerability requires other project files.

PROJECT TREE:
{project_tree}

TARGET FILE: {file_path}

CODE:
```
{file_code}
```

VULNERABILITY:
- Type: {vuln_type}
- CWE: {cwe_id}
- Line: {line_number}
- Function: {function_name}
- Description: {description}
- Affected Code: {affected_code}
- Recommendation: {recommendation}
- Dependency Chain: {dependency_chain}

TASK:
Determine if other files from the project tree are needed to fix this vulnerability.

OUTPUT (JSON):
{{
  "requires_dependencies": true/false,
  "required_files": [
    {{
      "file_path": "Services/DatabaseService.cs",
      "reason": "Need to see ExecuteQuery implementation",
      "confidence": "high"
    }}
  ],
  "reasoning": "Explanation here"
}}"""